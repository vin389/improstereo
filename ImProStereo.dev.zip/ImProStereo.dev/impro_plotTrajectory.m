function handles = impro_plotTrajectory( hObject, handles )
% This function plots a 3D trajectory on a plot 
% 
% Advanced option dialog
dialog_prompt = { '1. Ctrl point(s):', ...
                  '2. Coord. sys. ID' };                
dialog_title  = 'Plot/save control point 3D coordinates.';
dialog_default= { '1', '1'};
dialog_answer = inputdlg( dialog_prompt, dialog_title, 1, dialog_default );

if ( size(dialog_answer,1) == 0 )
  return;
end

% Coord. sys IDs
CtrlPointRange = str2num(dialog_answer{1}); 
coordID_ref    = str2num(dialog_answer{2}); 

% Check if handles.CoordSys is empty
if (exist('handles.CoordSys', 'var') == 0) 
  % if no coord. sys is defined, at least define:
  % handles.CoordSys{1:handles.nPair,1} = identity(4,4); 
  for iPair = 1: handles.nPair
    handles.CoordSys{iPair,1} = [1 0 0 0; 0 1 0 0; 0 0 1 0; 0 0 0 1];   
  end
end

if ( (coordID_ref < 0) || ... 
     (coordID_ref >= 1 && coordID_ref > size(handles.CoordSys, 2))) 
  fprintf('Invalid input of movement coord. ID.\n');
  return;
end

nPointPlot = size( CtrlPointRange, 2 ); 
CtrlPosit  = zeros( handles.nPair, 3 * nPointPlot );
%CtrlDisps  = zeros( handles.nPair, 3 * nPointPlot );
 
% if cam. coord.
if ( coordID_ref == 0 )
  for iiPoint = 1: nPointPlot
    iPoint = CtrlPointRange(iiPoint);
    CtrlPosit(:, (iiPoint-1)*3+1 ) = handles.CtrlPoints3D(:, 1, iPoint, 1);
    CtrlPosit(:, (iiPoint-1)*3+2 ) = handles.CtrlPoints3D(:, 1, iPoint, 2);
    CtrlPosit(:, (iiPoint-1)*3+3 ) = handles.CtrlPoints3D(:, 1, iPoint, 3);
  end
end

% if user-defined coord.
if ( coordID_ref >= 1 )
  for iPair = 1: handles.nPair
    % Transform matrix from cam coord. to ref coord.
    refMat = handles.CoordSys{iPair, coordID_ref}; 
    refMat = inv(refMat); 
    for iiPoint = 1: nPointPlot
      iPoint = CtrlPointRange(iiPoint);
      thePoint4      = zeros(4,1);
      thePoint4(1:3) = handles.CtrlPoints3D(iPair, 1, iPoint, 1:3);
      thePoint4(4)   = 1.0; 
      thePoint4 = refMat * thePoint4; 
      CtrlPosit( iPair, (iiPoint-1)*3+1 ) = thePoint4(1);
      CtrlPosit( iPair, (iiPoint-1)*3+2 ) = thePoint4(2);
      CtrlPosit( iPair, (iiPoint-1)*3+3 ) = thePoint4(3);
    end
  end
end

% calculate the displacements from the positions
%for iPair = 2: handles.nPair
%  for iiPoint = 1: nPointPlot
%    CtrlDisps( iPair, (iiPoint-1)*3+1 ) =  CtrlPosit( iPair, (iiPoint-1)*3+1 ) - CtrlPosit( 1, (iiPoint-1)*3+1 );
%    CtrlDisps( iPair, (iiPoint-1)*3+2 ) =  CtrlPosit( iPair, (iiPoint-1)*3+2 ) - CtrlPosit( 1, (iiPoint-1)*3+2 );
%    CtrlDisps( iPair, (iiPoint-1)*3+3 ) =  CtrlPosit( iPair, (iiPoint-1)*3+3 ) - CtrlPosit( 1, (iiPoint-1)*3+3 );
%  end
%end

% Plot it 
for iiPoint = 1: nPointPlot
  iPoint = CtrlPointRange(iiPoint);
  figure('Name', sprintf('Control points trajectory P-%02d', iPoint) );
  plot3( CtrlPosit(:,(iiPoint-1)*3+1), ...
         CtrlPosit(:,(iiPoint-1)*3+2), ...
         CtrlPosit(:,(iiPoint-1)*3+3), 'LineWidth', 2 );  
  grid on; 
end

% Save it to a file (ask user)
[datFile, datPath] = uiputfile('*.txt', ...
  'Save the control point trajectory data as ... CANCEL if you do not want to save');
if ( ischar(datFile) )
  fid = fopen( [datPath datFile], 'w' );
  % fprintf title row
  fprintf( fid, 'iPair\t');  
  for iiPoint = 1: nPointPlot
    iPoint = CtrlPointRange(iiPoint);
    fprintf( fid, 'Ux\tUy\tUz\t');
  end
  fprintf( fid, '\n');
  % fprintf data rows
  for iPair = 1: handles.nPair
    fprintf(fid, '%d\t', iPair );
    for iiPoint = 1: nPointPlot
      iPoint = CtrlPointRange(iiPoint);
      if ( coordID_ref < 0) 
          for idof = 1: 2
            fprintf( fid, '%10.2f\t', ...
              CtrlPosit(iPair, (iiPoint-1)*3 + idof) );
          end
      else
          for idof = 1: 3
            fprintf( fid, '%10.2f\t', ...
              CtrlPosit(iPair, (iiPoint-1)*3 + idof) );
          end
      end
    end % end of iiPoint
    fprintf( fid, '\n');
  end % end of iPair
  fclose(fid);
  
end % end if user saves data to a file. 














