function [dxL dyL thL dxR dyR thR ] = impro_moveBack(psx, psy, pit1, pit2)
%�N�Q���ʹL�᪺�Ӥ��A�H�Ĥ@�i�������I����ǡA���L���Ӥ���^��
% Input parameters:
%      psx: Photo size of X axis. (The width of photo.)
%      psy: Photo size of Y axis. (The height of photo.)
%      pit1: �����I�_�l�I
%      pit2: �����I�����I
% Output parameters:
%      dxL:  pixel movement along x direction of left camera. (image coordinate)
%      dyL:  pixel movement along y direction of left camera. (image coordinate)(downward)
%      thL:  angular rotation about image origin (0,0) (clockwise) (left camera)
%      dxR:  pixel movement along x direction of right camera. (image coordinate)
%      dyR:  pixel movement along y direction of right camera. (image coordinate)(downward)
%      thR:  angular rotation about image origin (0,0) (clockwise) (right camera)
%
% 2012/03/12 ��s�G���ϥΪ̿�J�Ӥ��������B��ֵ{���X�C
% 2012/03/16 ��s�G�[�t�B��C
tic;  %0.27
fprintf('Load data and set path...\n');
load 0524SCtrlPointFixed5.mat
s=size(handles.CtrlPoints);
pairs=s(1);  %�^���Ӥ����

pathL=char(handles.PhotoPath(1)); %�⥪��ۤ������|�ର�r��
n=size(pathL);
n=n(2)-1;
pathL=pathL(1,1:n);  %����|�̦h�l��'/' �R��

pathR=char(handles.PhotoPath(2));
n=size(pathR);
n=n(2)-1;
pathR=pathR(1,1:n);
toc;

for j=2:pairs
    c=1;
    for i=pit1:pit2
        XoL(c,1:2) = [handles.CtrlPoints(1,1,i,1),handles.CtrlPoints(1,1,i,2)]; %LeftCam initial
        XnL(c,1:2) = [handles.CtrlPoints(j,1,i,1),handles.CtrlPoints(j,1,i,2)]; %�Q���ʹL�᪺�����I�y��
        XoR(c,1:2) = [handles.CtrlPoints(1,2,i,1),handles.CtrlPoints(1,2,i,2)]; %RightCam initial
        XnR(c,1:2) = [handles.CtrlPoints(j,2,i,1),handles.CtrlPoints(j,2,i,2)]; %�Q���ʹL�᪺�����I�y��
        c=c+1;
    end
    [a b c] = impro_findCamMove(XoL,XnL);    %�D���۾��� dx,dy,th�Ѽ�
    dxL(j-1)=a;
    dyL(j-1)=b;
    thL(j-1)=c;
    [a b c] = impro_findCamMove(XoR,XnR);    %�D�k�۾��� dx,dy,th�Ѽ�
    dxR(j-1)=a;
    dyR(j-1)=b;
    thR(j-1)=c;
    
    tic; %88
    phn=char(handles.filelistPhoto(j,1));       %phn=photo name;
    fprintf('Calculating the %d pair left photo.  (%s) ... \n', j, phn);
    [iMesh2Dx iMesh2Dy] = calloc(psx, psy, dxL(j-1), dyL(j-1), thL(j-1));
    toc;
    tic; %1.6
    fprintf('cvremap..\n');
    iPhotoimg = imread([pathL phn]);              %Ū������Ӥ�
    % if read image is one-channel, convert it to 3-channel (vince 2014-08-07)
    if (size(iPhotoimg,3) == 1) 
       iPhotoimg = uint8(cat(3,iPhotoimg,iPhotoimg,iPhotoimg));
    end
  
    iRectfImg = cvRemap(uint8(iPhotoimg), iMesh2Dx, iMesh2Dy );
    imwrite( iRectfImg, ['L' phn],'jpg' );
    fprintf('The %d pair left photo save comple.  (L%s)... \n', j,phn);
    toc;
    
    tic;
    fprintf('Calculating the %d pair right photo. (%s) ... \n', j, phn);
    phn=char(handles.filelistPhoto(j,2));       %phn=photo name;
    [iMesh2Dx iMesh2Dy] = calloc(psx, psy, dxR(j-1), dyR(j-1), thR(j-1));
    toc;
    tic;
    iPhotoimg=imread([pathR phn]);              %Ū���k��Ӥ�
    % if read image is one-channel, convert it to 3-channel (vince 2014-08-07)
    if (size(iPhotoimg,3) == 1) 
       iPhotoimg = uint8(cat(3,iPhotoimg,iPhotoimg,iPhotoimg));
    end
    
    iRectfImg = cvRemap(uint8(iPhotoimg), iMesh2Dx, iMesh2Dy );
    imwrite( iRectfImg, ['R' phn],'jpg' );
    fprintf('The %d pair right photo save comple. (R%s)... \n', j,phn);
    toc;
end
end

function [iMesh2Dx iMesh2Dy] = calloc(psx, psy, dx, dy, th)
%�ѷs�Ӥ���(X,Y)�y�СA��X�Ӯy�Ъ���X�O�b�·Ӥ������Ӯy��
%      [ cos(th) -sin(th) dx ]
% R =  [ sin(th)  cos(th) dy ]
%      [   0        0      1 ]
%
% {Xn}        {Xo}
% {Yn} =  R * {Yo}
% {1 }        {1 }
%
% {Xo}             {Xn}
% {Yo} =  inv(R) * {Yn}
% {1 }             {1 }
iMesh2Dx=zeros(psy, psx, 'single');
iMesh2Dy=zeros(psy, psx, 'single');
dx=-dx;
dy=-dy;
th=-th;
R=[cos(th) , -sin(th), dx; ...
    sin(th),  cos(th), dy; ...
    0      ,     0   , 1 ];
Rinv = inv(R);
r11 = Rinv(1,1);
r21 = Rinv(2,1);
for h=1:psy
    sumdx = Rinv(1,2) * h + Rinv(1,3);
    sumdy = Rinv(2,2) * h + Rinv(2,3);
    for k=1:psx
        iMesh2Dx(h,k)= sumdx + k * r11;
        iMesh2Dy(h,k)= sumdy + k * r21;
    end
end

end


