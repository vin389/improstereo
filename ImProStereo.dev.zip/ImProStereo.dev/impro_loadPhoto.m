function [handles,iPhotoimg] = ... 
         impro_loadPhoto(hObject, handles, iPair, iLR)
% This function loads photo image and data from file and show the image.
% To save memory, photo images are not stored in handles memory.

% Photos
if ( isfield(handles, 'iPhotoPair') && isfield(handles, 'iPhotoLR') && ...
     isfield(handles, 'iPhoto')     && ...
     handles.iPhotoPair == iPair    && handles.iPhotoLR == iLR )
   iPhotoimg = handles.iPhoto; 
   return; 
end


%   Define iPhoto
if ( exist([handles.PhotoPath{iLR} handles.filelistPhoto{iPair,iLR}],'file') )
  iPhotoimg = imread([handles.PhotoPath{iLR} handles.filelistPhoto{iPair,iLR}]);
  % if read image is one-channel, convert it to 3-channel (vince 2014-08-07)
  if (size(iPhotoimg,3) == 1) 
      iPhotoimg = uint8(cat(3,iPhotoimg,iPhotoimg,iPhotoimg));
  end
  
  axes(handles.axPhoto{iLR});
  cla(handles.axPhoto{iLR});   % If we do not clear axes first, the image
                               % object is added and the original image 
                               % is not cleared. Memory usage expands.
  image(iPhotoimg);
  axis equal;                  % added by vince (12 Aug 2014)
  fprintf('Photo Pair:%d/LR:%d loaded.\n', iPair, iLR );
  handles.iPhoto = iPhotoimg;
  handles.iPhotoPair = iPair; 
  handles.iPhotoLR   = iLR; 
else
  cla(handles.axPhoto{iLR});
  fprintf('Photo Pair:%d/LR:%d is not loaded.\n', iPair, iLR );
  iPhotoImg = [];
end

end


