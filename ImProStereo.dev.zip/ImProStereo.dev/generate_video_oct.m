function generate_video()

[files,directory] = uigetfile({'*.jpg', 'JPG-files (*.jpg)'}, 'Pick JPG files that you want to put in video', 'MultiSelect', 'on');

% if user clicks Cancel
if (~iscell(files))
    return;
end

% get video parameter
user_input = inputdlg({'Video file' 'fps' 'compression' 'Group-of-pictures' 'bitrate' 'resize factor' }, ...
                       'Input parameter for the video', 1, ...
                       {'MyVideoName.avi' '30'  'mpeg4' '1' '400000' '0.2'}); 
                   
if (isempty(user_input))
    return;
end

filename    = user_input{1}; 
fps         = user_input{2};
compression = user_input{3};
gop         = user_input{4};
bitrate     = user_input{5};

resize_fact = str2num(user_input{6}); 

% open file
try
    aviobj = avifile([directory filename], 'fps', eval(fps), ...
                     'compression', compression, ...
                     'gop', eval(gop), 'bitrate', eval(bitrate) ); 

    % for each jpg file, read image and add frames
    nfiles  = max(size(files, 2)); 

    for i = 1: nfiles
        if (i == 1) 
            hwait = waitbar(0,'Generating video ...');
        end
        fullpathname = [directory files{i}];
        img = imread(fullpathname); 
        img = resize(img, resize_fact, resize_fact); 
        img = double(img) / 256.0 ; 
        try 
            aviobj = addframe(aviobj, img);
        catch
            % fprintf('Error message of aviobj is ignored.\n');
        end
        waitbar(i / nfiles, hwait); 
    end    % end of for each file

    close(aviobj); 
    clear aviobj; 
    close(hwait); 
catch
    if (exist('aviobj', 'var')) 
        aviobj = close(aviobj); 
    end
    if (exist('hwait', 'var'))
        close(hwait); 
    end
end
    
end 
