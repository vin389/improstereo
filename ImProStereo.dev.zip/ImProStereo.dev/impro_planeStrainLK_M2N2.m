function [uxGrid,uyGrid,strain2Dxx,strain2Dyy,strain2Dxy,xGrid,yGrid, infoTM ] = ...
         impro_planeStrainLK(imgInitial, imgDeformd, rangeTracing, options)
%
%  [ux,uy,exx,eyy,exy] = impro_planeStrain20(img1, img2, rangeTracing, options)
%   
%  impro_planeStrainLK calculates 2D displacment and strain fields.
%  by calling cvCalcOpticalFlowPyrLK. 
%  
%  INPUTS: 
%
%    imgInitial:        image of initial  specimen
%    imgDeformd:        image of deformed specimen
%    rangeTracing:  [x1Tracing x2Tracing y1Tracing y2Tracing]: 
%                       range of the target in img1
%    options:           options for the displacement/strain field measurement
%      options.M:       number of rows    of feature points. Default value: round(height/50)
%      options.N:       number of columns of feature points. Default value: round(width/50) 
%      options.winSx    search window size. Default value: min(11, round(width/N/2)*2+1)
%      options.winSy    search window size. Default value: min(11, round(height/M/2)*2+1)
%      options.nlevel   number of levels of pyramid LK. Default value is 3. 
%      options.itrType  iteration criterion type: 1:maxIter. 2:epsilon. 3:Stop when either reaches.
%                       Default value is 3.  
%      options.maxIter  max number of iterations for LK. Default value is 20. 
%      options.epsilon  epsilon of iterations for LK. Default value is 1e-4. 
%      options.flags    miscellaneous flags. Default is 0. 
%                       CV_LKFLOW_PYR_A_READY       1
%                       CV_LKFLOW_PYR_B_READY       2
%                       CV_LKFLOW_INITIAL_GUESSES   4   
%                       CV_LKFLOW_GET_MIN_EIGENVALS 8
%
%  OUTPUTS:
%
%    uxGrid/uyGrid:       displacement fields.  (in pixel)
%                         size: Mu by Nu.  Mu/Nu: number of rows/columns of the displacement field grid.
%    strain2Dxx/yy/xy:    strain fields 
%                         size: Mu by Nu.  Mu/Nu: number of rows/columns of the strain field grid. 
%    xGrid/yGrid:         grid positions (in pixel)
%    infoTM:              information of template matching
%    infoTM.Acc(1:M,1:N): Err returned from OpenCV LK function.  
%    

% initialization of return values 
uxGrid = [];
uyGrid = [];
strain2Dxx = [];
strain2Dxy = [];
strain2Dyy = [];
xGrid = [];
yGrid = [];
infoTM = [];

%
% basic information
%
  x1Tracing= rangeTracing(1);
  x2Tracing= rangeTracing(2);
  y1Tracing= rangeTracing(3);
  y2Tracing= rangeTracing(4);
  sxImgInit= size(imgInitial,2); 
  syImgInit= size(imgInitial,1);
  sxImgDefm= size(imgDeformd,2); 
  syImgDefm= size(imgDeformd,1);
  if ( sxImgInit ~= sxImgDefm || syImgInit ~= syImgDefm )
    fprintf( 'Warning: Initial/deformed images have different sizes. ');
    fprintf( ' As OpenCV LK function requires they have the same size, '); 
    fprintf( ' the images are expanded to fit OpenCV LK requirement\n.');
  end
  
%
% optional parameters (in options.xxx) 
%
%   M/N:   Template matching refinement. # of rows/columns of templates. 
%   Default values assigned first.
  M = round(syImgInit/50);
  N = round(sxImgInit/50);
  if (isstruct(options))
    if (isfield(options,'M'))
      M = options.M;
    end
    if (isfield(options,'N'))
      N = options.N;
    end
  end
%   winSx/winSy : search window size. Have to be odd numbers. 
%   Default values assigned first.
%   Note: 
%   1. We are not sure the definition of window sizes are the width/height 
%      or "half" of width/height. We expected they are width/height. But 
%      in some tests, the window covered areas that we did not expect. So 
%      we reduce them to "half" of window size. 
%   2. The window size should be small considering they are (possibly) 
%      applied to all levels of pyramid images. Large window sizes are not 
%      proper for coarsened images. 
  winSx = min(15, round(sxImgInit/N/2/2)*2+1) ;
  winSy = min(15, round(syImgInit/M/2/2)*2+1) ;
  if (isstruct(options))
    if (isfield(options,'winSx'))
      winSx = options.winSx;
    end
    if (isfield(options,'winSy'))
      winSy = options.winSy;
    end
  end
%   nlevel: number of levels of pyramid LK. 
%   Default values assigned first.
  nlevel = 3; 
  if (isstruct(options) && isfield(options,'nlevel'))
      nlevel = options.nlevel;
  end
%   itrType: iteration criterion type 
%   Default values assigned first.
  itrType = 3; 
  if (isstruct(options) && isfield(options,'itrType'))
      itrType = options.itrType;
  end
%   maxIter: max number of iterations 
%   Default values assigned first.
  maxIter = 30; 
  if (isstruct(options) && isfield(options,'maxIter'))
      maxIter = options.maxIter;
  end
%   epsilon: epsilon of iterations 
%   Default values assigned first.
  epsilon = 1e-6; 
  if (isstruct(options) && isfield(options,'epsilon'))
      maxIter = options.epsilon;
  end
%   flags: miscellaneous flags 
%   Default values assigned first.
  flags = 0; 
  if (isstruct(options) && isfield(options,'flags'))
      maxIter = options.flags;
  end
  
% increase Mu Nu by 2 for abandoning the boundary grids later.
  M2 = M + 2;
  N2 = N + 2;
  
%
% define the positions of feature points (center of templates)
%
% Feature points along image coord. X and Y 
  xInc = (x2Tracing-x1Tracing+1)/(N-2);
  x1Feature = x1Tracing - xInc; 
  x2Feature = x2Tracing + xInc; 
  xFeatures = linspace(x1Feature, x2Feature, N2);
  yInc = (y2Tracing-y1Tracing+1)/(M-2);
  y1Feature = y1Tracing - yInc; 
  y2Feature = y2Tracing + yInc; 
  yFeatures = linspace(y1Feature, y2Feature, M2);
% Feature points grid to 1-d array
  [xgrid,ygrid] = meshgrid(xFeatures, yFeatures);
  prevFeatures(1,:) = xgrid(:);
  prevFeatures(2,:) = ygrid(:);
  nFeatures = M2*N2; 

% Pyramid information. Will be an array later on.  
  prevPyr = 0; 
  currPyr = 0; 

% winSize 
  winSize = [winSx winSy];
  
% Iterative criteria 
  criteria = [ itrType maxIter epsilon ]; 
  
%
% Call pyramid LK optical flow analysis (an interface to OpenCV) 
%
  [prevPyr, currPyr, currFeatures, status, track_error] = ...
            cvCalcOpticalFlowPyrLK( imgInitial, imgDeformd, ...
                                    prevPyr, currPyr, ...
                                    prevFeatures, ...
                                    nFeatures, winSize, nlevel, ...
                                    criteria, flags ); 
% Calculate displacements and reshape the 1-d array to 2-d
  disp = currFeatures - prevFeatures; 
  uxGrid = reshape(disp(1,:),   [M2 N2]);
  uyGrid = reshape(disp(2,:),   [M2 N2]);
  errU   = reshape(track_error, [M2 N2]); 
  statuU = reshape(status,      [M2 N2]); 

  infoTM.Acc = ones(M,N);
  
%
% calculate strain field from the template displacements
%
%   strain2Dxx/yy/xy(1:M, 1:N)    the strain component of the region. (sxx,syy,sxy)
%   x/yGrid(1:M,1:N):    center points of regular grid 
%   ux/uyGrid(1:M2,1:N2)   :   displacement field on regular grid
%   

%
% calculation of strain 
% Note: strain2D is in image coordinate (which image Y vector is downward). Normally in 3D the Y vector
% is upward, so the strain2Dxy will be converted.
% 
 for i=2:M2-1
 for j=2:N2-1
   ux_left=uxGrid(i,j-1);  ux_rigt=uxGrid(i,j+1); 
   uy_left=uyGrid(i,j-1);  uy_rigt=uyGrid(i,j+1); 
   ux_up__=uxGrid(i-1,j);  ux_down=uxGrid(i+1,j); 
   uy_up__=uyGrid(i-1,j);  uy_down=uyGrid(i+1,j); 
   
   xx_left= xFeatures(j-1);  xx_rigt= xFeatures(j+1);
   yy_left= yFeatures(i  );  yy_rigt= yFeatures(i  );
   xx_up__= xFeatures(j  );  xx_down= xFeatures(j  );
   yy_up__= yFeatures(i-1);  yy_down= yFeatures(i+1);

   strain2Dxx(i-1,j-1)= (ux_rigt-ux_left)/(xx_rigt-xx_left);
   strain2Dyy(i-1,j-1)= (uy_up__-uy_down)/(yy_up__-yy_down);
   strain2Dxy(i-1,j-1)= 0.5*( (ux_up__-ux_down)/(yy_up__-yy_down) + (uy_rigt-uy_left)/(xx_rigt-xx_left) );
 end; end
 
%
% abandoning boundary grid.
%
 uxGrid     = uxGrid(2:M2-1,2:N2-1);
 uyGrid     = (-1) * uyGrid(2:M2-1,2:N2-1);
 xGrid      = xFeatures(2:N2-1);
 yGrid      = yFeatures(2:M2-1);

end

 