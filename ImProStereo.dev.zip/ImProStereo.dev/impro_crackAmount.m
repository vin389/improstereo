function [crackHistCount, crackMidVal] = impro_crackAmount(field1, minCrackRange, maxCrackRange, numCrackRange) 
field1_1d = field1(:); 
field1_1d(field1_1d < minCrackRange) = nan;
field1_1d(field1_1d > maxCrackRange) = maxCrackRange;

crackEdges = logspace(log10(minCrackRange),log10(maxCrackRange),numCrackRange); 

[crackHistCount,crackEdgesOut] = histcounts(field1_1d, crackEdges);

crackMidVal = zeros(1, numCrackRange - 1);
for i = 1:numCrackRange-1
    crackMidVal(i) = (crackEdgesOut(i) + crackEdgesOut(i + 1)) / 2;
end

plotHist = false; 
if (plotHist)
    figure; plot(crackMidVal, crackHistCount); grid on; 
    set(gca, 'XScale', 'log')
    set(gca, 'YScale', 'log')
    xlim([crackMidVal(1) crackMidVal(end)]);
    ylim([1 numel(field1_1d)]); 
    xticks(crackMidVal);
    xticklabels(round(crackMidVal,3));
end

end
