%% Object points

obj_xyz = [];
% User selects Excel from uigetfile
[filename, pathname] = uigetfile( {'*.xlsx';'*.xls'}, 'Pick Excel file of markers coordinates');
if (isnumeric(filename)) 
    disp('User cancelled.');
    return;
end
if (exist([pathname filename], 'file') ~= 2)
    disp('File not found.');
    return;
end
% Read markers coordinates (to markers_xyz(1:nMarker, 1:3)) 
% Marker ID has to be correctedly ordered
[obj_xyz,txt,raw] = xlsread([pathname filename], 'Markers'); 
nMarker = size(obj_xyz, 1); 
markers_xyz_col = input('Enter Markers XYZ column range (e.g., 1:3 or 3:5): ');

%% Image points
[xlsStatus,xlsSheets] = xlsfinfo([pathname filename]);
disp(['XLS file: ' pathname filename]);
for i = 1: size(xlsSheets, 2)
    fprintf('Sheet %d: %s\n', i, xlsSheets{i});
end
nameSheetUx = input('Which sheet is ux? (Enter the number): ');
nameSheetUy = input('Which sheet is uy? (Enter the number): ');
[img_ux_xls,txt,img_ux_raw] = xlsread([pathname filename], xlsSheets{nameSheetUx}); 
[img_uy_xls,txt,img_uy_raw] = xlsread([pathname filename], xlsSheets{nameSheetUy}); 
img_ux = img_ux_xls(:,4:end);
img_uy = img_uy_xls(:,4:end);

%% Form object points data (those have image points data)
% check img_ux and img_uy have the same size
if (size(img_ux, 2) ~= size(img_uy, 2)) 
    disp('Ux and Uy data size are not consistent.');
    fprintf('Ux size is %d. Uy size is: %d.\n', size(img_ux, 2), size(img_uy, 2) );
    return;
end
clear obj_xyz_valid;
clear img_xy_valid; 
nPoint = 0;
for iPointXls = 1: size(img_ux, 2)
    % if this point is traced, not NaN
    if (isnan(img_ux(1, iPointXls)) == false ...
        && img_ux(1, iPointXls) ~= 0.0 ) 
        nPoint = nPoint + 1;
%        obj_xyz_valid{1}{nPoint} = obj_xyz(iPointXls, 1:3); 
        obj_xyz_valid{1}{nPoint} = obj_xyz(iPointXls, markers_xyz_col); 
        img_xy_valid{1}{nPoint} = [img_ux(1, iPointXls) img_uy(1, iPointXls) ];
    end
end
nValidPoints = size(img_xy_valid{1},2); 
fprintf('There are %d valid points.\n', nValidPoints); 

%% Calibrate camera
% For non-planar calibration rigs the initial intrinsic matrix must be 
% specified in function cvCalibrateCamera

% Conert image points from cell format to mat format
img_xy_valid_mat = zeros( nValidPoints, 2 ); 
for i = 1: nValidPoints
    img_xy_valid_mat(i,:) = img_xy_valid{1}{i};
end

% Find a possible image size
clear possible_wh; 
possible_wh(4, 1:2) = [3840 2160];
possible_wh(3, 1:2) = [1920 1080];
possible_wh(2, 1:2) = [1440 1080];
possible_wh(1, 1:2) = [1280  720];
img_cx = sum(img_xy_valid_mat(:,1)) / nValidPoints; 
img_cy = sum(img_xy_valid_mat(:,2)) / nValidPoints;
fprintf('Valid points average: X: %f  Y: %f\n', img_cx, img_cy); 
wh_err = 1e99; 
which_wh = 0; 
for i = 1: size(possible_wh, 1)
    err = (img_cx * 2 - possible_wh(i, 1)) ^ 2 + ...
          (img_cy * 2 - possible_wh(i, 2)) ^ 2 ;
    if (err < wh_err)
        which_wh = i;
        wh_err = err; 
    end
end
w = possible_wh(which_wh, 1); 
h = possible_wh(which_wh, 2); 
fprintf('Guessed image size: %d x %d.\n', w, h); 

%w = 3840; h = 2160;
fx = input('Fx: '); % fx = w * 0.75; 
fy = input('Fy: '); % fy = fx; 
cx = input('Cx: '); % cx = w / 2;
cy = input('Cy: '); % cy = h / 2;
clear distCoeffs; 
distCoeffs(1) = input('K1: '); 
distCoeffs(2) = input('K2: '); 
distCoeffs(3) = input('P1: '); 
distCoeffs(4) = input('P2: '); 
distCoeffs(5) = 0; 
cameraMatrix = [fx 0 cx; 0 fy cy; 0 0 1]; 
% distCoeffs = [0 0 0 0]; 
objectPoints = zeros( size(obj_xyz_valid{1}, 2), 3); 
for i = 1: size(obj_xyz_valid{1}, 2)
    objectPoints(i, 1:3) = obj_xyz_valid{1}{i}; 
end
imagePoints = zeros(  size(img_xy_valid{1}, 2), 2);
for i = 1: size(img_xy_valid{1}, 2)
    imagePoints(i, 1:2) = img_xy_valid{1}{i}; 
end
[rvec, tvec, success] = cv.solvePnP(objectPoints, imagePoints, cameraMatrix, 'DistCoeffs', distCoeffs); 
% [rvec, tvec, success] = cv.solvePnP(obj_xyz_valid{1}, img_xy_valid, cameraMatrix, 'DistCoeffs', distCoeffs); 
rvecs{1} = rvec; 
tvecs{1} = tvec; 
% [cameraMatrix, distCoeffs, reprojErr, rvecs, tvecs] = cv.calibrateCamera( ... 
%     obj_xyz_valid, img_xy_valid, [w, h], ...
%     'CameraMatrix', cameraMatrix, ...
%     'DistCoeffs', distCoeffs, ...
%     'UseIntrinsicGuess', true, ...
%     'FixAspectRatio', true, ...
%     'ZeroTangentDist', false, ...
%     'FixK1', false, ...
%     'FixK2', false, ...
%     'FixK3', true, ...
%     'FixK4', true, ...
%     'FixK5', true, ...
%     'FixK6', true ); 
% fx = cameraMatrix(1,1);
% fy = cameraMatrix(2,2);
% cx = cameraMatrix(1,3);
% cy = cameraMatrix(2,3); 

% Display camera parameters
fprintf('Fx: %12.3f\n', cameraMatrix(1,1));
fprintf('Fy: %12.3f\n', cameraMatrix(2,2));
fprintf('Cx: %12.3f\n', cameraMatrix(1,3));
fprintf('Cy: %12.3f\n', cameraMatrix(2,3));
fprintf('Dist Coeff.: '); disp(distCoeffs); 
% fprintf('Reproj err.: %12.4e\n', reprojErr); 

img_xy_valid_proj = ...
    cv.projectPoints(obj_xyz_valid{1}, rvecs{1}, tvecs{1}, cameraMatrix, ...
    'DistCoeffs', distCoeffs); 

img_xy_valid_proj_mat = zeros( size(img_xy_valid{1},2), 2 ); 

for i = 1: size(img_xy_valid{1},2)
    img_xy_valid_mat(i,:) = img_xy_valid{1}{i};
    img_xy_valid_proj_mat(i,:) = img_xy_valid_proj{i};
end

%% Plot image / reproj points
figure; 
plot(img_xy_valid_mat(:,1), img_xy_valid_mat(:,2), ':b'); hold on;
plot(img_xy_valid_proj_mat(:,1), img_xy_valid_proj_mat(:,2), ':r'); hold on;
legend('Image', 'Reproj'); 
set(gca,'YDir','reverse');

%% Display camera position
R3 = cv.Rodrigues(rvecs{1}); 
R4 = [R3(1,1:3) tvecs{1}(1); R3(2,1:3) tvecs{1}(2); R3(3,1:3) tvecs{1}(3); 0 0 0 1];
invR4 = inv(R4); 
fprintf('Camera is at %7.1f %7.1f %7.1f\n', invR4(1,4), invR4(2,4), invR4(3,4));
