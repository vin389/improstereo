function handles = ...
         impro_saveCtrlPoint(hObject, handles)
% This function saves gui variable "handles" into a user selected file.
% This function is designed for ImPro Strain 2.0 only.

[handles.DataFile handles.DataPath] = uiputfile('*.mat');
if ( isnumeric(handles.DataPath) && isnumeric(handles.DataFile) ) 
  return     
end
% try to save the file. If fails, try again
for itry = 1: 10
    file_saved = 0; 
    try
        % Save non-ui-control variables in handles
        %  (by temporarily removing ui variables from handles) 
        clear save_data; 
        fieldnames_handles = fieldnames(handles);
        n_fields = max(size(fieldnames_handles)); 
        for i_field = 1: n_fields
            ftype = class(handles.(fieldnames_handles{i_field}));
            % if it is a matlab component (ui or graphics) then skip it.
            if (strcmp(ftype(1:min(max(size(ftype)),7)), 'matlab.')) 
                continue; 
            end
            % if it is a cell of matlab components then skip it
            if (iscell(handles.(fieldnames_handles{i_field}))) 
                tmp = handles.(fieldnames_handles{i_field}); 
                ftype = class(tmp{1});
                if (strcmp(ftype(1:min(max(size(ftype)),7)), 'matlab.')) 
                    continue;
                end
            end
            % if it is iPhoto (a large temporary variable) then skip it.
            if (strcmp(fieldnames_handles{i_field}, 'iPhoto') ) 
%                continue;
            end
            % OK. Ready to save this field
            save_data.(fieldnames_handles{i_field}) = handles.(fieldnames_handles{i_field});
        end
        tmp = handles;
        handles = save_data; 
        save([handles.DataPath handles.DataFile], 'handles');
        handles = tmp; clear save_data; 
        fprintf('File saved successfully (the %d-th try).\n', itry);
        file_saved = 1; 
        break;
    catch
        fprintf('Having a problem when saving file (the %d-th time). Trying again... \n', itry); 
        pause(1.0); 
        continue; 
    end
end
if (file_saved == 0) 
    fprintf('Failed to save file (after %d tries). Please save to a new file.\n', itry); 
end
end