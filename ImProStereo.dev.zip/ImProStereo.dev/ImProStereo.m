function varargout = ImProStereo(varargin)
% ImProStereo M-file for ImProStereo.fig
%      ImProStereo, by itself, creates a new ImProStereo or raises the existing
%      singleton*.
%
%      H = ImProStereo returns the handle to a new ImProStereo or the handle to
%      the existing singleton*.
%
%      ImProStereo('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in ImProStereo.M with the given input arguments.
%
%      ImProStereo('Property','Value',...) creates a new ImProStereo or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before ImProStereo_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to ImProStereo_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES
% 
% ------------------------------------------------------------------------
% Variables in this handles
% ------------------------------------------------------------------------
%   handles.ListPath/ListFile - [ListPath ListFile] is the full path of the
%                               file-list file.
%   handles.DataPath/DataFile - [DataPath DataFile] is the full path of the
%                               complete handles data. By default it is the
%                               same as [ListPath ListFile] except the ext.
%                               name is '.mat'. 
%   handles.verFile       - version of ImProStereo that the input file for.
%                           (Note: Not the version of this program.) 
%   handles.CalibPath/CalibFile - the full path of the 3D calibration data.
%   handles.nPair         - number of pairs of photos
%   handles.nLR           - number of photos in a pair (1 or 2)
%   handles.nPoint        - number of control points in a photo (default:4)
%
%   handles.iPair         - the current pair of photos (shown) 
%   handles.iLR           - selected side (1:left or 2:right)
%   handles.iPoint        - selected control point 
% 
%   ----------------------------------------------------------------------
%   handles.CtrlPoints(iPair,iLR,iPoint,iXy) - the matched control points
%                                              in images 
%   handles.CtrlPoints3D(iPair,iLR,iPoint,iXyz) - the matched control 
%                                              points in 3D space.
%                                              For iLR==1, L-camera coord.
%                                              For iLR==2, R-camera coord.
%   ----------------------------------------------------------------------
%   handles.filelistPhoto{iPair,iLR} - file list of photo files (.JPG)
%                         - iPair: the pair index of photos
%                         - iLR: Left(iLR=1) or Right(iLR=2) photo
%   handles.PhotoPath{ }  - the folder path (with a slash at end) of photos
%          .PhotoPath{1}  - the folder path of left photos
%          .PhotoPath{2}  - the folder path of right photos
%   handles.iPhoto        - the current photo image
%   handles.iPhotoPair    - latest loaded Photo iPair
%   handles.iPhotoLR      - latest loaded Photo iLR
%   
%   Note: Only the current pair (iPair) data are stored in MATLAB memory.
%
%   ----------------------------------------------------------------------
%   handles.filelistTmplt{iPair,iLR} - file list of template files (.mat)
%                         - iPair: the pair index of photos
%                         - iLR: Left(iLR=1) or Right(iLR=2) photo
%   handles.TmpltPath{ }  - the folder path (with a slash at end) of Tmplt
%          .TmpltPath{1}  - the folder path of left Tmplt
%          .TmpltPath{2}  - the folder path of right Tmplt
%          .TmpltSize     - the size of a template image (e.g., if 30, it
%                           means the template size is 30x30. 
%
%   The MATLAB structure: 
%   handles.iTmplt{iLR}
%           iTmplt{iLR}.nPoint   -- number of control points in each photo
%           iTmplt{iLR}.file{iP} -- file name of template image file (.JPG)
%           iTmplt{iLR}.pckXy{iP}(1,1:2) -- picked point in image
%           iTmplt{iLR}.refXy{iP}(1,1:2) -- picked point in template
%
%   handles.iTmplt{iLR}   - the template data of the current photo pair 
%
%   Note: Only the current pair (iPair) data are stored in MATLAB memory.
%
%   ----------------------------------------------------------------------
%   handles.filelistMatch{iPair,iLR} - file list of matched files (.mat)
%                         - iPair: the pair index of photos
%                         - iLR: Left(iLR=1) or Right(iLR=2) photo
%   handles.MatchPath     - the folder path (with a slash at end) of Match
%          .MatchPath{1}  - the folder path of left Match
%          .MatchPath{2}  - the folder path of right Match
%
%          The MATLAB structure: 
%   handles.iMatch{iLR}   - the matched data of the current photo pair 
%           iMatch{iLR}.nPoint   -- number of ctrl points in each photo
%           iMatch{iLR}.file{iP} -- file name of matched image (.JPG)
%           iMatch{iLR}.mchXy{iP}(1,1:2) -- matched picked point in image
%           iMatch{iLR}.refXy{iP}(1,1:2) -- matched picked point in match
%           iMatch{iLR}.corr{iP} -- correlation of each matching
%
%   Note: Only the current pair (iPair) data are stored in MATLAB memory.
%
%   ----------------------------------------------------------------------
%   handles.filelistRectf{iPair,iLR} - file list of rectified files (.mat)
%                         - iPair: the pair index of photos
%                         - iLR: Left(iLR=1) or Right(iLR=2) photo
%   handles.RectfPath{ }  - the folder path (with a slash at end) of Rectf
%          .RectfPath{1}  - the folder path of left Rectf
%          .RectfPath{2}  - the folder path of right Rectf
%   The MATLAB structure: 
%   handles.iRectf{iLR}   - the rectified data of the current photo pair 
%           iRectf{iLR}.nPoint   -- number of ctrl points in each photo
%           iRectf{iLR}.file -- file name of rectified image (.JPG)
%
%   ----------------------------------------------------------------------
%   handles.calib3d - 3D calibration data
%                   including the following important factors:
%     handles.calib3d.fc_left/right
%     handles.calib3d.kc_left/right
%     handles.calib3d.cc_left/right
%     handles.calib3d.alpha_c_left/right
%     handles.calib3d.om
%     handles.calib3d.T
%
%   ----------------------------------------------------------------------
%   handles.rectfMeasureRange(iPair, iLR, 4) 
%                             - The measureRange is the range of 
%                               measurement region of this rectified image. 
%                               Note: The measurement region is only a 
%                                 part of the rectified image.
%                                 The region is defined by this variable.
%     Note: The measureRange is a rectangle defined by the "corrected"
%     control points. The deformed image may be out of the range especially
%     when it has a shear deformation. 
%     range of X is measureRange(1) and (2)
%     range of Y is measureRange(3) and (4)
%   handles.rpxRectf          - length per pixel in rectified images 
%                               (an unique value in all rectified images)
%
%   ----------------------------------------------------------------------
%   handles.measurementErr - The measurement errors.
%     handles.measurementErr.TmpltErr(1:nPair, 1:nLR, 1:nPoint)
%     handles.measurementErr.StereoErr(1:nPair, 1:nPoint) 
% 
% UI objects 
%   handles.axPhotoLeft - handles.axPhoto{1}
%   handles.axPhotoRigt - handles.axPhoto{2}
%   handles.axTmpltLeft - handles.axTmplt{1}
%   handles.axTmpltRigt - handles.axTmplt{2}
%   handles.axMatchLeft - handles.axMatch{1}
%   handles.axMatchRigt - handles.axMatch{2}
%   handles.axRectfLeft - handles.axRectf{1}
%   handles.axRectfRigt - handles.axRectf{2}
%   handles.txCorrLeft  - handles.txCorr{1}
%   handles.txCorrRigt  - handles.txCorr{2}
% 
%   handles.slPair
%   handles.slLR
%   handles.slPoint
% 
% 
% 
% 
% Edit the above text to modify the response to help ImProStereo

% The ScreenPixelsPerInch property became read-only since R2015b (8.6)
ver_num = version; ver_num = ver_num(1:3); 
ver_num = str2num(ver_num);
if (ver_num < 8.5999999) 
    set(0, 'ScreenPixelsPerInch', 96);
end

% Last Modified by GUIDE v2.5 27-Jun-2012 13:43:33

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @ImProStereo_OpeningFcn, ...
                   'gui_OutputFcn',  @ImProStereo_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

% ------------------------------------------------------------------------
% ------------------------------------------------------------------------

% --- Executes just before ImProStereo is made visible.
function ImProStereo_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to ImProStereo (see VARARGIN)

handles = ImProStereoInit(hObject, handles );

% Choose default command line output for ImProStereo
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes ImProStereo wait for user response (see UIRESUME)
% uiwait(handles.fgImProStereo);

% ------------------------------------------------------------------------
% ------------------------------------------------------------------------

% --- Outputs from this function are returned to the command line.
function varargout = ImProStereo_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

% ------------------------------------------------------------------------
% ------------------------------------------------------------------------

% --- Executes on button press in pbGetFileList.
function pbGetFileList_Callback(hObject, eventdata, handles)
% hObject    handle to pbGetFileList (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles = impro_getFileList(hObject, handles);

% update handles variables
guidata(hObject, handles);

% ------------------------------------------------------------------------
% ------------------------------------------------------------------------

% --- Executes on slider movement.
function slPair_Callback(hObject, eventdata, handles)
% hObject    handle to slPair (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

% Set the slider disable until this function completes.
set(handles.slPair,'Enable','off');

% update slPair 
handles = impro_updSlPair(hObject, handles);

% Set the slider disable until this function completes.
set(handles.slPair,'Enable','on');

% update handles variables
guidata(hObject, handles);

% ------------------------------------------------------------------------
% ------------------------------------------------------------------------

% --- Executes during object creation, after setting all properties.
function slPair_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slPair (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end

% ------------------------------------------------------------------------
% ------------------------------------------------------------------------

% --- Executes on button press in pbPickPoint.
function pbPickPoint_Callback(hObject, eventdata, handles)
% hObject    handle to pbPickPoint (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles = impro_pbPickPoint(hObject, handles); 

% update handles variables
guidata(hObject, handles);

% ------------------------------------------------------------------------
% ------------------------------------------------------------------------

% --- Executes on slider movement.
function slLR_Callback(hObject, eventdata, handles)
% hObject    handle to slLR (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

% Set the slider disable until this function completes.
set(handles.slLR,'Enable','off');

% update slLR status
handles = impro_updSlLR(hObject, handles);

% Set the slider disable until this function completes.
set(handles.slLR,'Enable','on');

% update handles variables
guidata(hObject, handles);

% ------------------------------------------------------------------------
% ------------------------------------------------------------------------

% --- Executes during object creation, after setting all properties.
function slLR_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slLR (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end

% ------------------------------------------------------------------------
% ------------------------------------------------------------------------

% --- Executes on slider movement.
function slPoint_Callback(hObject, eventdata, handles)
% hObject    handle to slPoint (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

% Set the slider disable until this function completes.
set(handles.slPoint,'Enable','off');

% update slPoint status
handles = impro_updSlPoint(hObject,handles);

% Set the slider disable until this function completes.
set(handles.slPoint,'Enable','on');
% update handles variables
guidata(hObject, handles);

% ------------------------------------------------------------------------
% ------------------------------------------------------------------------

% --- Executes during object creation, after setting all properties.
function slPoint_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slPoint (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end

% ------------------------------------------------------------------------
% ------------------------------------------------------------------------

% --- If Enable == 'on', executes on mouse press in 5 pixel border.
% --- Otherwise, executes on mouse press in 5 pixel border or over txPoint.
function txPoint_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to txPoint (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Change number of control points (handles.nPoint)
handles = impro_changeNPoint(hObject, handles);

% update handles variables
guidata(hObject, handles);


% --- Executes on button press in pbAutoMatch.
function pbAutoMatch_Callback(hObject, eventdata, handles)
% hObject    handle to pbAutoMatch (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles = impro_autoMatch(hObject, handles);
% update handles variables
guidata(hObject,handles);


% --- Executes on button press in pbManualMatch.
function pbManualMatch_Callback(hObject, eventdata, handles)
% hObject    handle to pbManualMatch (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles = impro_manualMatch(hObject, handles);
% update handles variables
guidata(hObject,handles);

% --- Executes on button press in pbTmCopyL2R.
function pbTmCopyL2R_Callback(hObject, eventdata, handles)
% hObject    handle to pbTmCopyL2R (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles = impro_copyTmpltL2R(hObject, handles);
guidata(hObject, handles);


% --- Executes on button press in pbDebug.
function pbDebug_Callback(hObject, eventdata, handles)
% hObject    handle to pbDebug (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
keyboard; 
guidata(hObject, handles); 



% --- Executes on button press in pbLoadCtrlPoint.
function pbLoadCtrlPoint_Callback(hObject, eventdata, handles)
% hObject    handle to pbLoadCtrlPoint (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles = impro_loadCtrlPoint(hObject, handles);
% refresh control points status data 
handles = impro_refreshCtrlPointsStatus(hObject, handles); 
% refresh calibration status data  
handles = impro_refreshCalibStatus(hObject, handles);
% refresh 'Ctrl Points Matching' control ui Values
handles = impro_refreshMatchingControls(hObject, handles);
guidata(hObject, handles);


% --- Executes on button press in pbSaveCtrlPoint.
function pbSaveCtrlPoint_Callback(hObject, eventdata, handles)
% hObject    handle to pbSaveCtrlPoint (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles = impro_saveCtrlPoint(hObject, handles);
guidata(hObject, handles);


% --- Executes on button press in pbLoad3dCalib.
function pbLoad3dCalib_Callback(hObject, eventdata, handles)
% hObject    handle to pbLoad3dCalib (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles = impro_load3dCalib(hObject, handles)
guidata(hObject, handles);

% --- Executes on button press in pb3dMesh.
function pb3dMesh_Callback(hObject, eventdata, handles)
% hObject    handle to pb3dMesh (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles = impro_3dMesh( hObject, handles );

guidata(hObject, handles);


% --- Executes on button press in pbRectification.
function pbRectification_Callback(hObject, eventdata, handles)
% hObject    handle to pbRectification (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles = impro_Rectification(hObject, handles);

guidata(hObject, handles);

% --- Executes on button press in pbFieldAnalysis.
function pbFieldAnalysis_Callback(hObject, eventdata, handles)
% hObject    handle to pbFieldAnalysis (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles = impro_fieldAnalysis_Cylinder(hObject, handles);

guidata(hObject, handles);


% --- Executes on button press in pb_triangulation.
function pb_triangulation_Callback(hObject, eventdata, handles)
% hObject    handle to pb_triangulation (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles = impro_CtrlPointsTriangulation( hObject, handles );
guidata(hObject, handles); 

% --- Executes on button press in pb_showErr.
function pb_showErr_Callback(hObject, eventdata, handles)
% hObject    handle to pb_showErr (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

impro_ShowError(hObject, handles); 


% --- Executes on button press in pb_defineCoordSys.
function pb_defineCoordSys_Callback(hObject, eventdata, handles)
% hObject    handle to pb_defineCoordSys (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles = impro_DefineCoordSys( hObject, handles );

guidata(hObject, handles); 


% --- Executes on button press in pb_calcRigidDisp.
function pb_calcRigidDisp_Callback(hObject, eventdata, handles)
% hObject    handle to pb_calcRigidDisp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles = impro_CalcRigidDisp( hObject, handles );

guidata(hObject, handles); 


% --- Executes on button press in pb_CtrlPointDisp.
function pb_CtrlPointDisp_Callback(hObject, eventdata, handles)
% hObject    handle to pb_CtrlPointDisp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles = impro_CtrlPointDisp( hObject, handles );

guidata(hObject, handles); 

% --- Executes on button press in pb_CamMovCorrect.
function pb_CamMovCorrect_Callback(hObject, eventdata, handles)
% hObject    handle to pb_CtrlPointDisp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles = impro_CamMovCorrect( hObject, handles );

guidata(hObject, handles); 




% --------------------------------------------------------------------
function mn_File_Callback(hObject, eventdata, handles)
% hObject    handle to mn_File (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function mn_Exit_Callback(hObject, eventdata, handles)
% hObject    handle to mn_Exit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
ButtonName = questdlg('Are you sure you want to quit?', ...
  'Quit Question', ...
  'Yes', 'No', 'No');
switch ButtonName,
  case 'Yes',
    close(handles.fgImProStereo);
  case 'No',
    return
end % switch


% --------------------------------------------------------------------
function mn_GetFileList_Callback(hObject, eventdata, handles)
% hObject    handle to mn_GetFileList (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles = impro_getFileList(hObject, handles);

% update handles variables
guidata(hObject, handles);


% --------------------------------------------------------------------
function mn_LoadData_Callback(hObject, eventdata, handles)
% hObject    handle to mn_LoadData (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles = impro_loadCtrlPoint(hObject, handles);

guidata(hObject, handles);

% --------------------------------------------------------------------
function mn_SaveData_Callback(hObject, eventdata, handles)
% hObject    handle to mn_SaveData (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles = impro_saveCtrlPoint(hObject, handles);

guidata(hObject, handles);



% --------------------------------------------------------------------
function mn_Load3dCalib_Callback(hObject, eventdata, handles)
% hObject    handle to mn_Load3dCalib (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[handles.CalibFile handles.CalibPath] = uigetfile('*.mat');
if ( isnumeric(handles.CalibFile) && isnumeric(handles.CalibPath) ) 
  return     
end

calib3d = load([handles.CalibPath handles.CalibFile]);
handles.calib3d = calib3d; 

guidata(hObject, handles);


% --------------------------------------------------------------------
function mn_CtrlPoints_Callback(hObject, eventdata, handles)
% hObject    handle to mn_CtrlPoints (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function mn_CopyTmplt_Callback(hObject, eventdata, handles)
% hObject    handle to mn_CopyTmplt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% --------------------------------------------------------------------

handles = impro_copyTmpltL2R(hObject, handles);
guidata(hObject, handles);


function mn_AutoMatch_Callback(hObject, eventdata, handles)
% hObject    handle to mn_AutoMatch (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles = impro_autoMatch(hObject, handles);
% update handles variables
guidata(hObject,handles);

% --------------------------------------------------------------------
function mn_ManualMatch_Callback(hObject, eventdata, handles)
% hObject    handle to mn_ManualMatch (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles = impro_manualMatch(hObject, handles);
% update handles variables
guidata(hObject,handles);

% --------------------------------------------------------------------
function mn_Triangulation_Callback(hObject, eventdata, handles)
% hObject    handle to mn_Triangulation (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles = impro_CtrlPointsTriangulation( hObject, handles );
guidata(hObject, handles); 


% --------------------------------------------------------------------
function mn_ShowErr_Callback(hObject, eventdata, handles)
% hObject    handle to mn_ShowErr (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

impro_ShowError(hObject, handles); 

function mn_InterpQ4_Callback(hObject, eventdata, handles)
% hObject    handle to mn_InterpQ4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles = impro_InterpQ4(hObject, handles); 
guidata(hObject, handles); 


% --------------------------------------------------------------------
function mn_Rectification_Callback(hObject, eventdata, handles)
% hObject    handle to mn_Rectification (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function mn_Rectf_Plane_Callback(hObject, eventdata, handles)
% hObject    handle to mn_Rectf_Plane (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles = impro_Rectf_Plane(hObject, handles); 
guidata(hObject, handles); 


% --------------------------------------------------------------------
function mn_Rectf_Cylinder_Callback(hObject, eventdata, handles)
% hObject    handle to mn_Rectf_Cylinder (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles = impro_Rectf_Cylinder(hObject, handles); 
guidata(hObject, handles); 


% --------------------------------------------------------------------
function mn_Rectf_Lplane_Callback(hObject, eventdata, handles)
% hObject    handle to mn_Rectf_Lplane (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles = impro_Rectf_Lplane(hObject, handles); 
guidata(hObject, handles); 


% --------------------------------------------------------------------
function mn_FieldAnalysis_Callback(hObject, eventdata, handles)
% hObject    handle to mn_FieldAnalysis (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function mn_FieldAnalysis_Plane_Callback(hObject, eventdata, handles)
% hObject    handle to mn_FieldAnalysis_Plane (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles = impro_fieldAnalysis_Plane(hObject, handles);

guidata(hObject, handles);


% --------------------------------------------------------------------
function mn_FieldAnalysis_Cylinder_Callback(hObject, eventdata, handles)
% hObject    handle to mn_FieldAnalysis_Cylinder (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles = impro_fieldAnalysis_Cylinder(hObject, handles);

guidata(hObject, handles);


% --------------------------------------------------------------------
function mn_FieldAnalysis_Lplane_Callback(hObject, eventdata, handles)
% hObject    handle to mn_FieldAnalysis_Lplane (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles = impro_fieldAnalysis_Lplane(hObject, handles);

guidata(hObject, handles);


% --------------------------------------------------------------------
function mn_PickPoint_Callback(hObject, eventdata, handles)
% hObject    handle to mn_PickPoint (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles = impro_pbPickPoint(hObject, handles);

guidata(hObject, handles);


% --------------------------------------------------------------------
function mn_CreateFileList_Callback(hObject, eventdata, handles)
% hObject    handle to mn_CreateFileList (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles = impro_CreateList(hObject, handles);

guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function axTmpltLeft_CreateFcn(hObject, eventdata, handles)
% hObject    handle to axTmpltLeft (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate axTmpltLeft


% --- If Enable == 'on', executes on mouse press in 5 pixel border.
% --- Otherwise, executes on mouse press in 5 pixel border or over pb_calcRigidDisp.
function pb_calcRigidDisp_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to pb_calcRigidDisp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- If Enable == 'on', executes on mouse press in 5 pixel border.
% --- Otherwise, executes on mouse press in 5 pixel border or over pbGetFileList.
function pbGetFileList_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to pbGetFileList (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on popup-menu callback in popmenuMatchMethodLeft.
function popmenuMatchMethodLeft_Callback(hObject, eventdata, handles)
% hObject    handle to popmenuMatchMethodLeft (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
matchMethodValue = get(handles.popmenuMatchMethodLeft, 'Value'); 
matchMethodsStrings = get(handles.popmenuMatchMethodLeft, 'String'); 
handles.matchMethod = matchMethodsStrings{matchMethodValue}; 
set(handles.popmenuMatchMethodRigt, 'Value', matchMethodValue);
fprintf('Set template method to %s\n', handles.matchMethod); 
guidata(hObject, handles); 

% --- Executes on popup-menu callback in popmenuMatchMethodLeft.
function popmenuTmpltSizeLeft_Callback(hObject, eventdata, handles)
% hObject    handle to popmenuTmpltSizeLeft (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
theTmpltSizeOption = get(handles.popmenuTmpltSizeLeft, 'Value'); 
strArray = get(handles.popmenuTmpltSizeLeft, 'String');
handles.TmpltSize = str2num(strArray{theTmpltSizeOption});
set(handles.popmenuTmpltSizeRigt, 'Value', theTmpltSizeOption);
fprintf('Set template size to %d\n', handles.TmpltSize); 
guidata(hObject, handles); 

% --- Executes on popup-menu callback in popmenuNPointLeft.
function popmenuNPointLeft_Callback(hObject, eventdata, handles)
% hObject    handle to popmenuNPointLeft (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
theNPointOption = get(handles.popmenuNPointLeft, 'Value'); 
strArray = get(handles.popmenuNPointLeft, 'String');
handles.nPoint = str2num(strArray{theNPointOption});
set(handles.popmenuNPointRigt, 'Value', theNPointOption);
fprintf('Set # of ctrl points to %d\n', handles.nPoint); 
set(handles.slPoint,'Max',handles.nPoint);
set(handles.slPoint, 'SliderStep', [1./(handles.nPoint-1) 1./(handles.nPoint-1)] );


guidata(hObject, handles); 

% --- Executes on popup-menu callback in popmenuTmSearchRangeXLeft.
function popmenuTmSearchRangeXLeft_Callback(hObject, eventdata, handles)
% hObject    handle to popmenuTmSearchRangeXLeft (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
searchRangeXOption = get(handles.popmenuTmSearchRangeXLeft, 'Value'); 
strArray = get(handles.popmenuTmSearchRangeXLeft, 'String');
handles.searchRangeX = str2num(strArray{searchRangeXOption});
set(handles.popmenuTmSearchRangeXRigt, 'Value', searchRangeXOption);
fprintf('Set template match search range (X) to %d\n', ... 
         handles.searchRangeX); 
guidata(hObject, handles); 

% --- Executes on popup-menu callback in popmenuTmSearchRangeYLeft.
function popmenuTmSearchRangeYLeft_Callback(hObject, eventdata, handles)
% hObject    handle to popmenuTmSearchRangeYLeft (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
searchRangeYOption = get(handles.popmenuTmSearchRangeYLeft, 'Value'); 
strArray = get(handles.popmenuTmSearchRangeYLeft, 'String');
handles.searchRangeY = str2num(strArray{searchRangeYOption});
set(handles.popmenuTmSearchRangeYRigt, 'Value', searchRangeYOption);
fprintf('Set template match search range (Y) to %d\n', ... 
         handles.searchRangeY); 
 guidata(hObject, handles); 

% --- Executes on button press in pbRefreshCtrlPointStatus.
function pbRefreshCtrlPointStatus_Callback(hObject, eventdata, handles)
% hObject    handle to pbRefreshCtrlPointStatus (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles = impro_refreshCtrlPointsStatus(hObject, handles); 
fprintf('Refreshed ctrl points status (C:Complete; i:Incomplete; .:Not available.)\n'); 
guidata(hObject, handles); 

% --- Executes on button press in pbRefreshCalibStatus.
function pbRefreshCalibStatus_Callback(hObject, eventdata, handles)
% hObject    handle to pbRefreshCalibStatus (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles = impro_refreshCalibStatus(hObject, handles); 
fprintf('Refreshed calibration data.\n'); 
guidata(hObject, handles); 

% --- Executes on slider movement.
function slProjAlpha_Callback(hObject, eventdata, handles)
% hObject    handle to slPair (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
alpha = get(handles.slProjAlpha, 'Value'); 
set(handles.txProjAlpha, 'String', sprintf('Projected transpar. alpha: %.2f', alpha)); 
% update handles variables
guidata(hObject, handles);


% --- Executes on button press in pbRefreshMatchedPointStatus.
function pbRefreshMatchedPointStatus_Callback(hObject, eventdata, handles)
% hObject    handle to pbRefreshMatchedPointStatus (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles = impro_refreshMatchedPointsStatus(hObject, handles); 
fprintf('Refreshed matched points status (C:Complete; i:Incomplete; .:Not available.)\n'); 
guidata(hObject, handles); 


% --- Executes on button press in pb_Trajectory
function pb_Trajectory_Callback(hObject, eventdata, handles)
% hObject    handle to pb_Trajectory_Callback (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
impro_plotTrajectory(hObject, handles); 
guidata(hObject, handles); 



% --- Executes on ckShowProjectedSurfaceMesh
function ck_ShowProjectedSurfaceMesh_Callback(hObject, eventdata, handles)
% hObject    handle to pb_Trajectory_Callback (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
impro_ckShowProjectedSurfaceMesh_showWarning(hObject, handles); 
sprintf('got it');
guidata(hObject, handles); 

% --------------------------------------------------------------------
function mn_DamageIndex_Callback(hObject, eventdata, handles)
% hObject    handle to mn_DamageIndex (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


function mn_DamageIndex_FractalBasic_Callback(hObject,eventdata, handles)
impro_damageIndexFractalBasic(hObject, handles); 

function mn_DamageIndex_Fractal_m1_Callback(hObject,eventdata, handles)
impro_damageIndexFractal_m1(hObject, handles); 

function mn_DamageIndex_CrackAmount_Callback(hObject,eventdata, handles)
impro_damageIndexCrackAmount(hObject, handles); 

function mn_DamageIndex_CrackAmount_F0_S4590135_Callback(hObject,eventdata, handles)
impro_damageIndexCrackAmount_F0_S4590135(hObject, handles); 

function mn_DamageIndex_CrackAmountOverFractalM1_Callback(hObject,eventdata, handles)
impro_damageIndexCrackAmountOverFractal(hObject, handles); 

% --------------------------------------------------------------------
function mn_Synchronization_Callback(hObject,eventdata,handles)
handles = impro_interactive_sync_all_points(handles);
guidata(hObject, handles); 


