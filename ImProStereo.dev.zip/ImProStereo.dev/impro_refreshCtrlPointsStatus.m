function handles = impro_refreshCtrlPointsStatus(hObject, handles)
return
% This function refreshes the control points status indicator
% check if control points are defined or not. Show C/i/.
%   C:Complete   - has sufficient template files, pckXy, refXy, and 
%                  template size is the same as system setting
%   i:Incomplete - has insufficient template files, pckXy, refXy, or
%                  template size is not the same as system setting
%   .:Not available - no data
ctrlStringArray{handles.nPair + 1} = {}; % pre-locate the cell array
ctrlStringArray{1} = 'Ctrl Points Status';
for iPair = 1: handles.nPair
  ctrlStringArray{iPair + 1} = strcat(sprintf('Pair%03d:', iPair), ...
                               repmat('.', 1, handles.nPoint), ...
                          '_', repmat('.', 1, handles.nPoint) );
end
set(handles.popmenuCtrlPointsStatus, 'String', ctrlStringArray);

for iPair = 1: handles.nPair
  for iLR = 1: handles.nLR  
    checkFileExist = 0;
    % Check the template data file
%    if ( exist([handles.TmpltPath{iLR} handles.filelistTmplt{iPair,iLR}], 'file') )
    if ( exist([handles.TmpltPath{iLR} handles.filelistTmplt{iPair,iLR}], 'file') == 2) % modified by vince 2017/07/20
      iTmplt = load([handles.TmpltPath{iLR} handles.filelistTmplt{iPair,iLR}]);
      % the file exists             
      checkFileExist = 1;
      % check template size for each iPoint
      for iPoint = 1: min(iTmplt.iTmplt.nPoint, handles.nPoint) 
        % check template exists or not (added by vince 12 Aug 2014) 
        if (size(handles.iTmplt, 2) < iLR) 
            handles.iTmplt{iLR} = iTmplt.iTmplt;
        end
        % read template image
        checkTmpltSize = 0;
        try 
            if ( exist([handles.TmpltPath{iLR} handles.iTmplt{iLR}.file{iPoint}], 'file') == 2) % modified by vince 2017/07/20 
                iTmpltImg = imread([handles.TmpltPath{iLR} handles.iTmplt{iLR}.file{iPoint}]);
            else
                continue;
            end
        end
        if (size(iTmpltImg,1) == handles.TmpltSize) 
          checkTmpltSize = 1;
        end  % end of if template size checking
        if (checkFileExist > 0) 
            strIndex = 8 + (iLR - 1) * (handles.nPoint + 1) + iPoint; 
            if (checkTmpltSize > 0) 
                ctrlStringArray{iPair + 1}(strIndex) = 'C';            
            else
                ctrlStringArray{iPair + 1}(strIndex) = 'i';
            end
        end  % end of if incomplete
      end  % end of for iPoint = 1: min(iTmplt.iTmplt.nPoint, handles.nPoint)   
    end  % end of if exist([handles.TmpltPath{iLR} handles.filelistTmplt{iPair,iLR}]
  end  % end of for iLR = 1: handles.nLR  
  if (mod(iPair,100) == 0)
      fprintf('Checking CtrlPoint Status (impro_refreshCtrlPointsStatus): iPair %d\n', iPair); 
  end
end  % end of for iPair = 1: handles.nPair 

set(handles.popmenuCtrlPointsStatus, 'String', ctrlStringArray);
end





