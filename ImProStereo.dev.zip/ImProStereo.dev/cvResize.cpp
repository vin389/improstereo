/*
 * =============================================================
   Matlab interface of image resize function .
   
   function imgR = cvResize( imgOri, rWidth, rHeight )
   
     Input:
       imgOri:   original image  (size: height x width x 3 (depth)) 
       rWidth:   demand width of the resized image
       rHeight:  demand height of the resized image
     Output:
       imgR:     resized image.
       
   Developed by Yuan-Sen Yang
   Date: 2008.09.18 

 * =============================================================
 */
     
#include <mex.h>
#include "opencv2\opencv.hpp"   /* Includes all OpenCV2 header files */
//#include "inc\cv.h"
//#include "inc\cxcore.h"

void mexFunction( int nlhs, mxArray *plhs[],int nrhs, const mxArray *prhs[])
{
  /* Check for proper number of arguments. */
  if (nrhs != 3) {
    mexErrMsgTxt("arguments: imgOri, resizeWidth, resizeHeight");
  } else if (nlhs > 1) {
    mexErrMsgTxt("Too many output arguments");
  }
  
  /* original image buffer pointer */
  uchar* imdata = (uchar*)mxGetPr(prhs[0]); 
  int width=  (int) mxGetN(prhs[0])/3;
  int height= (int) mxGetM(prhs[0]);
  int nChannels = 3;  /* must be 3. Or this function would collapse */ 
  int depth = 8;      /* must be 8. Or this function would collapse */ 

  int rWidth  = (int) mxGetScalar(prhs[1]);
  int rHeight = (int) mxGetScalar(prhs[2]);

  CvSize size = cvSize(width, height);
  IplImage* image = cvCreateImage(size, depth, nChannels);

  int i, j;

  /* copy the image from MATLAB format to OpenCV format */ 
  for(j = 0; j < height; j++) {
    for(i = 0; i < width; i++) {
      (image->imageData + image->widthStep * j) [i*3+0] = imdata[j + i * height + width * height * 2];
      (image->imageData + image->widthStep * j) [i*3+1] = imdata[j + i * height + width * height * 1];
      (image->imageData + image->widthStep * j) [i*3+2] = imdata[j + i * height + width * height * 0];
  } }

  /* create memory space for resized image */
  CvSize size_resize = cvSize(rWidth, rHeight);
  IplImage* image_resize = cvCreateImage(size_resize, depth, nChannels);

  /* resize */
  cvResize(image, image_resize, CV_INTER_CUBIC );

  /* copy the image from OpenCV format to MATLAB format */ 
  mwSize bufdim[3] = { rHeight, rWidth, nChannels} ;
/*  plhs[0] = mxCreateNumericMatrix(buflen, 1, mxUINT8_CLASS, mxREAL); */
  plhs[0] = mxCreateNumericArray(3, bufdim, mxUINT8_CLASS, mxREAL); 
  uchar* buffer_resize = (uchar*)mxGetPr(plhs[0]);

  for(j = 0; j < rHeight; j++) {
    for(i = 0; i < rWidth; i++) {
      buffer_resize[j + i * rHeight + rWidth * rHeight * 2] = (image_resize->imageData + image_resize->widthStep * j) [i*3+0]; 
      buffer_resize[j + i * rHeight + rWidth * rHeight * 1] = (image_resize->imageData + image_resize->widthStep * j) [i*3+1]; 
      buffer_resize[j + i * rHeight + rWidth * rHeight * 0] = (image_resize->imageData + image_resize->widthStep * j) [i*3+2]; 
  } }
  
  cvReleaseImage(&image);
  cvReleaseImage(&image_resize);
}
