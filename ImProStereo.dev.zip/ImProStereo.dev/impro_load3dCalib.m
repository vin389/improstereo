function handles = impro_load3dCalib(hObject, handles)
% hObject    handle to pbPickPoint (see GCBO)
% handles    structure with handles and user data (see GUIDATA)

    [handles.CalibFile handles.CalibPath] = uigetfile('*.mat', 'Press Cancel to manually input');
    if ( isnumeric(handles.CalibFile) && isnumeric(handles.CalibPath) ) 
        try
            fc_left = handles.calib3d.fc_left;
            cc_left = handles.calib3d.cc_left;
            kc_left = handles.calib3d.kc_left;
            fc_right = handles.calib3d.fc_right;
            cc_right = handles.calib3d.cc_right;
            kc_right = handles.calib3d.kc_right;
            if isfield(handles.calib3d, 'omc_left_user')
                omc_left_user = handles.calib3d.omc_left_user;
            else 
                omc_left_user = [0;0;0]
            end
            if isfield(handles.calib3d, 'Tc_left_user')
                Tc_left_user = handles.calib3d.Tc_left_user;
            else
                Tc_left_user = [0;0;0];
            end
            if isfield(handles.calib3d, 'omc_right_user')
                omc_right_user = handles.calib3d.omc_right_user;
            else 
                omc_right_user = rodrigues(handles.calib3d.R); 
            end
            if isfield(handles.calib3d, 'Tc_right_user')
                Tc_right_user = handles.calib3d.Tc_right_user;
            else
                Tc_right_user = handles.calib3d.T;
            end
        catch 
            fc_left = [2000 2000];
            cc_left = [959.5 539.5];
            kc_left = [-.1 0 0 0 0];
            fc_right = [2000 2000];
            cc_right = [959.5 539.5];
            kc_right = [-.1 0 0 0 0];
            omc_left_user = [0;0;0];
            Tc_left_user = [0;0;0];
            omc_right_user = [0;0;0];
            Tc_right_user = [-1000;0;0];            
        end
        % manual input 
       prompt={'Left fx fy cx cy', ...
               'Left k1 k2 p1 p2 k3', ...
               'Left R-mat', ...
               'Left T-vec', ...
               'Right fx fy cx cy', ...
               'Right k1 k2 p1 p2 k3', ...
               'Right R-mat', ...
               'Right T-vec' };
       name='Input calibration parameters';
       numlines=1;
       defaultanswer={num2str([fc_left(1) fc_left(2) cc_left(1) cc_left(2)]), ...
                      num2str([kc_left(1) kc_left(2) kc_left(3) kc_left(4) kc_left(5)]), ...
                      mat2str(rodrigues(omc_left_user)), ...
                      mat2str(Tc_left_user), ...
                      num2str([fc_right(1) fc_right(2) cc_right(1) cc_right(2)]), ...
                      num2str([kc_right(1) kc_right(2) kc_right(3) kc_right(4) kc_right(5)]), ...
                      mat2str(rodrigues(omc_right_user)), ...
                      mat2str(Tc_right_user)}; 
       options.Resize='on';
       options.WindowStyle='normal';
       calib_input = inputdlg(prompt,name,numlines,defaultanswer,options);
       if isempty(calib_input) 
           return
       end
       % left cam intrinsic
       tmp = str2num(calib_input{1}); 
       handles.calib3d.fc_left = [tmp(1) tmp(2)]; 
       handles.calib3d.cc_left = [tmp(3) tmp(4)]; 
       tmp = str2num(calib_input{2}); 
       handles.calib3d.kc_left = [tmp(1) tmp(2) tmp(3) tmp(4) tmp(5)]; 
       handles.calib3d.alpha_c_left = 0; 
       % left cam extrinsic
       tmp1 = eval(calib_input{3}); 
       tmp2 = eval(calib_input{4}); 
       rmat_left = eye(4); 
       rmat_left(1:3,1:3) = tmp1;
       rmat_left(1:3,4) = tmp2;
       handles.calib3d.omc_left_user = rodrigues(rmat_left(1:3, 1:3)); 
       handles.calib3d.Tc_left_user = rmat_left(1:3, 4); 
       % right cam intrinsic
       tmp = str2num(calib_input{5}); 
       handles.calib3d.fc_right = [tmp(1) tmp(2)]; 
       handles.calib3d.cc_right = [tmp(3) tmp(4)]; 
       tmp = str2num(calib_input{6}); 
       handles.calib3d.kc_right = [tmp(1) tmp(2) tmp(3) tmp(4) tmp(5)]; 
       handles.calib3d.alpha_c_right = 0; 
       % right cam extrinsic
       tmp1 = eval(calib_input{7}); 
       tmp2 = eval(calib_input{8}); 
       rmat_right = eye(4); 
       rmat_right(1:3,1:3) = tmp1;
       rmat_right(1:3,4) = tmp2;
       handles.calib3d.omc_right_user = rodrigues(rmat_right(1:3, 1:3)); 
       handles.calib3d.Tc_right_user = rmat_right(1:3, 4); 
       % stereo 
       rmat44 = rmat_right * inv(rmat_left); 
       handles.calib3d.R = rmat44(1:3, 1:3);
       handles.calib3d.om = rodrigues(handles.calib3d.R);
       handles.calib3d.T = rmat44(1:3, 4);
       % define coord. sys
       coordID = 2; 
       for iPair = 1: handles.nPair
           handles.CoordSys{iPair,coordID} = rmat44; 
       end
       handles = impro_refreshCalibStatus(hObject, handles); 
    else
        calib3d = load([handles.CalibPath handles.CalibFile]);
        handles.calib3d = calib3d; 
        handles = impro_refreshCalibStatus(hObject, handles); 
    end

end