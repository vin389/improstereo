function handles = impro_fieldAnalysis(hObject, handles)

% Estimate paremeters M and N (# of cells) according to size of 
% measurement region of Pair 1 Left. 

measureWidth  = handles.rectfMeasureRange(1, 1, 2) - ...
                handles.rectfMeasureRange(1, 1, 1) + 1; 
measureHeight = handles.rectfMeasureRange(1, 1, 4) - ...
                handles.rectfMeasureRange(1, 1, 3) + 1; 
MN = 1500;  % Make estimated M*N is about MN (say 1000, M=25 and N=40)
              
estM = round( measureHeight*sqrt(MN/(measureWidth*measureHeight)) );
estN = round( measureWidth *sqrt(MN/(measureWidth*measureHeight)) );

% Ask user to input range of field analysis
inpans = inputdlg( {'Range of Pair'   ...
  'Range of iLR'    ...
  'M (# of cells along Y)', ...
  'N (# of cells along X)', ...
  'TM zoom factor' }, ...
  'Range of field analysis', 1, ...
  { ['2:'  num2str(handles.nPair) ] ...
  ['1:'  num2str(handles.nLR)   ] ...
  num2str(estM) num2str(estN) '20' } );

% If user press CANCEL, this function returns. 
if ( size(inpans,1) < 1 )
  return
end

% Get inputs. 
iPairRange  = str2num(inpans{1});
iLRRange    = str2num(inpans{2});
M           = str2num(inpans{3});
N           = str2num(inpans{4});
ZmFct       = str2num(inpans{5});

% Loop for iLR
for iLR = iLRRange
  % Load rectified image of Pair 1 from file and save to variable iRectfImg
  iPair = 1;
  [handles, imgInitial] = impro_loadRectf(hObject, handles, iPair, iLR);
  
  % Loop for iPair
  for iPair = iPairRange
    
    [handles, imgDeformd] = impro_loadRectf(hObject, handles, iPair, iLR);
    initPair = 1;
    rangeTracing(1:4) = handles.rectfMeasureRange( initPair, iLR, 1:4 );
    options.M     = M;
    options.N     = N;
    options.Mu    = M;
    options.Nu    = N;
    options.ZmFct = ZmFct;
    options.rangeMatching = [20 20 20 20 ]; % A guess for NDP4 (CYCU 1/4)
    
    % plane disp/strain analysis
    [uxGrid,uyGrid,strain2Dxx,strain2Dyy,strain2Dxy,xGrid,yGrid, infoTM ] = ...
      impro_planeStrain20(imgInitial, imgDeformd, rangeTracing, options);
    
    % output the analysis result
    impro_3dMeshStrain( hObject, handles, iPair, iLR, ...
                        uxGrid, uyGrid, strain2Dxx, strain2Dyy, ...
                        strain2Dxy, ...
                        xGrid, yGrid, ...
                        infoTM );
    
    % end of iPair loop
  end
  
  % end of iLR loop
end





end
