clear all; 

prev = imread('D:\ExpDataExamples\2011-SingleColumn.NCREE\20110503\Casio_w\left\CIMG0108.jpg');
curr = imread('D:\ExpDataExamples\2011-SingleColumn.NCREE\20110503\Casio_w\left\CIMG0480.jpg');
% prev = imread('C:\NDP4\CY2_NDP4\left\RECTF_001.JPG');
% curr = imread('C:\NDP4\CY2_NDP4\left\RECTF_005.JPG');

imgPrevWidth  = size(prev,2);
imgPrevHeight = size(prev,1);
imgCurrWidth  = size(curr,2);
imgCurrHeight = size(curr,1);



prevPyr = zeros( 1, fix(((imgPrevWidth+8)*(imgPrevHeight+2)+3)/3), 'int8' ); 
currPyr = zeros( 1, fix(((imgCurrWidth+8)*(imgCurrHeight+2)+3)/3), 'int8' ); 

cellstep = 25;

xx = cellstep:cellstep:imgPrevWidth -cellstep;
yy = cellstep:cellstep:imgPrevHeight-cellstep;

[xgrid,ygrid] = meshgrid(xx,yy);
xxcol = xgrid(:); yycol=ygrid(:); 
nFeatures = size(xxcol,1);

prevFeatures(1,:) = xxcol;
prevFeatures(2,:) = yycol;

count = size(prevFeatures, 2); 
winSize = [21 21];
level = 3; 
criteria = [ 1 20 1e-4 ]; 
flags = 8; 

tic; 
[prevPyr, currPyr, currFeatures, status, track_error] = ...
            cvCalcOpticalFlowPyrLK( prev, curr, ...
                                    prevPyr, currPyr, ...
                                    prevFeatures, ...
                                    count, winSize, level, ...
                                    criteria, flags ); 
toc; 

disp = currFeatures - prevFeatures; 

dispUx = reshape(disp(1,:), size(xgrid));
dispUy = reshape(disp(2,:), size(xgrid));
% errU   = reshape(track_error, size(xgrid)) / nFeatures; 
% errU   = reshape(track_error, size(xgrid)) / sqrt(winSize(1)*winSize(2)) / 256; 
errU   = reshape(track_error, size(xgrid));
statuU = reshape(status, size(xgrid)); 

figure; 
subplot(1,4,1); imagesc(dispUx, [-20 20]); colorbar; axis image;  
subplot(1,4,2); imagesc(dispUy, [-20 20]); colorbar; axis image; 
subplot(1,4,3); imagesc(errU            ); colorbar; axis image; 
subplot(1,4,4); imagesc(statuU          ); colorbar; axis image; 


