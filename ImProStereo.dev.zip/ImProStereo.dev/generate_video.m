function generate_video()

[files,directory] = uigetfile({'*.jpg', 'JPG-files (*.jpg)'}, 'Pick JPG files that you want to put in video', 'MultiSelect', 'on');

% if user clicks Cancel
if (~iscell(files))
    return;
end

% get video parameter
user_input = inputdlg({'Video file' 'FPS' 'COMPRESSION' ...
                       'QUALITY' 'KEYFRAME'}, ...
                       'Input parameter for the video (Indeo3, Indeo5, Cinepak, MSVC, RLE, None', 1, ...
                       {'MyVideoName.avi' '30'  'Cinepak' '95' '1'}); 
                   
if (isempty(user_input))
    return;
end

filename    = user_input{1}; 
fps         = user_input{2};
compression = user_input{3};
quality     = user_input{4};
keyframe    = user_input{5};

% open file
try 
    aviobj = avifile([directory filename], 'FPS', eval(fps), ...
                     'COMPRESSION', compression, ...
                     'QUALITY', eval(quality), 'KEYFRAME', eval(keyframe) ); 

    % for each jpg file, read image and add frames
    nfiles  = max(size(files, 2)); 

    for i = 1: nfiles
        if (i == 1) 
            hwait = waitbar(0,'Generating video ...');
        end
        fullpathname = [directory files{i}];
        img = imread(fullpathname); 
        aviobj = addframe(aviobj, img);
        waitbar(i / nfiles, hwait); 
    end    % end of for each file

    close(aviobj); 
catch
    if (exist('aviobj', 'var')) 
        aviobj = close(aviobj); 
    end
    if (exist('hwait', 'var'))
        close(hwait); 
    end
    fprintf('Failed to write video file.\n');
end
    
end 
