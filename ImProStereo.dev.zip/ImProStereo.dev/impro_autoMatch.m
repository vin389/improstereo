function handles = impro_autoMatch(hObject, handles)

useInitialTemplate = 1; 

% Ask user to input range of matching
inpans = inputdlg( {'Range of Pair'   ...
                    'Range of iLR'    ...
                    'Range of Point'  ...
                    'Search DX'       ...
                    'Search DY'    }, ...
        'Range of auto matching', 1, ...
                   { ['1:'  num2str(handles.nPair) ] ...
                     ['1:'  num2str(handles.nLR)   ] ...
                     ['1:'  num2str(handles.nPoint)] ...
                      '50'  ...
                      '50' } );
if ( size(inpans,1) < 1 ) 
  return
end

iPairRange  = str2num(inpans{1});
iLRRange    = str2num(inpans{2});
iPointRange = str2num(inpans{3});
Dx          = str2num(inpans{4});  
Dy          = str2num(inpans{5});  

for iPair = iPairRange
  for iLR = iLRRange
    for iPoint = iPointRange
      
      % Run template matching and save the matched data
      handles = impro_TmpltMatch(hObject, handles, iPair, iLR, iPoint, ...
                Dx, Dy);
      if (useInitialTemplate == 1)
        % Copy the template data to the template of next pair
        handles = impro_copyTmplt2Tmplt(hObject, handles, iPair, iLR, iPoint );      
      else
        % Copy the matched data to the template of next pair
        handles = impro_copyMatch2Tmplt(hObject, handles, iPair, iLR, iPoint );      
      end

    end
  end
end

end