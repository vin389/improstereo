function [crack_opening crack_sliding] = ...
    impro_crackField(uxGrid, uyGrid, theta)
%impro_crackField
% calculates crack fields, including crack opening and crack sliding.
%   Input arguments:
%     uxGrid/uyGrid: displacement fields.  (in pixel)
%                    size: Mu by Nu.  Mu/Nu: number of rows/columns of 
%                          the displacement field grid.
%     theta:         the crack angle (in degree)

theta = mod(theta, 180); % theta is between 0 and 179.999...

mat_cr(2,2) = sin(theta * pi / 180);
mat_cr(1,2) = cos(theta * pi / 180);
mat_cr(1,1) = cos(theta * pi / 180 + pi / 2);
mat_cr(2,1) = sin(theta * pi / 180 + pi / 2);
    
inv_mat_cr = inv(mat_cr); 
    
M = size(uxGrid, 1); 
N = size(uxGrid, 2); 

crack_opening = zeros(M, N);
crack_sliding = zeros(M, N);

for i=1:M
   for j=1:N
      % calculate ux_left, uy_left, ..., ux_down, uy_down
      if (j > 1) % not left bound (normal)
          ux_left = uxGrid(i,j-1);  
          uy_left = uyGrid(i,j-1);
      else       % left bound (special case)
          ux_left = uxGrid(i,j);  
          uy_left = uyGrid(i,j);
      end
      if (j < N) % not right bound (normal)
          ux_rigt = uxGrid(i,j+1); 
          uy_rigt = uyGrid(i,j+1); 
      else       % right bound (special case)
          ux_rigt = uxGrid(i,j); 
          uy_rigt = uyGrid(i,j);
      end
      if (i > 1) % not upper bound (normal)
          ux_up__ = uxGrid(i-1,j);
          uy_up__ = uyGrid(i-1,j);
      else       % upper bound (special case)
          ux_up__ = uxGrid(i,j);
          uy_up__ = uyGrid(i,j);
      end
      if (i < M) % not lower bound (normal)
          ux_down = uxGrid(i+1,j); 
          uy_down = uyGrid(i+1,j);
      else
          ux_down = uxGrid(i,j); 
          uy_down = uyGrid(i,j);          
      end
      % Calclate uax, uay, ubx, uby
      c = cos(theta);
      s = sin(theta);
      if (theta >= 0 && theta < 90) 
          uax = (ux_up__ * c + ux_left * s) / (c + s); 
          uay = (uy_up__ * c + uy_left * s) / (c + s); 
          ubx = (ux_down * c + ux_rigt * s) / (c + s); 
          uby = (uy_down * c + uy_rigt * s) / (c + s); 
      else    
          uax = (-ux_down * c + ux_left * s) / (-c + s); 
          uay = (-uy_down * c + uy_left * s) / (-c + s); 
          ubx = (-ux_up__ * c + ux_rigt * s) / (-c + s); 
          uby = (-uy_up__ * c + uy_rigt * s) / (-c + s); 
      end
      % calculate crack opening and sliding
      u_vec = [ uax - ubx; uay - uby ];
      c_vec = inv_mat_cr * u_vec; 
      crack_opening(i,j) = c_vec(1);
      crack_sliding(i,j) = c_vec(2);
   end
end

end
