function handles = impro_saveTmplt(hObject, handles, iPair, iLR, ...
                   iPoint, iTmpltImg, pckXy, refXy )
% This function saves template image and data to file

% Create the folder if it does not exist
if ( ~exist(handles.TmpltPath{iLR}, 'dir') )
    mkdir(handles.TmpltPath{iLR});
end

% Load data from template file first if it exists, and 
% only modify data which are updated. 
if ( exist([handles.TmpltPath{iLR} handles.filelistTmplt{iPair,iLR}],'file') )
  iTmplt = load([handles.TmpltPath{iLR} handles.filelistTmplt{iPair,iLR}]);
  % handles.iTmplt = iTmplt.iTmplt;
  handles.iTmplt{iLR} = iTmplt.iTmplt; % Modified by vince. 2013/04/23
%            iTmplt{iLR} 
%            iTmplt{iLR}.nPoint   -- number of control points in each photo
%            iTmplt{iLR}.file{iP} -- file name of template image file (.JPG)
%            iTmplt{iLR}.refXy{iP}(1,1:2) -- picked point in template
end
handles.iTmplt{iLR}.nPoint = handles.nPoint;
tstr= handles.filelistTmplt{iPair,iLR};
handles.iTmplt{iLR}.file{iPoint} = [tstr(1:size(tstr,2)-4) ...
        sprintf('_Point%03d.jpg',iPoint)]; 
handles.iTmplt{iLR}.pckXy{iPoint}(1,1:2) = pckXy;      
handles.iTmplt{iLR}.refXy{iPoint}(1,1:2) = refXy;

% Save iTmplt to template file
% iTmplt = handles.iTmplt; 
iTmplt = handles.iTmplt{iLR}; % Modified by vince. 2013/04/23
save([handles.TmpltPath{iLR} handles.filelistTmplt{iPair,iLR}], 'iTmplt');
% Save image
imwrite( iTmpltImg, [handles.TmpltPath{iLR} handles.iTmplt{iLR}.file{iPoint}]...
    , 'Quality', 100); % Modified by vince. Set quality to 100. If use 
    % default quality, image error may accumulate. 
    % We assume the template image is small so that setting the quality to 
	% 100 would not increase disk space cost too much. 
	

end