function X = impro_Surface_XY( alpha, basepoint )
N = size(alpha,2);
X = zeros(3,N);
X(1,:)   = alpha(1,:) + basepoint(1);
X(2,:)   = alpha(2,:) + basepoint(2);
X(3,1:N) = basepoint(3);
end