/*
 * =============================================================
   Matlab interface of OpenCV canny (edge detection) function .
   The low threshold is 100. The initial high threshold is 1000 and gets
   smaller iteratively (times 0.999 each iteration). 
   The 1st found edge (with strongest edge contract) is 100.
   The 2nd found edge is 99, and so on. 
   If high <= low then this function returns.  
   
   function edges = cvCannyAuto( imgOri )
   
     Input:
       imgOri:   original image  (size: height x width x 3 (depth)) 
     Output:
       edges:    Single-channel (CV_8U or uint8) 
                 with the same size to imgOri
                 100: The 1st found edge.
                  99: The 2nd found edge.
                  98: The 3rd found edge....
       
   Developed by Yuan-Sen Yang
   Date: 2011.05.14

 * =============================================================
 */
     
#include <mex.h>
#include <matrix.h>
#include "opencv2\core\core.hpp"
#include "opencv2\imgproc\imgproc_c.h"
#include "opencv2\video\tracking.hpp"
#include "opencv2\highgui\highgui.hpp"

#include <stdlib.h>
#include <stdio.h>


double sumUcharCvMat( const CvMat* mat ) {
  double s = 0.0f;
  for(int row=0; row<mat->rows; row++ ) {
    const uchar * ptr = (const uchar*)(mat->data.ptr + row * mat->step);
    for( int col=0; col<mat->cols; col++ ) {
      s += (double)(*ptr++);
    }
  }
  return( s );
}

void zeroUcharCvMat( const CvMat* mat ) {
  for(int row=0; row<mat->rows; row++ ) {
    uchar * ptr = (uchar*)(mat->data.ptr + row * mat->step);
    for( int col=0; col<mat->cols; col++ ) {
      (*ptr++) = (uchar) 0;
    }
  }
}



void mexFunction( int nlhs, mxArray *plhs[],int nrhs, const mxArray *prhs[])
{
	
  /* Check for proper number of arguments. */
  if (nrhs < 1) {
    mexErrMsgTxt("arguments: imgOri");
  } 
  if (nlhs > 1) {
    mexErrMsgTxt("Too many output arguments");
  }
  
  /* get original image buffer pointer */
  
  uchar* imgOriMat    = (uchar*)mxGetPr(prhs[0]); 
  mwSize nDim         = mxGetNumberOfDimensions(prhs[0]);  
  const mwSize *imgDim   = mxGetDimensions(prhs[0]);
  int    imgWidth     = (int) imgDim[1];
  int    imgHeight    = (int) imgDim[0];
  int    imgDepth     = 8;  /* must be 8. Or this function would collapse */ 
  int    imgNChannels; 
  if ( nDim > 2 )
    imgNChannels = (int) imgDim[2];  
  else
    imgNChannels = 1; 
  
  /* create an openCV image space for source image
     and copy  matlab image (imgOriMat) to openCV image (imgOriOcv). 
     The openCV image (imgOriOcv) will be released before returning */
  
  CvMat*    imgOriOcv  = cvCreateMat(imgHeight, imgWidth, CV_8U);
  
    /* copy image from matlab format to OpenCV format */ 
  int i,j; 
  if ( imgNChannels == 3 ) 
  {
    for(j = 0; j < imgHeight; j++) {
      for(i = 0; i < imgWidth; i++) {
        imgOriOcv->data.ptr[j*imgWidth+i] = 
                (uchar) ((imgOriMat[j + i * imgHeight + imgWidth * imgHeight * 0] + 
                          imgOriMat[j + i * imgHeight + imgWidth * imgHeight * 1] +
                          imgOriMat[j + i * imgHeight + imgWidth * imgHeight * 2] )/3.+0.5); 
    } }
  }
  if ( imgNChannels == 1 ) 
  {
    for(j = 0; j < imgHeight; j++) {
      for(i = 0; i < imgWidth; i++) {
        imgOriOcv->data.ptr[j*imgWidth+i] = 
                (uchar) (imgOriMat[j + i * imgHeight] ); 
    } }
  }
  
  /* create an openCV image space for destination array.
     The created opencv image (edges) will be deleted before returning. */

  CvMat *  edges = cvCreateMat( imgOriOcv->height, imgOriOcv->width, CV_8U );
  CvMat *  neweg = cvCreateMat( imgOriOcv->height, imgOriOcv->width, CV_8U );
  zeroUcharCvMat( edges ); 
  
  /* call opencv canny function */
  /*  OpenCV function interface:
            void cvCanny( const CvArr* image,
                 CvArr* edges,
                 double threshold1,
                 double threshold2,
                 int aperture size=3 );  */
  
  /* set low and initial high thresholds */

  double  lowThreshold   = 100.;
  double  highThreshold  = 1000.; 
  int     edgevalue      = 100; // initial edge value. 100 denotes the 1st
                                // found edge. 99 the 2nd, and so on. 
  double  edgsum =0.0, newsum;   
  while ( highThreshold > lowThreshold )
  {  
    cvCanny( imgOriOcv, neweg, lowThreshold, highThreshold );
    newsum = sumUcharCvMat( neweg );        
    
    if ( newsum != edgsum ) 
    {
      // update edges
      for(int row=0; row<edges->rows; row++ ) {
        uchar       * ptredg =       (uchar*)(edges->data.ptr + row * edges->step);
        const uchar * ptrnew = (const uchar*)(neweg->data.ptr + row * neweg->step);
        uchar uedg, unew; 
        for( int col=0; col<edges->cols; col++ ) {          
          uedg = *ptredg;
          unew = *ptrnew;
          // if it is a new edge pixel, update edges.
          if ( uedg == 0 && unew != 0 ) (*ptredg) = edgevalue;      
          ptredg++; ptrnew++; 
        }
      }
      edgevalue--;
      edgsum = newsum; 
    } // end if any new edge is found.
    highThreshold *= 0.999; 
  } // end of while loop; 
              
  /* create a matlab image (mxArray) and
     copy the generated openCV image to matlab image */
    /* mxREAL means there is no complex part */
  mwSize bufdim[2] = { imgHeight, imgWidth} ;
  plhs[0] = mxCreateNumericArray(2, bufdim, mxUINT8_CLASS, mxREAL);  
  
  /* copy the image from OpenCV format to matlab format */ 
  uchar* bufDesImg = (uchar*) mxGetPr(plhs[0]);

  for(j = 0; j < imgHeight; j++) {
    for(i = 0; i < imgWidth; i++) {
      bufDesImg[j + i * imgHeight] = (uchar) edges->data.ptr[j*imgWidth+i]; 
  } }
    
  /* release opencv images */
  cvReleaseMat(&imgOriOcv);
  cvReleaseMat(&edges);
  
}
