function handles = impro_3dMeshStrain( hObject, handles, iPair, iLR, ...
                        uxGrid, uyGrid, strain2Dxx, strain2Dyy, ...
                        strain2Dxy, ...
                        xGrid, yGrid, ...
                        infoTM )
% This function generates 3D mesh of the measured results
% plots the surface on the photos.  

% Check
if ( isfield( handles, 'calib3d') == 0 )
  msgbox('Load 3D Calib Data first.','Warning');
  return;
end

% Find axes of the cylinder system
iCtrlPoint3D(:,:) = handles.CtrlPoints3D(handles.iPair,1,:,:);
% Find the cylinder sys.
[vx,vy,vz,ori,R,th1,th2,h1,h2] = impro_cylinderSys( iCtrlPoint3D );
% Find mesh of the cylinder face (theta=th1~th2) (height=h1~h2)
m=size(uxGrid,1); 
n=size(uxGrid,2);
[vtx faces] = impro_cylinFace(vx,vy,vz,ori,R,th1,th2,h1,h2, m, n);
% Convert to image coord and set active axes object. 
hh=figure; pcolor(uxGrid); close(hh);
set(handles.slPair, 'Value', iPair);
handles.iPair = iPair;
handles = impro_updSlPair(hObject,handles);
if (iLR==1) 
  [xp] = project_points2( ...
    vtx', [0 0 0], [0;0;0], handles.calib3d.fc_left, ...
    handles.calib3d.cc_left, handles.calib3d.kc_left, ...
    handles.calib3d.alpha_c_left );
  axes(handles.axPhotoLeft);
  xp = [xp' zeros(size(xp,2),1)];
end  
if (iLR==2)
  %  Right
  [xp] = project_points2( ...
    vtx', handles.calib3d.om, handles.calib3d.T, ...
    handles.calib3d.fc_right, ...
    handles.calib3d.cc_right, handles.calib3d.kc_right, ...
    handles.calib3d.alpha_c_right );
  axes(handles.axPhotoRigt);
  xp = [xp' zeros(size(xp,2),1)];
end

% Plot strain2Dyy
% The strain2Dyy is in image coord. and therefore is upside down.
% We need to flip it before plotting. 

pFieldFilter = strain2Dyy; 
%pFieldFilter = uyGrid; 
% filter values that are out of user-defined range (1/4/2014 by vince) 
filterMin = str2num(get(handles.edVisibleMatchRangeMin, 'String'));
filterMax = str2num(get(handles.edVisibleMatchRangeMax, 'String'));
pFieldFilter(or(infoTM.Acc < filterMin, infoTM.Acc > filterMax)) = nan; 
%pFieldFilter( infoTM.Acc < 0.97 ) = nan; 
icount=0;
for im=m:-1:1
  for in=1:n
    icount=icount+1;
    pField(icount) = pFieldFilter(im,in);
  end
end
% Set colormap and caxis range
thecolormap = colormap('jet');
% graycolormap(1:64,:) = graycolormap(64:-1:1,:);
colormap(thecolormap);
% caxis([min(pField) max(pField)]);
caxis([-0.01 0.01]); 
hPatch = patch('Vertices',xp,'Faces',faces, ...
               'CData',pField,'FaceAlpha',0.6, ...
               'EdgeColor','white', 'EdgeAlpha', 0.5, 'FaceColor','flat' );

end
