/*
 * =============================================================
   Matlab interface of OpenCV canny (edge detection) function .
   
   function edges = cvCanny( imgOri, low, high, aper =3 )
   
     Input:
       imgOri:   original image  (size: height x width x 3 (depth)) 
       low:      The first threshold (double).
       high:     The second threshold (double).
       aper:     aperture size (optional, default=3)
     Output:
       edges:    Single-channel (CV_8U or uint8) 
                 with the same size to imgOri
       
   Developed by Yuan-Sen Yang
   Date: 2011.05.14

 * =============================================================
 */
     
#include <mex.h>
#include <matrix.h>
#include "opencv2\core\core.hpp"
#include "opencv2\imgproc\imgproc_c.h"
#include "opencv2\video\tracking.hpp"
#include "opencv2\highgui\highgui.hpp"

#include <stdlib.h>
#include <stdio.h>


void mexFunction( int nlhs, mxArray *plhs[],int nrhs, const mxArray *prhs[])
{
	
  /* Check for proper number of arguments. */
  if (nrhs < 3) {
    mexErrMsgTxt("arguments: imgOri, low, high, aper(=3,optional)");
  } 
  if (nlhs > 1) {
    mexErrMsgTxt("Too many output arguments");
  }
  
  /* get original image buffer pointer */
  
  uchar* imgOriMat    = (uchar*)mxGetPr(prhs[0]); 
  mwSize nDim         = mxGetNumberOfDimensions(prhs[0]);  
  const mwSize *imgDim   = mxGetDimensions(prhs[0]);
  int    imgWidth     = (int) imgDim[1];
  int    imgHeight    = (int) imgDim[0];
  int    imgDepth     = 8;  /* must be 8. Or this function would collapse */ 
  int    imgNChannels; 
  if ( nDim > 2 )
    imgNChannels = (int) imgDim[2];  
  else
    imgNChannels = 1; 
  
  /* get low and high thresholds */

  double  lowThreshold   = (double) (*mxGetPr(prhs[1]));
  double  highThreshold  = (double) (*mxGetPr(prhs[2]));
  int     apr = -1;
  if ( nrhs > 3) apr = (int) (*mxGetPr(prhs[3]));
  
  /* create an openCV image space for source image
     and copy  matlab image (imgOriMat) to openCV image (imgOriOcv). 
     The openCV image (imgOriOcv) will be released before returning */
  
  CvMat*    imgOriOcv  = cvCreateMat(imgHeight, imgWidth, CV_8U);
  
    /* copy image from matlab format to OpenCV format */ 
  int i,j; 
  if ( imgNChannels == 3 ) 
  {
    for(j = 0; j < imgHeight; j++) {
      for(i = 0; i < imgWidth; i++) {
        imgOriOcv->data.ptr[j*imgWidth+i] = 
                (uchar) ((imgOriMat[j + i * imgHeight + imgWidth * imgHeight * 0] + 
                          imgOriMat[j + i * imgHeight + imgWidth * imgHeight * 1] +
                          imgOriMat[j + i * imgHeight + imgWidth * imgHeight * 2] )/3.+0.5); 
    } }
  }
  if ( imgNChannels == 1 ) 
  {
    for(j = 0; j < imgHeight; j++) {
      for(i = 0; i < imgWidth; i++) {
        imgOriOcv->data.ptr[j*imgWidth+i] = 
                (uchar) (imgOriMat[j + i * imgHeight] ); 
    } }
  }
  
  /* create an openCV image space for destination array.
     The created opencv image (edges) will be deleted before returning. */

  CvMat *  edges = cvCreateMat( imgOriOcv->height, imgOriOcv->width, CV_8U );
 
  /* call opencv canny function */
  /*  OpenCV function interface:
            void cvCanny( const CvArr* image,
                 CvArr* edges,
                 double threshold1,
                 double threshold2,
                 int aperture size=3 );  */
  if (apr < 0) 
    cvCanny( imgOriOcv, edges, lowThreshold, highThreshold );
  else 
    cvCanny( imgOriOcv, edges, lowThreshold, highThreshold, apr );
              
  /* create a matlab image (mxArray) and
     copy the generated openCV image to matlab image */
    /* mxREAL means there is no complex part */
  mwSize bufdim[2] = { imgHeight, imgWidth} ;
  plhs[0] = mxCreateNumericArray(2, bufdim, mxUINT8_CLASS, mxREAL);  
  
  /* copy the image from OpenCV format to matlab format */ 
  uchar* bufDesImg = (uchar*) mxGetPr(plhs[0]);

  for(j = 0; j < imgHeight; j++) {
    for(i = 0; i < imgWidth; i++) {
      bufDesImg[j + i * imgHeight] = (uchar) edges->data.ptr[j*imgWidth+i]; 
  } }
    
  /* release opencv images */
  cvReleaseMat(&imgOriOcv);
  cvReleaseMat(&edges);
  
}
