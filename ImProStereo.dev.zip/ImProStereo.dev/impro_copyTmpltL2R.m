function handles = impro_copyTmpltL2R( hObject, handles )

% This function copies "templates or matches" to templates.
%    and saves the files.

dialog_prompt = { 'Option (1:Tmplt L1 to R1. 2:Match R1 to Tmplt R)' }; 
dialog_title  = 'Template copy';
dialog_default= { '1' };
dialog_answer = inputdlg( dialog_prompt, dialog_title, 1, dialog_default );

if ( size(dialog_answer,1) == 0 ) 
  return;
end  
  
% Template L1 to R1
if ( str2num(dialog_answer{1}) == 1 )
  iPair = 1; 
  for iPoint = 1: handles.nPoint
    % Load the left template 
    %  handles.iTmplt{iLR}
    %  handles.iTmplt{iLR}.nPoint   -- number of control points in each photo
    %  handles.iTmplt{iLR}.file{iP} -- file name of template image file (.JPG)
    %  handles.iTmplt{iLR}.refXy{iP}(1,1:2) -- picked point in template
    %  handles.iTmpltImg{iLR,iPoint} -- the template image
    iLR = 1; 
    [handles,iTmpltImg] = impro_loadTmplt(hObject, handles, iPair, iLR, iPoint); 
    % Copy
    handles.iTmplt{2} = handles.iTmplt{1}; 
    % Save to the rigt template 
    iLR = 2; 
    handles = impro_saveTmplt(hObject, handles, iPair, iLR, iPoint, ... 
              iTmpltImg,... 
              handles.iTmplt{iLR}.pckXy{iPoint}, ...
              handles.iTmplt{iLR}.refXy{iPoint} ); 
  end
end

% Matches R1 to template R1
if ( str2num(dialog_answer{1}) == 2 )
  iPair = 1; 
  for iPoint = 1: handles.nPoint
    % Load the left template 
    %  handles.iTmplt{iLR}
    %  handles.iTmplt{iLR}.nPoint   -- number of control points in each photo
    %  handles.iTmplt{iLR}.file{iP} -- file name of template image file (.JPG)
    %  handles.iTmplt{iLR}.refXy{iP}(1,1:2) -- picked point in template
    %  handles.iTmpltImg{iLR,iPoint} -- the template image
    iLR = 2; 
    [handles, iMatchImg] = impro_loadMatch(hObject, handles, iPair, iLR, iPoint); 
    % Copy
    handles.iTmplt{2} = handles.iMatch{2}; 
    % Save to iMatchImg the rigt template 
    iLR = 2; 
    handles = impro_saveTmplt(hObject, handles, iPair, iLR, iPoint, ... 
              iMatchImg,... 
              handles.iMatch{iLR}.mchXy{iPoint}, ...
              handles.iMatch{iLR}.refXy{iPoint} ); 
  end
end

set(handles.slPoint,'Value',1);
handles = impro_updSlPoint(hObject, handles); 


end
