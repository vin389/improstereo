function snth = impro_crack33win_snth_inverse(ux33,uy33)

min_ith = 0;
min_err = 1e30;
ths = [0 15 30 45 60 75 90 105 120 135 150 165];
err_ith = zeros(1,12); 
for ith = 1:12
    option.MaxIter = 10; 
    option.Display = 'off';
    [snth,fval] = fminsearch(@(x)u33err2(x, ths(ith), ux33,uy33), [1 1], option); 
%    [snth, fval] = lsqnonlin(@(x)u33errvec(x,ux33,uy33), [1 1 ths(ith)], LB_snth, UB_snth); 
    snth_ith{ith} = snth;
    err_ith(ith) = fval; 
    if (fval < min_err) 
        min_err = fval;
        min_ith = ith;
    end
end
snth = snth_ith{min_ith};
snth(3) = ths(min_ith); 
end


function err = u33err2(sn, th, ux33, uy33)
[ux33snth, uy33snth] = impro_crack33win_snth(sn(1), sn(2), th); 
errx = ux33(:) - ux33snth(:);
erry = uy33(:) - uy33snth(:);
err = norm(errx) + norm(erry); 
end

function err = u33err(snth, ux33, uy33)
[ux33snth, uy33snth] = impro_crack33win_snth(snth(1), snth(2), snth(3)); 
errx = ux33(:) - ux33snth(:);
erry = uy33(:) - uy33snth(:);
err = norm(errx) + norm(erry); 
end

function err = u33errvec(snth, ux33, uy33)
[ux33snth, uy33snth] = impro_crack33win_snth(snth(1), snth(2), snth(3)); 
errx = ux33(:) - ux33snth(:);
erry = uy33(:) - uy33snth(:);
err = [errx; erry]; 
end