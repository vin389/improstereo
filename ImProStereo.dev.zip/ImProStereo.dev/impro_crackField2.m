function [crack_opening crack_sliding crack_angledg] = ...
    impro_crackField2(uxGrid, uyGrid)
%impro_crackField2
% calculates crack fields, including crack opening and crack sliding.
%   Input arguments:
%     uxGrid/uyGrid: displacement fields.  (in pixel)
%                    size: Mu by Nu.  Mu/Nu: number of rows/columns of 
%                          the displacement field grid.
%     theta is not needed.
tic_crack2 = tic; 

M = size(uxGrid, 1); 
N = size(uxGrid, 2); 
crack_opening = zeros(M, N);
crack_sliding = zeros(M, N);
crack_angledg = zeros(M, N);

uxGrid11 = zeros(M+2,N+2,'single'); 
uxGrid11(M+2,N+2) = uxGrid(M,N);
uxGrid11(M+2,1  ) = uxGrid(M,1);
uxGrid11(1  ,N+2) = uxGrid(1,N);
uxGrid11(1  ,1  ) = uxGrid(1,1);

uxGrid11(1  ,2:N+1) = uxGrid(1, 1:N); 
uxGrid11(M+2,2:N+1) = uxGrid(M, 1:N); 
uxGrid11(2:M+1,  1) = uxGrid(1:M, 1); 
uxGrid11(2:M+1,N+2) = uxGrid(1:M, N); 
uxGrid11(2:M+1,2:N+1) = uxGrid(:,:); 

uyGrid11 = zeros(M+2,N+2,'single'); 
uyGrid11(M+2,N+2) = uyGrid(M,N);
uyGrid11(M+2,1  ) = uyGrid(M,1);
uyGrid11(1  ,N+2) = uyGrid(1,N);
uyGrid11(1  ,1  ) = uyGrid(1,1);

uyGrid11(1  ,2:N+1) = uyGrid(1, 1:N); 
uyGrid11(M+2,2:N+1) = uyGrid(M, 1:N); 
uyGrid11(2:M+1,  1) = uyGrid(1:M, 1); 
uyGrid11(2:M+1,N+2) = uyGrid(1:M, N); 
uyGrid11(2:M+1,2:N+1) = uyGrid; 

for i=2:M+1
   for j=2:N+1
      % Find crack angle (theta) 
      ux33 = [uxGrid11(i-1,j-1)  uxGrid11(i-1,j  )  uxGrid11(i-1,j+1); ...
          uxGrid11(i  ,j-1)  uxGrid11(i  ,j  )  uxGrid11(i  ,j+1); ...
          uxGrid11(i+1,j-1)  uxGrid11(i+1,j  )  uxGrid11(i+1,j+1) ]; 
      uy33 = [uyGrid11(i-1,j-1)  uyGrid11(i-1,j  )  uyGrid11(i-1,j+1); ...
          uyGrid11(i  ,j-1)  uyGrid11(i  ,j  )  uyGrid11(i  ,j+1); ...
          uyGrid11(i+1,j-1)  uyGrid11(i+1,j  )  uyGrid11(i+1,j+1) ]; 
      ux33 = ux33 - sum(ux33(:))/9;
      uy33 = uy33 - sum(uy33(:))/9;
      theta = impro_crack_deg(ux33, uy33); 
      % Calclate uax, uay, ubx, uby
      ux_up__ = uxGrid11(i - 1, j    ); 
      ux_down = uxGrid11(i + 1, j    );
      ux_left = uxGrid11(i    , j - 1);
      ux_rigt = uxGrid11(i    , j + 1);
      uy_up__ = uyGrid11(i - 1, j    ); 
      uy_down = uyGrid11(i + 1, j    );
      uy_left = uyGrid11(i    , j - 1);
      uy_rigt = uyGrid11(i    , j + 1);     
      % Calclate uax, uay, ubx, uby
      c = cos(theta * pi / 180);
      s = sin(theta * pi / 180);
      mat_cr(2,2) = sin(theta * pi / 180);
      mat_cr(1,2) = cos(theta * pi / 180);
      mat_cr(1,1) = cos(theta * pi / 180 + pi / 2);
      mat_cr(2,1) = sin(theta * pi / 180 + pi / 2);
      inv_mat_cr = inv(mat_cr); 
      if (theta >= 0 && theta < 90) 
          uax = (ux_up__ * c + ux_left * s) / (c + s); 
          uay = (uy_up__ * c + uy_left * s) / (c + s); 
          ubx = (ux_down * c + ux_rigt * s) / (c + s); 
          uby = (uy_down * c + uy_rigt * s) / (c + s); 
      else    
          uax = (-ux_down * c + ux_left * s) / (-c + s); 
          uay = (-uy_down * c + uy_left * s) / (-c + s); 
          ubx = (-ux_up__ * c + ux_rigt * s) / (-c + s); 
          uby = (-uy_up__ * c + uy_rigt * s) / (-c + s); 
      end
      % calculate crack opening and sliding
      u_vec = [ uax - ubx; uay - uby ];
      c_vec = inv_mat_cr * u_vec; 
      crack_opening(i - 1,j - 1) = c_vec(1);
      crack_sliding(i - 1,j - 1) = c_vec(2);
      crack_angledg(i - 1,j - 1) = theta; 
   end
end
toc_crack2 = toc(tic_crack2);
fprintf('Crack field analysis time: %6.3f sec.\n', toc_crack2); 
end
