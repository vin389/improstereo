function X = impro_Surface_YZ( alpha, basepoint )
N = size(alpha,2);
X = zeros(3,N);
X(1,1:N) = basepoint(1);
X(2,:)   = alpha(1,:) + basepoint(2);
X(3,:)   = alpha(2,:) + basepoint(3);
end