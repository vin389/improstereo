function handles = impro_interactive_sync_all_points(handles)

    % Get point ID for sync reference
    nPoint = size(handles.CtrlPoints,3); % handles.nPoint; 
    nPair = size(handles.CtrlPoints,1); % handles.nPair; 
    point = input('Synchronization reference point: ');
    if (point > handles.nPoint || point <= 0) 
        disp(sprintf('Reference point (%d) is out of range.', point));
        return
    end

    % Get x or y 
    xy = input('Synchronization reference point direction (1) x, (2) y: ');
    if (xy ~= 1 && xy ~= 2) 
        disp('Should be either 1 or 2.');
        return;
    end

    % Factor (1 or -1)
    fac = input('Factor (1) 1 or (-1) -1:\n (1: L/R movement are about the same directions. -1:L/R are about opposite direction): ');
    if (fac < -1 || fac > 1 || fac == 0) 
        disp('Factor should be nonzero between -1 and 1');
        return
    end

    % Figure
    xystr{1} = 'X'; xystr{2} = 'Y';
    hfig = figure('Name', sprintf('Point %d image-%s factor:%f', point, xystr{xy}, fac));
    ut1(:) = handles.CtrlPoints(:,1,point,xy);
    ut2(:) = handles.CtrlPoints(:,2,point,xy);
    plot(1:nPair, ut1 - ut1(1), 1:nPair, (ut2 - ut2(1)) * fac); grid on; legend('L', 'R * factor'); 

    % Let user to try synchronization many times
    while true
        % Ask sync range
        t1_begin = input('t1_begin: Beginning time (step) of L curve for correlation: ');
        t1_end = input('t1_end: Ending time (step) of L curve for correlation: ');

        % Ask time lag bounds
        lb = input('Lower bound of time lag (+ means R curve appears at right-hand side of L curve): ');
        ub = input('Upper bound of time lag (+ means R curve appears at right-hand side of L curve): ');
        % if user set lb and ub opposite way, swap them. 
        if (lb > ub)
            swaptmp = lb;
            lb = ub;
            ub = swaptmp; 
        end

        % Run sync
        tlag = impro_sync_two_curves(ut1, ut2, t1_begin, t1_end, fac, lb, ub); 
        fprintf('Time lag by correlation between steps (%d,%d) is %f\n', t1_begin, t1_end, tlag);

        % Plot trial figure
        hfigTrial = figure('Name', sprintf('Trial of Sync. (Lag: %f). Point %d image-%s factor:%f', tlag, point, xystr{xy}, fac));
        plot(1:nPair, ut1 - ut1(1), (1:nPair) - tlag, (ut2 - ut2(1))* fac); grid on; legend('L', 'R'); 

        % Ask user 
        try_again = input('Do you want to try again? (1:Yes, else:No): ');
        if (try_again == 1)
            continue;
        else
            break;
        end
    end

    % Input user preferred time lag
    tlag = input('Your preferred time lag (0 to quit): '); 
    if (tlag == 0)
        return
    end

    while true
       vpoint = input('With your time lag, which point(s) do you want to preview?\n   (0 to skip preview, -1 to return without sync.): ');
       if (vpoint == -1)
           return
       end
       if (vpoint == 0) 
           break;
       end
       vxy = input('With your time lag, x or y do you want to preview?\n   (1 for x, 2 for y, [1 2] for both): ');
       if (vxy == -1) 
           return;
       end
       if (vxy == 0)
           break;
       end
       for iPoint = vpoint
           for ixy = vxy
               hfigTrial1 = figure('Name', sprintf('Preview of Sync. (Lag: %f). Point %d image-%s', tlag, iPoint, xystr{ixy}));
               ut1(:)     = handles.CtrlPoints(:, 1, iPoint, ixy);
               ut2_old(:) = handles.CtrlPoints(:, 2, iPoint, ixy);
               if (tlag > 0) 
                   expValue = ut2_old(end);
               else
                   expValue = ut2_old(1);
               end
               ut2_new(:) = interp1(1:nPair, ut2_old, (1:nPair) + tlag, 'spline', expValue); 
               plot(1:nPair, ut1 - ut1(1), 1:nPair, ut2_new - ut2_new(1)); grid on; legend('L', 'R'); 
           end
       end
    end

    % Do sync. and replace CtrlPoints(:,2,:,:)
    disp('Running synchronization to all points ...'); 
    handles.CtrlPointsBackup = handles.CtrlPoints; 
    try
        for iPoint = 1: nPoint
           for ixy = 1: 2
               ut2_old(:) = handles.CtrlPoints(:, 2, iPoint, ixy);
               if (tlag > 0) 
                   expValue = ut2_old(end);
               else
                   expValue = ut2_old(1);
               end
               ut2_new(:) = interp1(1:nPair, ut2_old, (1:nPair) + tlag, 'spline', expValue); 
               handles.CtrlPoints(:, 2, iPoint, ixy) = ut2_new(:); 
           end    
        end
    catch syncException
        handles.CtrlPoints = handles.CtrlPointsBackup; 
        fprintf('Synchronization exception occurred: The identifier was:\n%s',syncException.identifier);
        fprintf('Synchronization exception occurred: There was an error! The message was:\n%s',syncException.message);
        fprintf('Synchronization stopped. handles.CtrlPoints remains.');
    end
end
                        
    