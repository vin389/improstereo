function handles = impro_DefineSingleCamCoordSys(hObject, handles)
% This function creates a user-defined coordinate system which is 
% defined by assigning at least three known control points. 
% The user needs to input: 
%    (1) Image coord. positions of the control points.
%    (2) User-defined coordinate positions of the control points. 
% This function is de facto a graphical interface of compute_extrinsic() 
% with additional minor functionalities for ImPro Stereo. 
% 
% Input dialog parameters:
% Reference pair     - The photo index that defines the coord sys. 
%                      Default value is 1 (the first photo). 
% Reference cam      - The camera index. Default value is 1. 
% Range of Points    - Control points that define the coord sys. 
% 3D Coord of Points - The 3D coordinates of points in user defined coord.
%                      Format: [ x1 y1 z1; x2 y2 z2; x3 y3 z3; ... ] 
% Max # of iterations- Maximal number of iterations allowed. 


% Ask user to input range of matching
inpans = inputdlg( {'Reference Pair'   ...
                    'Reference Cam(iLR)'    ...
                    'Range of Points'  ...
                    '3D Coord. of Points'       ...
                    'Max # of itrs'    }, ...
        'Define single-cam coord. sys.', 1, ...
                   { '1' ...
                     '1' ...
                     ['1:'  num2str(handles.nPoint)] ...
                      '[x1 y1 z1; x2 y2 z2;]'  ...
                      '50' }, ...
                      'on');
                  
if ( size(inpans,1) < 1 ) 
  return
end

refPair     = str2num(inpans{1});
iLR         = str2num(inpans{2});
iPointRange = str2num(inpans{3});
X_kk        = str2num(inpans{4});  
maxItr      = str2num(inpans{5});                    

N = size(iPointRange(:), 1); 

% Check size of coord. array. 
if ( ~(size(X_kk,2) == 3 && size(X_kk,1) == N) ) 
    errordlg('3D coord. must be sized Nx3');
    return;
end
% convert it to 3xN
X_kk = X_kk'; 

% Get x_kk (image coord.) 
x_kk = zeros(2, N); 
for i = 1:N
   x_kk(1,i) = handles.CtrlPoints(refPair, iLR, iPointRange(i), 1 );
   x_kk(2,i) = handles.CtrlPoints(refPair, iLR, iPointRange(i), 2 );
end

% Get camera intrinsic parameters
fc = handles.calibSingleCam.fc; 
cc = handles.calibSingleCam.cc; 
kc = handles.calibSingleCam.kc;
ac = handles.calibSingleCam.alpha_c;

% call initial compute_extrinsic using refined points if N is small
if ( N < 10 ) 
    refFac = 10; 
else
    refFac = 1; 
end
N_refine = (N-1) * refFac + 1;
x_kk_refine = zeros(2, N_refine);
X_kk_refine = zeros(3, N_refine);
for i = 1: N-1    
    x_kk_refine(1, (i-1)*refFac+1:i*refFac+1) = ... 
        linspace( x_kk(1,i), x_kk(1,i+1), refFac+1 );
    x_kk_refine(2, (i-1)*refFac+1:i*refFac+1) = ... 
        linspace( x_kk(2,i), x_kk(2,i+1), refFac+1 );
    X_kk_refine(1, (i-1)*refFac+1:i*refFac+1) = ... 
        linspace( X_kk(1,i), X_kk(1,i+1), refFac+1 );
    X_kk_refine(2, (i-1)*refFac+1:i*refFac+1) = ... 
        linspace( X_kk(2,i), X_kk(2,i+1), refFac+1 );
    X_kk_refine(3, (i-1)*refFac+1:i*refFac+1) = ... 
        linspace( X_kk(3,i), X_kk(3,i+1), refFac+1 );
end
[omckk, Tckk, Rckk, H, x, ex, JJ] = ...
    compute_extrinsic(x_kk_refine,X_kk_refine,fc,cc,kc,ac,maxItr); 

% refine compute extrinsic parameters
[omckk,Tckk,Rckk,JJ] = compute_extrinsic_refine(omckk,Tckk,x_kk,X_kk,...
    fc,cc,kc,ac,maxItr); 
x = project_points2(X_kk,omckk,Tckk,fc,cc,kc,ac);
ex = x_kk - x;

% print error
fprintf(' omckk = [%7.4f %7.4f %7.4f]\n', omckk(1), omckk(2), omckk(3) );
fprintf('  Tckk = [%7.4f %7.4f %7.4f]\n', Tckk(1), Tckk(2), Tckk(3) );
fprintf('Average of norm of image coord err. = %9.4f\n', norm(ex)/sqrt(N));

% show image in a separate figure
figure; 
img00 = imread([handles.PhotoPath{iLR} handles.filelistPhoto{refPair}]); 
% if read image is one-channel, convert it to 3-channel (vince 2014-08-07)
if (size(img00,3) == 1) 
    img_tmp = img00; 
    img00 = zeros([size(img_tmp,1) size(img_tmp,2) 3], 'uint8'); 
    img00(:,:,1) = img_tmp; 
    img00(:,:,2) = img_tmp; 
    img00(:,:,3) = img_tmp; 
    clear img_tmp; 
end

image(img00); axis image; hold on; 
plot(x(1,:),x(2,:),'o', x_kk(1,:),x_kk(2,:), '*', 'LineWidth', 2);

handles.SingleCamCoord.omckk = omckk;
handles.SingleCamCoord.Tckk  = Tckk;
                  
end
