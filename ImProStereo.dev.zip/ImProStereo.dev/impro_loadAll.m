function handles = impro_loadAll(hObject, handles )
% This function load and show all photos/template/matched/rectified images
iPair  = handles.iPair; 
iPoint = handles.iPoint; 
% Show images on gui axes when slider object is triggered.
for iLR = 1: handles.nLR
  % Photos
  handles = impro_loadPhoto(hObject,handles,iPair,iLR);
  % Template and Rectified images (for each control point)
  handles = impro_loadTmplt(hObject,handles,iPair,iLR,iPoint);
  handles = impro_loadMatch(hObject,handles,iPair,iLR,iPoint);
  % Rectified
  handles = impro_loadRectf(hObject,handles,iPair,iLR);
end

end