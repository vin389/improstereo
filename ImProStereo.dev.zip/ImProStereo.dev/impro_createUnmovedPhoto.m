function impro_createUnmovedPhoto(FilenameSrc, FilenameDst, camMove2)
% This function creates a new photo by mapping the source photo which 
% contains a camera movement to its un-moved photo (the new one).
%
% Input parameters:
%      FilenameSrc:  file name of the source photo (with movement)
%      FilenameDst:  file name of the new photo (without movement)
%                    If FilenameDst equals to FilenameSrc, the source photo
%                    will be replaced.
%      camMoveInv2:  movement parameters calculated by
%                    impro_findCamMove2()
%
% Output parameters:
%      There is no output parameters.
%
% Developer: Yuan-Sen Yang
% Date: 2012-04-18
% 

% Get source photo data
PhotoSrc = imread( FilenameSrc );
% if read image is one-channel, convert it to 3-channel (vince 2014-08-07)
if (size(PhotoSrc,3) == 1) 
    PhotoSrc = uint8(cat(3,PhotoSrc,PhotoSrc,PhotoSrc));
end

PhotoHgt = size(PhotoSrc, 1); % photo height
PhotoWdt = size(PhotoSrc, 2); % photo width
PhotoDpt = size(PhotoSrc, 3); % photo depth
if ( PhotoDpt ~= 3) 
    fprintf('Error: impro_createUnmovedPhoto supports 3-ch photo only.\n');
    return;
end

% Create mapping arrays
mapx = zeros(PhotoHgt, PhotoWdt, 'single');
mapy = zeros(PhotoHgt, PhotoWdt, 'single');

dx = camMove2(1); 
dy = camMove2(2);
th = camMove2(3);
sc = camMove2(4);
C = cos(th); S = sin(th);
for i = 1: PhotoHgt
   for j = 1: PhotoWdt
       mapx(i,j) =  sc *(C*j - S*i + dx);
       mapy(i,j) =  sc *(S*j + C*i + dy);
   end
end

% Create mapped photo
PhotoDst = cvRemap( PhotoSrc, mapx, mapy );

% Write the file.
imwrite( PhotoDst, FilenameDst, 'Quality', 98 );

end
