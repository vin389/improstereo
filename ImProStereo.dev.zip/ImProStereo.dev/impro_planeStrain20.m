function [uxGrid,uyGrid,strain2Dxx,strain2Dyy,strain2Dxy,xGrid,yGrid, infoTM ] = ...
         impro_planeStrain20(imgInitial, imgDeformd, rangeTracing, options)
%
%  [ux,uy,exx,eyy,exy] = impro_planeStrain20(img1, img2, rangeTracing, options)
%   
%  impro_planeStrain20 calculates 2D displacment and strain fields.
%  for ImPro Strain 2.0 
%  
%  INPUTS: 
%
%    imgInitial:        image of initial  specimen
%    imgDeformd:        image of deformed specimen
%    rangeTracing:  [x1Tracing x2Tracing y1Tracing y2Tracing]: 
%                       range of the target in img1
%    options:           options for the displacement/strain field measurement
%      options.M:       number of rows    of template matching grids
%      options.N:       number of columns of template matching grids
%      options.Mu:      number of rows    of interpolated displacement/strain field grids
%      options.Nu:      number of columns of interpolated displacement/strain field grids
%      options.ZmFct:   zoom factor for sub-pixel template matching (suggested: 10 to 20 for vivid image)
%      options.rangeMatching: [leftRange rigtRange upprRange downRange ]:
%                       range of matching (searching range) (in pixel). 
%                       E.g., If leftRange=rigtRange=img2 width, and upprRange=downRange=img2 height, 
%                       then the matching range is 3x3 times the size of img2. 
%
%  OUTPUTS:
%
%    uxGrid/uyGrid:       displacement fields.  (in pixel)
%                         size: Mu by Nu.  Mu/Nu: number of rows/columns of the displacement field grid.
%    strain2Dxx/yy/xy:    strain fields 
%                         size: Mu by Nu.  Mu/Nu: number of rows/columns of the strain field grid. 
%    xGrid/yGrid:         grid positions (in pixel)
%    infoTM:              information of template matching
%    infoTM.Acc(1:M,1:N): Accuracy values of template matching ( good-->1.0   poor-->0.0)
%    infoTM.imgTmp{1:M,1:N}: template image of each template matching.
%    infoTM.imgMat{1:M,1:N}: matched  image of each template matching.
%    infoTM.tCPU{1:M,1:N}:   CPU time of each template matching.

%
% basic information
%
  x1Tracing= rangeTracing(1);
  x2Tracing= rangeTracing(2);
  y1Tracing= rangeTracing(3);
  y2Tracing= rangeTracing(4);
  sxImgInit= size(imgInitial,2); 
  syImgInit= size(imgInitial,1);
  sxImgDefm= size(imgDeformd,2); 
  syImgDefm= size(imgDeformd,1);
  % clear infoTM;
%
% parameters (sizes of grid) 
%
%   M,N,Mu,Nu: Refinement of grids
%   M/N:       Template matching refinement. M/N:# of rows/columns of templates. 
%   Mu/Nu:     Strain calculation refinement. Mu/Nu: # of rows/columns of strain grid. 
%  
  if (isstruct(options))
    M  = options.M;
    N  = options.N;
    Mu = options.Mu;
    Nu = options.Nu;
    ZmFct = options.ZmFct;
  else 
    sxAvgTemplate=50; 
    syAvgTemplate=50; 
    M= round((y2Tracing-y1Tracing+1)/syAvgTemplate);
    N= round((x2Tracing-x1Tracing+1)/sxAvgTemplate);
    Mu= 20;
    Nu= 20;
    ZmFct = 20; 
  end
% increase Mu Nu by 2 for abandoning the boundary grids later.
  Mu = Mu + 2;
  Nu = Nu + 2;
  x2TracingN = min( round(x2Tracing + (x2Tracing-x1Tracing) * 1./Nu), sxImgInit);
  x1TracingN = max( round(x1Tracing - (x2Tracing-x1Tracing) * 1./Nu), 1);
  y2TracingN = min( round(y2Tracing + (y2Tracing-y1Tracing) * 1./Mu), syImgInit);
  y1TracingN = max( round(y1Tracing - (y2Tracing-y1Tracing) * 1./Mu), 1);

  x2Tracing = x2TracingN;
  x1Tracing = x1TracingN;
  y2Tracing = y2TracingN;
  y1Tracing = y1TracingN;
%  disp(sprintf('M/N:%d/%d  Mu/Nu:%d/%d',M,N,Mu,Nu));

%
% rough template matching 
%
%   x1/x2/y1/y2TracingDeformedRough: rough range of selection of tracing region in deformed image
%

 % only for that initial image is smaller than deformed image. 
 
 if ( x2Tracing-x1Tracing+1 < sxImgDefm && y2Tracing-y1Tracing+1 < syImgDefm ) 
   fact=0.2; 
   imgResDeformd= impro_resize(imgDeformd, fact);
   imgResInitialTrac= impro_resize(imgInitial(y1Tracing:y2Tracing,x1Tracing:x2Tracing,:), fact);
   result = cvTemplateMatch2( uint8(imgResInitialTrac), uint8(imgResDeformd),...
                               [1 99999 1 99999], 1 );
   x1TracingDeformedRough= result(1) / fact; 
   x2TracingDeformedRough= x1TracingDeformedRough+ x2Tracing - x1Tracing;
   y1TracingDeformedRough= result(2) / fact; 
   y2TracingDeformedRough= y1TracingDeformedRough+ y2Tracing - y1Tracing;
 else
   x1TracingDeformedRough= 0;
   x2TracingDeformedRough= 0;
   y1TracingDeformedRough= 0;
   y2TracingDeformedRough= 0;
   disp(['Warning: (in impro_planeStrain.m: imgInitial tracing range is larger than the deformed image. ' ...
         'The analysis error may be large.'] ); 
 end  

%
% define the positions of each templates (within the tracing region) 
%
%   x1/x2/y1/y2Templates(1:M,1:N): positions of templates
%   x/yTemplates(1:M,1:N): center positions of templates
%   sx/syTemplates(1:M,1:N): size of templates
%
 sizeXTemp= (x2Tracing-x1Tracing)/N;
 sizeXTemp= (x2Tracing-x1Tracing)/N;
 sizeYTemp= (y2Tracing-y1Tracing)/M;
 sizeYTemp= (y2Tracing-y1Tracing)/M;

 % boundary & size of each template
 for i=1:M
   x1Templates(i,1:N)= round( linspace(x1Tracing,x2Tracing-sizeXTemp,N) );
   x2Templates(i,1:N-1)= x1Templates(i,2:N)-1; 
   x2Templates(i,N)= round(x2Tracing); 
 end
 for i=1:N
   y1Templates(1:M,i)= round( linspace(y1Tracing,y2Tracing-sizeYTemp,M) );
   y2Templates(1:M-1,i)= y1Templates(2:M,i)-1; 
   y2Templates(M,i)= round(y2Tracing); 
 end
 % center point of each template
 for i=1:M
 for j=1:N
   xTemplates(i,j)= 0.5 * (x1Templates(i,j)+x2Templates(i,j));
   yTemplates(i,j)= 0.5 * (y1Templates(i,j)+y2Templates(i,j));
 end; end
 % size of each template
 for i=1:M
 for j=1:N
   sxTemplates(i,j)= x2Templates(i,j)-x1Templates(i,j);
   syTemplates(i,j)= y2Templates(i,j)-y1Templates(i,j);
 end; end
%
% define the search range of each template
%  
%   x1/x2/y1/y2Ranges(1:M,1:N): range of template matching
%
 if (isfield(options,'rangeMatching'))
   x1AddRange = options.rangeMatching(1);
   x2AddRange = options.rangeMatching(2);
   y1AddRange = options.rangeMatching(3);
   y2AddRange = options.rangeMatching(4);
 end
 if (~isfield(options,'rangeMatching') || ...
     x1AddRange <= 0 || ...
     x2AddRange <= 0 || ...
     y1AddRange <= 0 || ...
     y2AddRange <= 0 )  
   x1AddRange= sizeXTemp * 0.2 + 20; 
   x2AddRange= sizeXTemp * 0.2 + 20; 
   y1AddRange= sizeYTemp * 0.2 + 20; 
   y2AddRange= sizeYTemp * 0.2 + 20; 
 end

 for i=1:M
 for j=1:N
     x1Ranges(i,j)= max( x1Templates(i,j)-x1AddRange + (x1TracingDeformedRough-x1Tracing), 1); 
     x2Ranges(i,j)= min( x2Templates(i,j)+x2AddRange + (x1TracingDeformedRough-x1Tracing), sxImgDefm) ;
     y1Ranges(i,j)= max( y1Templates(i,j)-y1AddRange + (y1TracingDeformedRough-y1Tracing), 1) ;
     y2Ranges(i,j)= min( y2Templates(i,j)+y2AddRange + (y1TracingDeformedRough-y1Tracing), syImgDefm);
 end; end; 

 
 
%
% run template matching
%
%   ux/uy(1:M,1:N): displacements of the center points of templates
%   acc(1:M,1:N): accuracy of the template matching result (--> 1.0: Good.  --> 0.0: Poor)
%
% also output template matching results to:
%   
 cpuTemplateMatch=0;
 clear ux; clear uy; clear acc; 

infoTMsl_Acc(M,N)    = 0; 
infoTMsl_tCPU(M,N)   = 0;
infoTMsl_imgTmp{M,N} = [];
infoTMsl_imgMat{M,N} = [];

for i=1:M

  % timing variable: 
  %  cpuTMRow: CPU time for template matching of a row of templates.
  %  cpuTMMat: CPU time for generate matched image (not necessary. For checking template matching result by 
  %    comparing template and matched images.)
  cpuTMRow = 0.0;
  cpuMatRow = 0.0;

%  parfor j=1:N
for j=1:N
  
   imgTemplate= imgInitial( y1Templates(i,j):y2Templates(i,j), x1Templates(i,j):x2Templates(i,j),:);
 
   cpuclock = clock; cpuTemplateMatch = cpuclock(4)*3600+cpuclock(5)*60+cpuclock(6); 
   result = cvTemplateMatch2( uint8(imgTemplate), uint8(imgDeformd),...
                             [x1Ranges(i,j) x2Ranges(i,j) y1Ranges(i,j) y2Ranges(i,j) ], ZmFct );
   cpuclock = clock; cpuTemplateMatch= cpuclock(4)*3600+cpuclock(5)*60+cpuclock(6) - cpuTemplateMatch;
   cpuTMRow = cpuTMRow + cpuTemplateMatch; 
   
   ux(i,j)= result(1) - x1Templates(i,j) + 1;
   uy(i,j)= result(2) - y1Templates(i,j) + 1;
    
   % template matching information 
    % accuracy, cpu time, and template image
    % only if infoTM is requested.

%   if (nargout >= 8) 
%     infoTM.Acc(i,j)    = result(3);
%     infoTM.tCPU(i,j)   = cpuTemplateMatch; 
%     infoTM.imgTmp{i,j} = imgTemplate;
     % use sliced variables for parfor
     infoTMsl_Acc(i,j)    = result(3);
     infoTMsl_tCPU(i,j)   = cpuTemplateMatch;
     infoTMsl_imgTmp{i,j} = imgTemplate;
     
     % matched image , which needs interpolation to obtain)
     x1 = result(1)+1;
     y1 = result(2)+1;
     Nx = size(imgTemplate,2);
     Ny = size(imgTemplate,1);
     cpuclock=clock; cpuImgIntp= cpuclock(4)*3600+cpuclock(5)*60+cpuclock(6); 

     imgMatchd = [];     
%     imgMatchd = impro_interpImg( imgDeformd, x1,y1,Nx,Ny ); 
     
     cpuclock=clock; cpuImgIntp= cpuclock(4)*3600+cpuclock(5)*60+cpuclock(6) - cpuImgIntp; 
     cpuMatRow = cpuMatRow + cpuImgIntp;
%     infoTM.imgMat{i,j} = imgMatchd;
     % use sliced variables for parfor
     infoTMsl_imgMat{i,j} = imgMatchd; 
%   else
%     infoTM = 0; 
%   end
   
  % end of j
  end
  
  for j=1:N
     infoTM.Acc(i,j)      = infoTMsl_Acc(i,j);
     infoTM.tCPU(i,j)     = infoTMsl_tCPU(i,j);
     infoTM.imgTmp{i,j}   = infoTMsl_imgTmp{i,j};
     infoTM.imgMat{i,j}   = infoTMsl_imgMat{i,j};
  end
  
  fprintf('TM line %d in %f sec. Avg/MinAcc: %f/%f. Gen matched img in %f sec.\n', ...
           i, cpuTMRow, mean(infoTM.Acc(i,:)), min(infoTM.Acc(i,:)), cpuMatRow );
  drawnow; 
 end  
  
%
% calculate strain field from the template displacements
%
%   strain2Dxx/yy/xy(1:M, 1:N)    the strain component of the region. (sxx,syy,sxy)
%   x/yGrid(1:Mu,1:Nu):    center points of regular grid 
%   ux/uyGrid(1:Mu,1Nu)   :   displacement field on regular grid
%   
 clear xGrid; clear yGrid; 
 x1TracingCenterPoint = (2*Nu-1)/(2*Nu)*x1Tracing + 1/(2*Nu)*x2Tracing;
 x2TracingCenterPoint = (2*Nu-1)/(2*Nu)*x2Tracing + 1/(2*Nu)*x1Tracing;
 y1TracingCenterPoint = (2*Mu-1)/(2*Mu)*y1Tracing + 1/(2*Mu)*y2Tracing;
 y2TracingCenterPoint = (2*Mu-1)/(2*Mu)*y2Tracing + 1/(2*Mu)*y1Tracing;
 xGrid(1:Nu)= linspace(x1TracingCenterPoint,x2TracingCenterPoint,Nu);
 yGrid(1:Mu)= linspace(y1TracingCenterPoint,y2TracingCenterPoint,Mu);
%
%   interpolation displacement from M/N grid to Mu/Nu grid
%
 cpuclock=clock; cpuGriddata= cpuclock(4)*3600+cpuclock(5)*60+cpuclock(6); 
 interpMethod='interp2';
 if ( interpMethod == 'gridfit' )
   uxGrid = gridfit(xTemplates,yTemplates,ux,xGrid,yGrid, 'interp', 'bilinear');
   uyGrid = gridfit(xTemplates,yTemplates,uy,xGrid,yGrid, 'interp', 'bilinear');
 end
 if ( interpMethod == 'interp2' )
   [xMeshGrid,yMeshGrid]=meshgrid(xGrid,yGrid);
   uxGrid = interp2(xTemplates,yTemplates,ux,xMeshGrid,yMeshGrid, 'cubic');
   uyGrid = interp2(xTemplates,yTemplates,uy,xMeshGrid,yMeshGrid, 'cubic');
 end
 cpuclock=clock; cpuGriddata= cpuclock(4)*3600+cpuclock(5)*60+cpuclock(6) - cpuGriddata; 
%
% calculation of strain 
% Note: strain2D is in image coordinate (which image Y vector is downward). Normally in 3D the Y vector
% is upward, so the strain2Dxy will be converted.
% 
%
 for i=2:Mu-1
 for j=2:Nu-1
   ux_left=uxGrid(i,j-1);  ux_rigt=uxGrid(i,j+1); 
   uy_left=uyGrid(i,j-1);  uy_rigt=uyGrid(i,j+1); 
   ux_up__=uxGrid(i-1,j);  ux_down=uxGrid(i+1,j); 
   uy_up__=uyGrid(i-1,j);  uy_down=uyGrid(i+1,j); 
   
   xx_left= xGrid(j-1);  xx_rigt= xGrid(j+1);
   yy_left= yGrid(i  );  yy_rigt= yGrid(i  );
   xx_up__= xGrid(j  );  xx_down= xGrid(j  );
   yy_up__= yGrid(i-1);  yy_down= yGrid(i+1);

   strain2D1(i,j)= (ux_rigt-ux_left)/(xx_rigt-xx_left);
   strain2D2(i,j)= (uy_up__-uy_down)/(yy_up__-yy_down);
   strain2D3(i,j)= 0.5*( (ux_up__-ux_down)/(yy_up__-yy_down) + (uy_rigt-uy_left)/(xx_rigt-xx_left) );
 end; end
 
 % xMeshGridM2 & yMeshGridM2 are similar to xMeshGrid & yMeshGrid but with smaller sizes
 % because their 4 boundary edges are cut off. 
 [xMeshGridM2,yMeshGridM2]= meshgrid(xGrid(2:Nu-1),yGrid(2:Mu-1));
 if ( interpMethod == 'interp2' )
   strain2Dxx = interp2(xMeshGridM2,yMeshGridM2,strain2D1(2:Mu-1,2:Nu-1),xMeshGrid,yMeshGrid, 'bilinear');
   strain2Dyy = interp2(xMeshGridM2,yMeshGridM2,strain2D2(2:Mu-1,2:Nu-1),xMeshGrid,yMeshGrid, 'bilinear');
   strain2Dxy = interp2(xMeshGridM2,yMeshGridM2,strain2D3(2:Mu-1,2:Nu-1),xMeshGrid,yMeshGrid, 'bilinear');
   clear xMeshGrid; clear yMeshGrid; 
 end
 if ( interpMethod == 'gridfit' )
   strain2Dxx = gridfit(xMeshGridM2,yMeshGridM2,strain2D1(2:Mu-1,2:Nu-1),xGrid,yGrid, 'interp', 'bilinear');
   strain2Dyy = gridfit(xMeshGridM2,yMeshGridM2,strain2D2(2:Mu-1,2:Nu-1),xGrid,yGrid, 'interp', 'bilinear');
   strain2Dxy = gridfit(xMeshGridM2,yMeshGridM2,strain2D3(2:Mu-1,2:Nu-1),xGrid,yGrid, 'interp', 'bilinear');
 end
 clear xMeshGridM2; clear yMeshGridM2; 
 clear strain2D1; clear strain2D2; clear strain2D3;

%
% abandoning boundary grid.
% Note: Mu and Nu were added by 2 earlier.
%
 uxGrid     = uxGrid(2:Mu-1,2:Nu-1);
 uyGrid     = uyGrid(2:Mu-1,2:Nu-1);
 strain2Dxx = strain2Dxx(2:Mu-1,2:Nu-1);
 strain2Dyy = strain2Dyy(2:Mu-1,2:Nu-1);
 strain2Dxy = strain2Dxy(2:Mu-1,2:Nu-1);
 xGrid      = xGrid(2:Nu-1);
 yGrid      = yGrid(2:Mu-1);
 