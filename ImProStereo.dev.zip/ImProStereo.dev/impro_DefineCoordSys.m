function handles = impro_DefineCoordSys( hObject, handles )
% This function allows user to define a coordinate system by 
% using GUI inputdlg 
% Input:
%  1: Coord. system ID (begins from 1. Suggestion: 1 for fixed system.) 
%  2. Vector definition ordering (1:X-Y, 2:X-Z, 3:Y-X, 4:Y-Z, 5:Z-X, 6:Z-Y)
%     E.g., 1:X-Y means the 1st vector to define is X. The 2nd is Y. 
%           And the 2nd vector will be slightly tuned so that 1st.2nd=0 
%  3. 1st vector direction
%     [1 2; 2 3; 4 5] means the 1st vector is the average direction of
%     {from P1 to P2}, {from P2 to P3}, {from P4 to P5}.
%  4. 2nd vector direction 
%     Using the same method as above to define the 2nd vector.
%  5. Origin point = a1*P1 + a2*P2 + ... + an*Pn + {x0;y0;z0} (in new
%     coord.) 
%     [a1 a2 a3 ... an]
%  6. [x0; y0; z0] 
%  7. 0:fixed coord. 1:moving coord. 
% 
% Output: 
%   handles.CoordSys{iPair,coordID} (a 4x4 matrix that transform a fixed 
%   point in the new coord. to the left cam coord.
%      

% Modified by vince (20 Mar 2015)
% Added 7th input: Coord sys update or not: 
%    0: always use initial (pair 1).
%    1: coord. updated with control points.

% Advanced option dialog
dialog_prompt = { '1. Coord. sys. ID', ... 
                  '2. Vector ordering(1:XY 2:XZ 3:YX 4:YZ 5:ZX 6:ZY', ...
                  '3: 1st vec direction: [Px1 Pj1; Pi2 Pj2; ... ]', ...
                  '4: 2nd vec direction: [Pm1 Pn1; Pm2 Pn2; ... ]', ...
                  '5: Origin combination [a1 a2 ... an]', ...
                  '6: Origin shift [x0; y0; z0]', ...
                  '7: Coord fixed (0) or update (1): ' }; 
dialog_title  = 'Define a coordinate system';
dialog_default= { '2', '4', ...
                  '[2 1; 3 2; 5 4; 6 5; 8 7; 9 8]', ...
                  '[4 1; 7 4; 5 2; 8 5; 6 3; 9 6]', ...
                  '[0 0 0 0 1]', ...
                  '[850 0 0]', ...
                  ' 0 ' };
dialog_answer = inputdlg( dialog_prompt, dialog_title, 1, dialog_default );

if ( size(dialog_answer,1) == 0 )
  return;
end

% Get parameters.
coordID = str2num(dialog_answer{1}); 
coordOrdering = str2num(dialog_answer{2}); 

if ( coordID < 1 || coordOrdering < 1 || coordOrdering > 6 )
  fprintf('Invalid input for coord. definition.\n');
  return;
end

vec1par = str2num(dialog_answer{3});
vec2par = str2num(dialog_answer{4});

% Get directional vectors (for each pair)

for iPair = 1: handles.nPair

  % Get vec 1. 
  vec1 = [0;0;0];
  for i = 1: size(vec1par, 1) 
    Pi = handles.CtrlPoints3D(iPair, 1, vec1par(i,1), :); 
    Pj = handles.CtrlPoints3D(iPair, 1, vec1par(i,2), :); 
    Pi = reshape(Pi,[3 1]);
    Pj = reshape(Pj,[3 1]);
    vec1 = vec1 + Pj - Pi;  
  end
  vec1 = vec1 / size(vec1par, 1); 

  % Get vec 2. 
  vec2 = [0;0;0];
  for i = 1: size(vec2par, 1) 
    Pm = handles.CtrlPoints3D(iPair, 1, vec2par(i,1), :); 
    Pn = handles.CtrlPoints3D(iPair, 1, vec2par(i,2), :); 
    Pm = reshape(Pm,[3 1]);
    Pn = reshape(Pn,[3 1]);
    vec2 = vec2 + Pn - Pm;  
  end
  vec2 = vec2 / size(vec2par, 1); 
  
  if ( coordOrdering == 1) % X->Y->Z
    vecx = vec1; 
    vecy = vec2; 
    vecz = cross(vecx, vecy);
    vecy = cross(vecz, vecx); 
  end  
  if ( coordOrdering == 2) % X->Z->Y
    vecx = vec1; 
    vecz = vec2; 
    vecy = cross(vecz, vecx); 
    vecz = cross(vecx, vecy);
  end  
  if ( coordOrdering == 3) % Y->X->Z
    vecy = vec1; 
    vecx = vec2; 
    vecz = cross(vecx, vecy);
    vecx = cross(vecy, vecz); 
  end  
  if ( coordOrdering == 4) % Y->Z->X
    vecy = vec1; 
    vecz = vec2; 
    vecx = cross(vecy, vecz); 
    vecz = cross(vecx, vecy);
  end  
  if ( coordOrdering == 5) % Z->X->Y
    vecz = vec1; 
    vecx = vec2; 
    vecy = cross(vecz, vecx); 
    vecx = cross(vecy, vecz); 
  end  
  if ( coordOrdering == 6) % Z->Y->X
    vecz = vec1; 
    vecy = vec2; 
    vecx = cross(vecy, vecz); 
    vecy = cross(vecz, vecx); 
  end  
  vecx = vecx/norm(vecx); 
  vecy = vecy/norm(vecy); 
  vecz = vecz/norm(vecz); 
  vecx = vecx(:);                % must be a column vector
  vecy = vecy(:);                % must be a column vector
  vecz = vecz(:);                % must be a column vector
  
  % Get origin (control points combination).
  
  Ori = [0;0;0];
  oriFactor = str2num(dialog_answer{5});  
  oriFactor = (oriFactor(:))';   % must be a row array (1*N)
    
  for iP = 1: size(oriFactor,2)
    Pip = handles.CtrlPoints3D(iPair, 1, iP, :); 
    Pip = Pip(:); 
    Ori = Ori + Pip * oriFactor(iP);
  end
  Ori = Ori(:);                  % must be a column vector
  
  % Get original (translation) 
  
  oriTrans = str2num(dialog_answer{6});  
  oriTrans = oriTrans(:);        % must be a column vector
  Ori = Ori + vecx * oriTrans(1) + vecy * oriTrans(2) + vecz * oriTrans(3);
    
  % 4x4 transform matrix
  
  R44 = zeros(4,4); 
  R44(1:3, 1) = vecx(1:3);
  R44(1:3, 2) = vecy(1:3);
  R44(1:3, 3) = vecz(1:3);
  R44(1:3, 4) =  Ori(1:3); 
  R44(  4, 4) = 1.0; 
  
  coordUpdate = str2num(dialog_answer{7});  % added by vince 20 Mar 2015
  
  if (coordUpdate == 0 && iPair > 1) 
      handles.CoordSys{iPair,coordID} = handles.CoordSys{ 1,coordID}; 
  else
      handles.CoordSys{iPair,coordID} = R44; 
  end
end

