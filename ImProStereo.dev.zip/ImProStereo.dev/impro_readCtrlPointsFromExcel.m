function ctrlPoints = impro_readCtrlPointsFromExcel(pathname, filename)

ctrlPoints = [];

% Check if path ane filename is correctly given
if (exist('pathname', 'var') == 0 || exist('filename', 'var') == 0  ... 
    || exist([pathname filename], 'file') ~= 2 ) 
    % If not given, user selects Excel from uigetfile
    [filename, pathname] = uigetfile( {'*.xlsx';'*.xls'}, 'Pick Excel file of markers coordinates');
end
      
% Returns if user selects nothing

if (isnumeric(filename))
    disp('User cancelled without selecting a file.');
    return;
end
if (exist([pathname filename], 'file') ~= 2)
    disp('File does not exist.');
    return;
end

% Read ctrl points coordinates (to ctrlPoints(1:nMarker, 1:3)) 
% Marker ID ordering can be arbitrary 
[ctrlPoints, txt, raw] = xlsread([pathname filename]); 


