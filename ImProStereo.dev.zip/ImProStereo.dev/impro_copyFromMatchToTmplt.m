% This function is similar to impro_copyMatch2Tmplt but allows 
% the user to specify the source (srcPair) match and 
% the destination (dstPair) template images.
% (The impro_copyMatch2Tmplt copies from Pair Match to Pair+1 Template).
function handles = impro_copyFromMatchToTmplt(hObject, handles, ...
                   srcPair, dstPair, ...
                   iLR, iPoint)
% Copy the matched data to template data of next pair (iPair+1) 
if (srcPair <= handles.nPair && dstPair <= handles.nPair )
  % Load data to handles.iMatch{iLR} and and iMatchImg{iLR,iPoint}
  [handles,iMatchImg] = impro_loadMatch(hObject, handles, srcPair, iLR, iPoint); 
  % Save data to template of next pair 
  handles = impro_saveTmplt(hObject, handles, dstPair, iLR, iPoint, ...
            iMatchImg, ...
            handles.iMatch{iLR}.mchXy{iPoint}, ...
            handles.iMatch{iLR}.refXy{iPoint} ); 
  % print a message to the console
  fprintf('Copy Match(Pr:%d/LR:%d/CPnt:%d)->Tmplt(%d)\n', ...
          srcPair,iLR,iPoint, dstPair );
end
end
