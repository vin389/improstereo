function handles = impro_Rectf_Lplane(hObject, handles)

% Data Check 
if ( handles.nPoint < 4 ) 
  msgString = [ 'Warning from impro_Rectf_Lplane().   ' ... 
                'You need at least 4 control points ' ...
                'to run this function.' ] ; 
  msgTitle = 'Warning'; 
  msgbox( msgString, msgTitle, 'warning');
  return; 
end

% Control points triangulation
handles = impro_CtrlPointsTriangulation( hObject, handles );

% Calculate rpx of a photo (the first-left photo) for user's reference.
rpxPhoto = norm( squeeze(handles.CtrlPoints3D(1,1,4,:) - ...
                         handles.CtrlPoints3D(1,1,2,:) ) ) / ...
           norm( squeeze(handles.CtrlPoints(1,1,4,:) - ...
                         handles.CtrlPoints(1,1,2,:) ) ) ;

% Determine default values of expan and rectfSize
% They are determined roughly by image coord. without considering 
% 3D geometric coord. trans. 

estSizeX = 0;
estSizeY = 0;
for iPair = 1:handles.nPair
  for iLR = 1:handles.nLR
    for iPoint = 1:handles.nPoint
      icpx(iPoint) = handles.CtrlPoints(iPair, iLR, iPoint, 1);
      icpy(iPoint) = handles.CtrlPoints(iPair, iLR, iPoint, 2);
    end
    % estimated size x is distance (P2-P1) + distance (P3-P2)  
    estSizeXi = sqrt( (icpx(2)-icpx(1))^2 + (icpy(2)-icpy(1))^2 ) ...
              + sqrt( (icpx(3)-icpx(2))^2 + (icpy(3)-icpy(2))^2 ); 
    % estimated size y is distance P4-P2
    estSizeYi = sqrt( (icpx(4)-icpx(2))^2 + (icpy(4)-icpy(2))^2 ) ; 
    % find the maximal estimated sizes along X and Y (in image coord.) 
    if ( estSizeXi > estSizeX ) 
      estSizeX = estSizeXi;
    end
    if ( estSizeYi > estSizeY ) 
      estSizeY = estSizeYi;
    end
  end
end
% conservatively increase the estimated sizes
estSizeX = fix( estSizeX * 1.0 / 100 + 1 ) * 100; 
estSizeY = fix( estSizeY * 1.0 / 100 + 1 ) * 100; 

% Ask user to input range of matching
%   Input 4: expan:      Expansion of the rectified image (in pixel). 
%              expan(1): The expansion along X.
%              expan(2): The expansion along Y.
%                        The most left-lower pixel of rectified image is at 
%                        ( -Expan(1)*Rpx, -Expan(2)*Rpx ) of the 
%                        rectification coord. system. 
%                        For example, if Expan is [ 200 100 ], and Rpx is 
%                        0.1 mm, the left-low pixel is at (-20 mm, -10 mm). 
%            rectfSize:  The expected size of rectified image.
%                        ImgSize(1): Width.   
%                        ImgSize(2): Height.
%                        The range of rectified image is:
%                        X: (-Expan(1)*Rpx) -> (-Expan(1)+ImgSize(1)-1)*Rpx 
%                        Y: (-Expan(2)*Rpx) -> (-Expan(2)+ImgSize(2)-1)*Rpx 

options.Resize='on';
options.WindowStyle='normal';
options.Interpreter='tex';
inpans = inputdlg( { 'Range of Pair'   ...
                     'Range of iLR'    ...
                     'Rpx (default L-1 photo P2-4)' ...
                     'Expansion (at lower-left, in pixel)' ...
                     'Expected rectf image size' ...
                    } , ...
                    'Range of rectification', 1, ...
                    { ['  1:'  num2str(handles.nPair) ] ...
                      ['  1:'  num2str(handles.nLR)   ] ...
                       sprintf('  %10.4e',rpxPhoto) ...
                      '  [ 300 300 ]' ...
                       sprintf('  [ %d %d ]', estSizeX+2*300, estSizeY+2*300 ) ...
                    } , ...
                    options );
% if user press CANCEL, then return.                     
if ( size(inpans,1) < 1 ) 
  return
end

iPairRange  = str2num(inpans{1});
iLRRange    = str2num(inpans{2});
rpxRectf    = str2num(inpans{3});  
expan       = str2num(inpans{4});
rectfSize   = str2num(inpans{5});

handles.rpxRectf = rpxRectf; 

% allocate memory 
rectfMeasureRange = zeros(handles.nPair, handles.nLR, 4); 
% For each pair
for iPair = iPairRange
  % For each camera
  for iLR = iLRRange
    % Get 3D coord. of ctrl points in left cam coord.
    iCtrlPoint3D(:,:) = handles.CtrlPoints3D(iPair,iLR,:,:);
    % Find the coord. sys.
    vx1p = iCtrlPoint3D(2,:) - iCtrlPoint3D(1,:); 
    vy   = iCtrlPoint3D(4,:) - iCtrlPoint3D(2,:); 
    vz1  = cross( vx1p, vy ); 
    vx1  = cross( vy, vz1 ); 
    vx2p = iCtrlPoint3D(3,:) - iCtrlPoint3D(2,:); 
    vz2  = cross( vx2p, vy ); 
    vx2  = cross( vy, vz2 ); 
    vx1  = vx1 / norm(vx1); 
    vx2  = vx2 / norm(vx2); 
    lenP12 = norm(vx1p); 
    lenP23 = norm(vx2p); 
    lenP42 = norm(vy); 
    vy   = vy  / norm(vy); 
    ori = iCtrlPoint3D(2,:);
    % the starting point of generation of points
    x1 = -lenP12; 
    y1 = 0;
    nX = rectfSize(1);
    nY = rectfSize(2);
    % The rectfMeasureRange is the range of measurement region of this 
    % rectified image. 
    % Note: The rectfMeasureRange is a rectangle defined by the "corrected"
    % control points. The deformed image may be out of the range especially
    % when it has a shear deformation. 
    % range of X is rectfMeasureRange(1) and (2)
    % range of Y is rectfMeasureRange(3) and (4)
    rectfMeasureRange(iPair,iLR, 1) = expan(1) + 1; 
    rectfMeasureRange(iPair,iLR, 2) = rectfMeasureRange(iPair,iLR, 1) + ...
                                    round( (lenP12 + lenP23) / rpxRectf ); 
    rectfMeasureRange(iPair,iLR, 4) = nY - expan(2); 
    rectfMeasureRange(iPair,iLR, 3) = rectfMeasureRange(iPair,iLR, 4) - ...
                                      round( (lenP42-y1) / rpxRectf );
    handles.rectfMeasureRange = rectfMeasureRange;      
    % Each call only calculates one column of pixels. 
    iMesh3D  = zeros(3,nY);  
    % 2D image coord. of the rectified image 
    iMesh2Dx = zeros(nY,nX,'single');
    iMesh2Dy = zeros(nY,nX,'single');
    % Loop along X
    for iX = 1: nX
      xx = x1 + (iX-1-expan(1))*rpxRectf; 
      % Loop along Y
      for iY = 1: nY
        % When iY==(nY-expan(2)), yy = y1.
        yy = y1 + ((nY-expan(2))-iY) * rpxRectf; 
        % Since it is L-shaped, we need to know the point is at left wing 
        % or right wing of the L-shape. 
        if ( xx < 0.0 )  % left wing
          iMesh3D(:,iY) = ori + xx * vx1 + yy * vy; 
        else             % right wing
          iMesh3D(:,iY) = ori + xx * vx2 + yy * vy; 
        end          
      end
      % Find 2D image coord. of this column of pixels.
      % ( iMesh3D -> iMesh2D)
      if (iLR == 1)
        [xp,dxpdom,dxpdT,dxpdf,dxpdc,dxpdk,dxpdalpha] = ...
          project_points2(iMesh3D, [0;0;0], [0;0;0], ...
          handles.calib3d.fc_left, handles.calib3d.cc_left, ...
          handles.calib3d.kc_left, handles.calib3d.alpha_c_left );
      else
        [xp,dxpdom,dxpdT,dxpdf,dxpdc,dxpdk,dxpdalpha] = ...
          project_points2(iMesh3D, [0;0;0], [0;0;0], ...
          handles.calib3d.fc_right, handles.calib3d.cc_right, ...
          handles.calib3d.kc_right, handles.calib3d.alpha_c_right );
          % Note: The om and T are zeros because the iMesh3D is in the 
          % "right"-cam coord. system. 
      end
      iMesh2Dx(:,iX) = xp(1,:);
      iMesh2Dy(:,iX) = xp(2,:);     
      
      % output a text message every dispNline lines
      dispNline = 500;
      if (iX/dispNline == round(iX/dispNline))
        disp(sprintf(' Pair:%d. iLR:%d. colmn %d of %d: project_points2 to 2D...', iPair, iLR, iX, nX) );
        drawnow;
      end
    % End of loop along theta
    end 

    % Re-sampling rectified image
    [handles,iPhotoimg] = ... 
         impro_loadPhoto(hObject, handles, iPair, iLR); 
    iRectfImg = cvRemap(uint8(iPhotoimg), iMesh2Dx, iMesh2Dy );   
    
    % Update information
    handles.iRectf{iLR}.nPoint = handles.nPoint; 
    tstr= handles.filelistRectf{iPair,iLR};
    handles.iRectf{iLR}.file = [tstr(1:size(tstr,2)-4) '.jpg' ]; 
    
    % Save iTmplt to template file
    % Create the folder if it does not exist
    if ( ~exist(handles.RectfPath{iLR}, 'dir') )
        mkdir(handles.RectfPath{iLR});
    end
%    if ( ~exist('iRectf', 'var') ) % This three lines were added on 2012/
%        iRectf = handles.iRectf;   % 12/29 due to an error that iRectf does
%    end                            % not exist. It is strange that how this
%                                   % program ran well in earier days. 
    iRectf = handles.iRectf{iLR}; % Modified by vince. 2013/04/23

    save([handles.RectfPath{iLR} handles.filelistRectf{iPair,iLR}], 'iRectf');
    % Save image
    imwrite( iRectfImg, [handles.RectfPath{iLR} handles.iRectf{iLR}.file] );   
      
  % end of iLR loop
  end
% end of iPair loop 
end

end
