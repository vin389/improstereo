function [dx dy th] = impro_findCamMove(X0, XN)
% This function finds an optimal movement parameters (dx, dy, th) 
% according to a set of fixed points. 
% Input parameters:
%      X0:  image coordinates of the fixed points in the initial photo.
%           array size: (N,2). N is the number of the fixed points. 
%      XN:  image coordinates of the fixed points in the moved photo.
%           array size: (N,2). N is the number of the fixed points. 
%
% Output parameters:
%      dx:  pixel movement along x direction (image coordinate)
%      dy:  pixel movement along y direction (image coordinate)(downward) 
%      th:  angular rotation about image origin (0,0) (clockwise) 
% 
%      which is the optimal set to the equations:
% 
%      XN(1,1) = cos(th)*X0(1,1) - sin(th)*X0(1,2) + dx
%      XN(1,2) = sin(th)*X0(1,1) + cos(th)*X0(1,2) + dy
%
%      XN(2,1) = cos(th)*X0(2,1) - sin(th)*X0(2,2) + dx
%      XN(2,2) = sin(th)*X0(2,1) + cos(th)*X0(2,2) + dy
%
%      XN(3,1) = cos(th)*X0(3,1) - sin(th)*X0(3,2) + dx
%      XN(3,2) = sin(th)*X0(3,1) + cos(th)*X0(3,2) + dy
%
%      XN(4,1) = cos(th)*X0(4,1) - sin(th)*X0(4,2) + dx
%      XN(4,2) = sin(th)*X0(4,1) + cos(th)*X0(4,2) + dy
%
%      ......
%

dx = 1; 
dy = 1; 
th = 0.001; 
DX = [dx;dy;th];

% optimization options
opt.Display = 'off'; 
opt.FunValCheck = 'on';
opt.TolFun = 1e-9; 
opt.TolX = 1e-9; 

optimal_x = fminsearch(@(x) impro_findCamMove_Errfunc(X0,XN,x), DX, opt ); 

dx = optimal_x(1);
dy = optimal_x(2);
th = optimal_x(3);

end 

function err = impro_findCamMove_Errfunc(X0,XN,DX)
dx = DX(1); 
dy = DX(2);
th = DX(3);
N = size(X0,1); 
% check 
if ( N ~= size(XN,1) ) 
   fprintf('impro_findCamMove_Errfunc Err: X0,XN must be same size.\n'); 
   err = 0+1i; 
   return; 
end
% calculate the error
err = 0;
for i=1:N
  err = err ...
      + norm( [XN(i,1) - (cos(th)*X0(i,1) - sin(th)*X0(i,2) + dx); ... 
               XN(i,2) - (sin(th)*X0(i,1) + cos(th)*X0(i,2) + dy)],2 );
end 
 %fprintf('Trial: %f %f %f. Error: %f\n', dx, dy, th, err);
end  










