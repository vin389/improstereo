function [ output_img ] = imerosion(  input_img, struct_elm  )
%UNTTLED2 Summary of this function goes here
%   Detailed explanation goes here
[height width] = size(struct_elm);
[rows columns] = size(input_img);
halfWidth = floor(width / 2);
halfHeight = floor(height / 2);
dia_out = zeros(rows + 2*halfHeight , columns + 2*halfWidth);
dia_in = [zeros(halfHeight,columns+2*halfWidth); zeros(rows,halfWidth) input_img zeros(rows,halfWidth); zeros(halfHeight,columns+2*halfWidth)]
for col = (halfWidth+1) : columns
    x1 = col - halfWidth;
    x2= col + halfWidth;
    for row = (halfWidth+1) : rows
        y1 = row - halfHeight;
        y2 = row + halfHeight;

         
		 if(rem(width, 2) == 1)
			if(rem(height, 2) == 1)
				if(dia_in(row,col) == 1)
					if(isequal((dia_in(y1:y2, x1:x2)& struct_elm), struct_elm))
						 dia_out(row, col) = dia_out(row, col)|struct_elm(halfHeight+1, halfWidth+1);
					 end
				end
			else
				if(dia_in(row,col) == 1)
					if(isequal((dia_in(y1:(y2-1), x1:x2)& struct_elm), struct_elm))
						 dia_out(row, col) = dia_out(row, col)|struct_elm(halfHeight+1, halfWidth+1);
					 end
				end
			end
		else
			if(rem(height, 2) == 1)
				if(dia_in(row,col) == 1)
					if(isequal((dia_in(y1:y2, x1:(x2-1))& struct_elm), struct_elm))
						 dia_out(row, col) = dia_out(row, col)|struct_elm(halfHeight+1, halfWidth+1);
					 end
				end
			else
				if(dia_in(row,col) == 1)
					if(isequal((dia_in(y1:(y2-1), x1:(x2-1))& struct_elm), struct_elm))
						 dia_out(row, col) = dia_out(row, col)|struct_elm(halfHeight+1, halfWidth+1);
					 end
				end
			end
		end
		 
    end
end

output_img = dia_out(halfWidth+1:rows, halfHeight+1:columns);

end