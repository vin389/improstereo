function handles = impro_3dMeshStrain_Plane( ...
                        hObject, handles, iPair, iLR, ...
                        uxGrid, uyGrid, strain2Dxx, strain2Dyy, ...
                        strain2Dxy, ...
                        xGrid, yGrid, ...
                        infoTM, patchOptions )
% This function generates 3D mesh of the measured results
% plots the surface on the photos.  

% Check
if ( isfield( handles, 'calib3d') == 0 )
  msgbox('Load 3D Calib Data first.','Warning');
  return;
end

% Find axes of the plane system
iCtrlPoint3D(:,:) = handles.CtrlPoints3D(handles.iPair,1,:,:);
vx = iCtrlPoint3D(3,:) - iCtrlPoint3D(1,:); 
x2 = norm(vx);
vx = vx/x2;
vy = iCtrlPoint3D(2,:) - iCtrlPoint3D(1,:); 
y2 = norm(vy);
vz = cross(vx, vy);
vz = vz/norm(vz);
vy = cross(vz, vx);
vy = vy/norm(vy); 
ori = iCtrlPoint3D(1,:);
x1 = 0; 
y1 = 0;
% Find mesh of the plane face (xx=x1~x2) (yy=y1~y2)
m=size(uxGrid,1); 
n=size(uxGrid,2);
[vtx faces] = impro_planeFace(vx,vy,vz,ori,x1,x2,y1,y2, m, n);

% modify to log scale (added by vince 2018/09/12)
% if user's caxis contains negative values, use linear scale. 
% otherwise, use log scale
if (sum(patchOptions.caxis(:) <= 0) == 0) 
    useLogScale = true;
else
    useLogScale = false;
end
  
% Convert to image coord and set active axes object. 
hh=figure; pcolor(uxGrid); close(hh);
set(handles.slPair, 'Value', iPair);
handles.iPair = iPair;
handles = impro_updSlPair(hObject,handles);
if (iLR==1) 
  [xp] = project_points2( ...
    vtx', [0 0 0], [0;0;0], handles.calib3d.fc_left, ...
    handles.calib3d.cc_left, handles.calib3d.kc_left, ...
    handles.calib3d.alpha_c_left );
  axes(handles.axPhotoLeft);
  xp = [xp' zeros(size(xp,2),1)];
end  
if (iLR==2)
  %  Right
  [xp] = project_points2( ...
    vtx', handles.calib3d.om, handles.calib3d.T, ...
    handles.calib3d.fc_right, ...
    handles.calib3d.cc_right, handles.calib3d.kc_right, ...
    handles.calib3d.alpha_c_right );
  axes(handles.axPhotoRigt);
  xp = [xp' zeros(size(xp,2),1)];
end

% Plot strain2Dyy
% The strain2Dyy is in image coord. and therefore is upside down.
% We need to flip it before plotting. 

% patchOptions.field can be an array, e.g., [1 2 3 4] 
%   (by vince 2014/5/15)
for iField = patchOptions.field
    % plot the first field that user assigned (by vince 2013/10/15)
    % add figName for later imwrite (by vince 2014/5/15)
    if (iField == 1) 
      pFieldFilter = uxGrid; 
      figName = sprintf('Pair-%d.Cam-%d.Ux', iPair, iLR) ;
    elseif (iField == 2) 
      pFieldFilter = uyGrid;
      figName = sprintf('Pair-%d.Cam-%d.Uy', iPair, iLR) ;
    elseif (iField == 3) 
      pFieldFilter = strain2Dxx;   
      figName = sprintf('Pair-%d.Cam-%d.Exx', iPair, iLR) ;
    elseif (iField == 4) 
      pFieldFilter = strain2Dyy;   
      figName = sprintf('Pair-%d.Cam-%d.Eyy', iPair, iLR) ;
    elseif (iField == 5) 
      pFieldFilter = strain2Dxy;   
      figName = sprintf('Pair-%d.Cam-%d.Exy', iPair, iLR) ;
    elseif (iField == 6)   % crack opening (45), added by vince 2015/6/23
      [crack_opening crack_sliding] = ...
          impro_crackField(uxGrid, uyGrid, 45); 
      pFieldFilter = crack_opening;   
      figName = sprintf('Pair-%d.Cam-%d.Cr45_opn', iPair, iLR) ;
    elseif (iField == 7)   % crack opening (45), added by vince 2015/6/23
      [crack_opening crack_sliding] = ...
          impro_crackField(uxGrid, uyGrid, 45); 
      pFieldFilter = crack_sliding;   
      figName = sprintf('Pair-%d.Cam-%d.Cr45_sld', iPair, iLR) ;
    elseif (iField == 8)   % crack opening (135), added by vince 2015/6/23
      [crack_opening crack_sliding] = ...
          impro_crackField(uxGrid, uyGrid, 135); 
      pFieldFilter = crack_opening;   
      figName = sprintf('Pair-%d.Cam-%d.Cr135_opn', iPair, iLR) ;
    elseif (iField == 9)   % crack opening (135), added by vince 2015/6/23
      [crack_opening crack_sliding] = ...
          impro_crackField(uxGrid, uyGrid, 135); 
      pFieldFilter = crack_sliding;   
      figName = sprintf('Pair-%d.Cam-%d.Cr135_sld', iPair, iLR) ;      
    elseif (iField == 10)   % crack opening maximal, modified by vince 2016/5/1
	  for crackDeg = [0 22.5 45 67.5 90 112.5 135 157.5]
		  [crack_opening crack_sliding] = ...
			  impro_crackField(uxGrid, uyGrid, crackDeg); 
	      if (crackDeg == 0) 
			max_crack = crack_opening; 
	      else 
		    max_crack = max(crack_opening, max_crack);
		  end
	  end
      pFieldFilter = max_crack;
      figName = sprintf('Pair-%d.Cam-%d.Crack_opn', iPair, iLR);
    elseif (iField == 11)   % crack sliding maximal, modified by vince 2016/5/1
	  for crackDeg = [0 22.5 45 67.5 90 112.5 135 157.5]
		  [crack_opening crack_sliding] = ...
			  impro_crackField(uxGrid, uyGrid, crackDeg); 
	      if (crackDeg == 0) 
			max_crack = crack_sliding; 
	      else 
		    max_crack = max(crack_sliding, max_crack);
		  end
	  end
      pFieldFilter = max_crack;
      figName = sprintf('Pair-%d.Cam-%d.Crack_sld', iPair, iLR);
    end    
    %pFieldFilter = strain2Dyy; 
    %pFieldFilter = uyGrid; 

    % filter values that are out of user-defined range (2014/1/4 by vince) 
    filterMin = str2num(get(handles.edVisibleMatchRangeMin, 'String'));
    filterMax = str2num(get(handles.edVisibleMatchRangeMax, 'String'));
    pFieldFilter(or(infoTM.Acc < filterMin, infoTM.Acc > filterMax)) = nan; 
    %pFieldFilter( infoTM.Acc < 0.97 ) = nan; 
    icount=0;
    for im=m:-1:1
      for in=1:n
        icount=icount+1;
        pField(icount) = pFieldFilter(im,in);
      end
    end
    
    % Show patch (3d mesh) on a separate figure/axis 
    %   (added by vince, 2015-07-24, modified, 2016-05-02)
    hfig = figure('units','normalized','outerposition',[0 0.05 1 .95]); 
    title([figName '_3dMesh'], 'interpreter','none'); 
           
    imagesc(imread([handles.PhotoPath{iLR} handles.filelistPhoto{iPair,iLR}]));
    axis image;  
    
    % Set colormap and caxis range
    reversed = 0; 
    colormapUserValue   = get(handles.popmenuColormap, 'Value'); 
    if (colormapUserValue > 13) % there are 13 colormaps and 13 reversed ones
       colormapUserValue = colormapUserValue - 13; 
       reversed = 1;
    end
    colormapUserStrings = get(handles.popmenuColormap, 'String'); 
    thecolormap = colormap(colormapUserStrings{colormapUserValue});
    if (reversed == 1) 
        colormapsize = size(thecolormap, 1); 
        thecolormap(1:colormapsize,:) = thecolormap(colormapsize:-1:1,:);
    end
    thecolormap(1,:) = 1.0;    % set white to those out of range
    thecolormap(end,:) = 1.0;  % set white to those out of range
    colormap(thecolormap);
    % caxis([min(pField) max(pField)]);
    % caxis([-0.01 0.01]); 
    if (useLogScale)
        if ( size(patchOptions.caxis,1) * size(patchOptions.caxis,2) == 2) 
          logCaxis = log(logspace(log10(patchOptions.caxis(1)), log10(patchOptions.caxis(2)), 10)); 
        else
          logCaxis = log(patchOptions.caxis); 
        end
        caxis([logCaxis(1) logCaxis(end)]); 
        colorbar('FontSize',11,'YTick', logCaxis, 'YTickLabel', round(exp(logCaxis),2));
    else
        if ( size(patchOptions.caxis,1) * size(patchOptions.caxis,2) == 2)
          caxis( patchOptions.caxis );
        else
          caxis([min(pField) max(pField)]);
        end  
    end
  
    % Get transparency (alpha = 1- transparency)
    alpha = get(handles.slProjAlpha, 'Value'); 

    % Plot the mesh using patch 
    plotFieldLimit = pField;
    plotFieldLimit(plotFieldLimit < patchOptions.caxis(1)) = patchOptions.caxis(1);
    plotFieldLimit(plotFieldLimit > patchOptions.caxis(end)) = patchOptions.caxis(end);    
    if (useLogScale)
        plotFieldLimit = log(plotFieldLimit); 
    end
    colormap(thecolormap);
    hPatch = patch('Vertices',xp,'Faces',faces, ...
                   'CData',plotFieldLimit,'FaceAlpha',alpha, ...
                   'EdgeColor','white', 'EdgeAlpha', alpha/2, 'FaceColor','flat' );

    %  fig to image file (jpg)            
    if (iLR == 1) 
%        theFigFrame = getframe(handles.axPhotoLeft);
         theFigFrame = getframe(hfig); % vince 2015-07-24
    else
%        theFigFrame = getframe(handles.axPhotoRigt);
         theFigFrame = getframe(hfig); % vince 2015-07-24
    end
    imwrite(theFigFrame.cdata, [handles.ListPath figName '_3dMesh.jpg']);

    delete(hPatch); 
    close(hfig);
    
% end of for iField = patchOptions.field(1) 
end    

end
