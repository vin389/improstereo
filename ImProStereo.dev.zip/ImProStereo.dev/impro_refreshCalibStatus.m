function handles = impro_refreshCalibStatus(hObject, handles)
return
% This function refreshes the calibration status indicator

% check calibration data and update handles.popmenuCalibStatus
calibStringArray = {};
calibStringArray{1 } = 'not loaded yet';
calibStringArray{2 } = 'L-Fx: N/A';
calibStringArray{3 } = 'L-Fy: N/A';
calibStringArray{4 } = 'L-Cx: N/A';
calibStringArray{5 } = 'L-Cy: N/A';
calibStringArray{6 } = 'L-K1: N/A';
calibStringArray{7 } = 'L-K2: N/A';
calibStringArray{8 } = 'L-K3: N/A';
calibStringArray{9 } = 'L-K4: N/A';
calibStringArray{10} = 'L-K5: N/A';
calibStringArray{11} = 'L-Alpha: N/A';
calibStringArray{12} = 'R-Fx: N/A';
calibStringArray{13} = 'R-Fy: N/A';
calibStringArray{14} = 'R-Cx: N/A';
calibStringArray{15} = 'R-Cy: N/A';
calibStringArray{16} = 'R-K1: N/A';
calibStringArray{17} = 'R-K2: N/A';
calibStringArray{18} = 'R-K3: N/A';
calibStringArray{19} = 'R-K4: N/A';
calibStringArray{20} = 'R-K5: N/A';
calibStringArray{21} = 'R-Alpha: N/A';
calibStringArray{22} = 'Stereo-R1: N/A';
calibStringArray{23} = 'Stereo-R2: N/A';
calibStringArray{24} = 'Stereo-R3: N/A';
calibStringArray{25} = 'Stereo-T1: N/A';
calibStringArray{26} = 'Stereo-T2: N/A';
calibStringArray{27} = 'Stereo-T3: N/A';

if (isfield(handles, 'calib3d') ) 
  if (isfield(handles.calib3d, 'fc_left'   ) && ...
    isfield(handles.calib3d, 'cc_left'   ) && ...
    isfield(handles.calib3d, 'kc_left'   ) && ...
    isfield(handles.calib3d, 'alpha_c_left'   ) && ...
    isfield(handles.calib3d, 'fc_right'   ) && ...
    isfield(handles.calib3d, 'cc_right'   ) && ...
    isfield(handles.calib3d, 'kc_right'   ) && ...
    isfield(handles.calib3d, 'alpha_c_right'  ) && ...
    isfield(handles.calib3d, 'om'  ) && ...
    isfield(handles.calib3d, 'T') )  
    calibStringArray{1 } = 'Loaded.';
    calibStringArray{2 } = sprintf('L-Fx: %8.2f', handles.calib3d.fc_left(2));
    calibStringArray{3 } = sprintf('L-Fy: %8.2f', handles.calib3d.fc_left(1));
    calibStringArray{4 } = sprintf('L-Cx: %8.2f', handles.calib3d.cc_left(2));
    calibStringArray{5 } = sprintf('L-Cy: %8.2f', handles.calib3d.cc_left(1));
    calibStringArray{6 } = sprintf('L-K1: %8.4f', handles.calib3d.kc_left(1));
    calibStringArray{7 } = sprintf('L-K2: %8.4f', handles.calib3d.kc_left(2));
    calibStringArray{8 } = sprintf('L-K3: %8.4f', handles.calib3d.kc_left(3));
    calibStringArray{9 } = sprintf('L-K4: %8.4f', handles.calib3d.kc_left(4));
    calibStringArray{10} = sprintf('L-K5: %8.4f', handles.calib3d.kc_left(5));
    calibStringArray{11} = sprintf('L-Alpha: %8.4f', handles.calib3d.alpha_c_left(1));
    calibStringArray{12} = sprintf('L-Fx: %8.2f', handles.calib3d.fc_right(2));
    calibStringArray{13} = sprintf('L-Fy: %8.2f', handles.calib3d.fc_right(1));
    calibStringArray{14} = sprintf('L-Cx: %8.2f', handles.calib3d.cc_right(2));
    calibStringArray{15} = sprintf('L-Cy: %8.2f', handles.calib3d.cc_right(1));
    calibStringArray{16} = sprintf('L-K1: %8.4f', handles.calib3d.kc_right(1));
    calibStringArray{17} = sprintf('L-K2: %8.4f', handles.calib3d.kc_right(2));
    calibStringArray{18} = sprintf('L-K3: %8.4f', handles.calib3d.kc_right(3));
    calibStringArray{19} = sprintf('L-K4: %8.4f', handles.calib3d.kc_right(4));
    calibStringArray{20} = sprintf('L-K5: %8.4f', handles.calib3d.kc_right(5));
    calibStringArray{21} = sprintf('L-Alpha: %8.4f', handles.calib3d.alpha_c_right(1));
    calibStringArray{22} = sprintf('Stereo-R1: %8.4f', handles.calib3d.om(1));
    calibStringArray{23} = sprintf('Stereo-R2: %8.4f', handles.calib3d.om(2));
    calibStringArray{24} = sprintf('Stereo-R3: %8.4f', handles.calib3d.om(3));
    calibStringArray{25} = sprintf('Stereo-T1: %8.2f', handles.calib3d.T(1));
    calibStringArray{26} = sprintf('Stereo-T2: %8.2f', handles.calib3d.T(2));
    calibStringArray{27} = sprintf('Stereo-T3: %8.2f', handles.calib3d.T(3)); 
  else
    calibStringArray{1 } = 'loaded but not complete';  
  end % end if all calib3d fields exist  
else    
    calibStringArray{1 } = 'not loaded yet'; 
end  % end if isfield(handles, 'calib3d')
set(handles.popmenuCalibStatus, 'String', calibStringArray);
end





