function handles = impro_getFileList(hObject, handles)

% Get file list from uigetfile
[listfile listpath] = uigetfile('*.*');
if ( isnumeric(listfile) && isnumeric(listpath) ) 
  return     
end
handles.ListFile = listfile;
handles.ListPath = listpath;

% Open file
fid = fopen([ listpath listfile ],'r');
if ( fid == -1 ) 
  errordlg('Can not open your file.', 'File Error');
  return
end

% Clear data
handles.PhotoPath = {};
handles.filelistPhoto = {};
handles.TmpltPath = {};
handles.filelistTmplt = {};
handles.MatchPath = {};
handles.filelistMatch = {};
handles.RectfPath = {};
handles.filelistRectf = {};
  
% Read data from file
while (true)
  
  keyword = fscanf( fid, '%s', [1 1] );
  
  if ( size(keyword,1) == 0) 
    if ( feof(fid) )
      break;
    else  
      continue; 
    end
    
  elseif ( strcmpi(keyword, '/*' ) == 1 ) 
    % comments 
    while (true)
      keyword = fscanf( fid, '%s', [1 1] );
      if ( strcmp(lower(keyword), '*/') == 1) 
        break;
      end
    end
    
  elseif ( strcmpi(keyword, 'version') == 1 )
    % version of ImProRigid that the input file for.
    % (Note: Not the version of this program.) 
    fileVer = fscanf( fid, '%f', [1,1] ); 
    handles.fileVer = fileVer; 
    
  elseif ( strcmpi(keyword, 'nPair') == 1 ) 
    nPair = fscanf(fid, '%d', [1,1] );
    handles.nPair  = nPair;
    
  elseif ( strcmpi(keyword, 'nLR') == 1 || ...
           strcmpi(keyword, 'nCam') == 1 ) 
    nLR   = fscanf(fid, '%d', [1,1] );
    handles.nLR    = nLR;
    
  elseif ( strcmpi(keyword, 'PhotoPath' ) == 1 ) 
    iLRStr = fscanf( fid, '%s', [1 1] );
    % Convert 'L' to 1 and 'R' to 2
    if ( strcmpi(iLRStr, 'L') || strcmpi(iLRStr, '1'))
      iLR = 1;
    elseif ( strcmpi(iLRStr, 'R') || strcmpi(iLRStr, '2'))
      iLR = 2;
    else
      iLR = str2num( iLRStr );
    end
    PhotoPath{iLR} = fscanf(fid, '%s', [1 1]) ;
    % Check keyword (added by Vince on 2012/04/28)   
    tmpstr = PhotoPath{iLR};
    if ( size(tmpstr,2) >=16 && ...
         strcmpi( tmpstr(1:16), '$$FileListPath$$') ) 
        if ( tmpstr(17) == '\' || tmpstr(17) == '/' )
            tmpstr = [listpath tmpstr(18:end)];
        else
            tmpstr = [listpath tmpstr(17:end)];
        end
        PhotoPath{iLR} = tmpstr; 
    end
    % Add a slash at the end if needed.
    if ( PhotoPath{iLR}(size(PhotoPath{iLR},2)) ~= '/' && ... 
         PhotoPath{iLR}(size(PhotoPath{iLR},2)) ~= '\' )
      PhotoPath{iLR} = [ PhotoPath{iLR} '/' ];
    end
    handles.PhotoPath{iLR} = PhotoPath{iLR};
    
  elseif ( strcmpi(keyword, 'Photo' ) == 1 )
    iPair = fscanf( fid, '%d', [1,1] );
    iLRStr = fscanf( fid, '%s', [1 1] );
    if ( strcmpi(iLRStr, 'L') || strcmpi(iLRStr, '1'))
      iLR = 1;
    elseif ( strcmpi(iLRStr, 'R') || strcmpi(iLRStr, '2'))
      iLR = 2;
    else
      iLR = str2num( iLRStr );
    end
    handles.filelistPhoto{iPair,iLR} = fscanf(fid, '%s', [1 1]);
    
  elseif ( strcmpi(keyword, 'TmpltPath' ) == 1 ) 
    iLRStr = fscanf( fid, '%s', [1 1] );
    if ( strcmpi(iLRStr, 'L') || strcmpi(iLRStr, '1'))
      iLR = 1;
    elseif ( strcmpi(iLRStr, 'R') || strcmpi(iLRStr, '2'))
      iLR = 2;
    else
      iLR = str2num( iLRStr );
    end
    TmpltPath{iLR} = fscanf(fid, '%s', [1 1]) ;
    % Check keyword (added by Vince on 2012/04/28)
    tmpstr = TmpltPath{iLR};
    if ( size(tmpstr,2) >=16 && ...
         strcmpi( tmpstr(1:16), '$$FileListPath$$') ) 
        if ( tmpstr(17) == '\' || tmpstr(17) == '/' )
            tmpstr = [listpath tmpstr(18:end)];
        else
            tmpstr = [listpath tmpstr(17:end)];
        end
        TmpltPath{iLR} = tmpstr; 
    end
    % Add a slash at the end if needed.
    if ( TmpltPath{iLR}(size(TmpltPath{iLR},2)) ~= '/' && ...
         TmpltPath{iLR}(size(TmpltPath{iLR},2)) ~= '\' )
      TmpltPath{iLR} = [ TmpltPath{iLR} '/' ];
    end
    handles.TmpltPath{iLR} = TmpltPath{iLR};
    
  elseif ( strcmpi(keyword, 'Tmplt' ) == 1 )
    iPair = fscanf( fid, '%d', [1,1] );
    iLRStr = fscanf( fid, '%s', [1 1] );
    if ( strcmpi(iLRStr, 'L') || strcmpi(iLRStr, '1'))
      iLR = 1;
    elseif ( strcmpi(iLRStr, 'R') || strcmpi(iLRStr, '2'))
      iLR = 2;
    else
      iLR = str2num( iLRStr );
    end
    handles.filelistTmplt{iPair,iLR} = fscanf(fid, '%s', [1 1]);
    
  elseif ( strcmpi(keyword, 'MatchPath' ) == 1 ) 
    iLRStr = fscanf( fid, '%s', [1 1] );
    if ( strcmpi(iLRStr, 'L') || strcmpi(iLRStr, '1'))
      iLR = 1;
    elseif ( strcmpi(iLRStr, 'R') || strcmpi(iLRStr, '2'))
      iLR = 2;
    else
      iLR = str2num( iLRStr );
    end
    MatchPath{iLR} = fscanf(fid, '%s', [1 1]) ;
    % Check keyword (added by Vince on 2012/04/28)   
    tmpstr = MatchPath{iLR};
    if ( size(tmpstr,2) >=16 && ...
         strcmpi( tmpstr(1:16), '$$FileListPath$$') ) 
        if ( tmpstr(17) == '\' || tmpstr(17) == '/' )
            tmpstr = [listpath tmpstr(18:end)];
        else
            tmpstr = [listpath tmpstr(17:end)];
        end
        MatchPath{iLR} = tmpstr; 
    end
    % Add a slash at the end if needed.
    if ( MatchPath{iLR}(size(MatchPath{iLR},2)) ~= '/' && ...
         MatchPath{iLR}(size(MatchPath{iLR},2)) ~= '\')
      MatchPath{iLR} = [ MatchPath{iLR} '/' ];
    end
    handles.MatchPath{iLR} = MatchPath{iLR};
    
  elseif ( strcmpi(keyword, 'Match' ) == 1 )
    iPair = fscanf( fid, '%d', [1,1] );
    iLRStr = fscanf( fid, '%s', [1 1] );
    if ( strcmpi(iLRStr, 'L') || strcmpi(iLRStr, '1'))
      iLR = 1;
    elseif ( strcmpi(iLRStr, 'R') || strcmpi(iLRStr, '2'))
      iLR = 2;
    else
      iLR = str2num( iLRStr );
    end
    handles.filelistMatch{iPair,iLR} = fscanf(fid, '%s', [1 1]);
    
  elseif ( strcmpi(keyword, 'RectfPath' ) == 1 ) 
    iLRStr = fscanf( fid, '%s', [1 1] );
    if ( strcmpi(iLRStr, 'L') || strcmpi(iLRStr, '1'))
      iLR = 1;
    elseif ( strcmpi(iLRStr, 'R') || strcmpi(iLRStr, '2'))
      iLR = 2;
    else
      iLR = str2num( iLRStr );
    end
    RectfPath{iLR} = fscanf(fid, '%s', [1 1]) ;
    % Check keyword (added by Vince on 2012/04/28)   
    tmpstr = RectfPath{iLR};
    if ( size(tmpstr,2) >=16 && ...
         strcmpi( tmpstr(1:16), '$$FileListPath$$') ) 
        if ( tmpstr(17) == '\' || tmpstr(17) == '/' )
            tmpstr = [listpath tmpstr(18:end)];
        else
            tmpstr = [listpath tmpstr(17:end)];
        end
        RectfPath{iLR} = tmpstr; 
    end
    % Add a slash at the end if needed.
    if ( RectfPath{iLR}(size(RectfPath{iLR},2)) ~= '/' && ...
         RectfPath{iLR}(size(RectfPath{iLR},2)) ~= '\'   )
      RectfPath{iLR} = [ RectfPath{iLR} '/' ];
    end
    handles.RectfPath{iLR} = RectfPath{iLR};
      
  elseif ( strcmpi(keyword, 'Rectf' ) == 1 )
    iPair = fscanf( fid, '%d', [1,1] );
    iLRStr = fscanf( fid, '%s', [1 1] );
    if ( strcmpi(iLRStr, 'L') || strcmpi(iLRStr, '1'))
      iLR = 1;
    elseif ( strcmpi(iLRStr, 'R') || strcmpi(iLRStr, '2'))
      iLR = 2;
    else
      iLR = str2num( iLRStr );
    end
    handles.filelistRectf{iPair,iLR} = fscanf(fid, '%s', [1 1]);
    
  end % end of if (after reading each keyword)

end % end of reading file

if ( ~isfield(handles, 'nPoint') ) 
    handles.nPoint = 4; % by default. Can be set by slider or when load control point data. 
end
if ( ~isfield(handles, 'iPair') ) 
    handles.iPair  = 1;
end
if ( ~isfield(handles, 'iLR') ) 
    handles.iLR    = 1;
end
if ( ~isfield(handles, 'iPoint') )
    handles.iPoint = 1;
end

% Setup ui objects and display information
set(handles.slPair, 'Min', 1);
set(handles.slPair, 'Max', nPair);
set(handles.slPair, 'Value', 1);
if ( nPair > 1)
  set(handles.slPair, 'SliderStep', [1./(nPair-1) 1./(nPair-1)] );
else % Modified by Vince (2012/04/14): We should allow nPair == 1. 
  set(handles.slPair, 'SliderStep', [0 0] );  
end
set(handles.txPair, 'String', sprintf('Photo pair %05d', 1) );
set(handles.slPair, 'Enable', 'on');

if (nLR > 1)
  set(handles.slLR,   'Min', 1);
  set(handles.slLR,   'Max', nLR);
  set(handles.slLR,   'Value', 1);
  set(handles.slLR,   'SliderStep', [1./(nLR-1) 1./(nLR-1)] );
  txLR={'Left','Right'};
  set(handles.txLR,   'String', txLR{1} );
  set(handles.slLR,   'Enable', 'on');
else  % Modified by Vince (2012/04/14): We should allow nLR == 1. 
  % set(handles.slLR,   'SliderStep', [0 0] );  
  % if nLR == 1, disable the slider slLR.
  set(handles.slLR,'Enable','off');
end

nPoint = handles.nPoint;
set(handles.slPoint,   'Min', 1);
set(handles.slPoint,   'Max', nPoint);
set(handles.slPoint,   'Value', 1);
if (nPoint > 1)
  set(handles.slPoint,   'SliderStep', [1./(nPoint-1) 1./(nPoint-1)] );
else  % Modified by Vince (2012/04/14): We should allow nPoint == 1. 
  set(handles.slPoint,   'SliderStep', [0 0] );
end
set(handles.slPoint,   'Enable', 'on');

% Call slider call-back function
handles = impro_updSlPair(hObject, handles);
handles = impro_updSlLR(hObject, handles);
handles = impro_updSlPoint(hObject, handles);

end