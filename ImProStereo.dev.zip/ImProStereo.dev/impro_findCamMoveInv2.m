function DX = impro_findCamMoveInv2(X0, XN)
% This function finds an optimal movement parameters (dx, dy, th, sc) 
% according to a set of fixed points. 
% Input parameters:
%      X0:  image coordinates of the fixed points in the initial photo.
%           array size: (N,2). N is the number of the fixed points. 
%      XN:  image coordinates of the fixed points in the moved photo.
%           array size: (N,2). N is the number of the fixed points. 
%
% Output parameters:
%      DX(1):  inverse pixel movement along x direction (image coordinate)
%      DX(2):  inverse pixel movement along y direction (image coordinate)
%      DX(3):  inverse angular rotation about image origin (0,0) (clockwise) 
%      DX(4):  inverse scale of size
% 
%      which is the optimal set to the equations:
% 
%      X0(1,1) = sc *(cos(th)*XN(1,1) - sin(th)*XN(1,2) + dx)
%      X0(1,2) = sc *(sin(th)*XN(1,1) + cos(th)*XN(1,2) + dy)
%
%      X0(2,1) = sc *(cos(th)*XN(2,1) - sin(th)*XN(2,2) + dx)
%      X0(2,2) = sc *(sin(th)*XN(2,1) + cos(th)*XN(2,2) + dy)
%
%      X0(3,1) = sc *(cos(th)*XN(3,1) - sin(th)*XN(3,2) + dx)
%      X0(3,2) = sc *(sin(th)*XN(3,1) + cos(th)*XN(3,2) + dy)
%
%      X0(4,1) = sc *(cos(th)*XN(4,1) - sin(th)*XN(4,2) + dx)
%      X0(4,2) = sc *(sin(th)*XN(4,1) + cos(th)*XN(4,2) + dy)
%
%      ......
%
DX = impro_findCamMove2(XN, X0);

