function handles = impro_updSlPoint(hObject, handles)
% Set the slider disable until this function completes.
set(handles.slPoint,'Enable','off');

% Set ui object properties
handles.iPoint = get(handles.slPoint, 'Value');
handles.iPoint = round(handles.iPoint);
iPoint = handles.iPoint;
set(handles.slPoint, 'Value', iPoint);
set(handles.txPoint, 'String', sprintf('Control Point %02d',iPoint ));

iPair = handles.iPair;

% Template & matched images
%   Define handles.iTmplt
for iLR = 1: handles.nLR
  % Load Template
  handles = impro_loadTmplt(hObject, handles, handles.iPair, iLR, iPoint);
  % Load Match
  handles = impro_loadMatch(hObject, handles, handles.iPair, iLR, iPoint);
end

% Set the slider disable until this function completes.
set(handles.slPoint,'Enable','on');

% 

end