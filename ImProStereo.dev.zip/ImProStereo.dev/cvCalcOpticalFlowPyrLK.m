 % =============================================================
 % Matlab interface of OpenCV optical flow for a sparse feature set using 
 % the iterative Lucas-Kanade method with pyramids (cvCalcOpticalFlowPyrLK)
 % 
 % function [prevPyr, currPyr, currFeatures, status, track_error] = ...
 %          cvCalcOpticalFlowPyrLK( prev, curr, ...
 %                                  prevPyr, currPyr, ...
 %                                  prevFeatures, ...
 %                                  count, winSize, level, ...
 %                                  criteria, flags )
 % 
 %   Input:
 %     prev:         Image of the first frame. If it is a color image (i.e.,
 %                   3-channel) it is converted to a gray image.
 %                   MATLAB data type: uint8()
 %     curr:         Image of the second frame. If it is a color image (i.e.,
 %                   3-channel) it is converted to a gray image.
 %                   MATLAB data type: uint8()
 %     prevPyr:      Buffer for the pyramid for the first frame. Sufficient
 %                   size: (image_width+8)*(image_height+2)/3, or a NULL pointer
 %                   will be inputted. 
 %                   Note: OpenCV's cvCalcOpticalFlowPyrLK changes its 
 %                         prevPyr and/or currPyr internally. However, 
 %                         this function does in a different way. It makes
 %                         a clone of prevPyr for OpenCV. The clone is 
 %                         changed by OpenCV and returned to MATLAB. 
 %                         Therefore, the original inputted MATLAB array 
 %                         prevPyr/currPyr is not changed unless the user 
 %                         uses the same array at output (the left-hand-
 %                         side prevPyr/currPyr).
 %     currPyr:      Similar to prevPyr, used for the second image
 %     prevFeatures: Single precision floating-point array of points for 
 %                   which the flow needs to be found. The image coord. 
 %                   index starts from 1 (to be consistent with MATLAB). 
 %                   MATLAB data type: single()
 %     count:        an integer number of feature points
 %                   MATLAB data type: int32()
 %     winSize:      size of the search window of each pyramid level
 %                   MATLAB data type: int32()
 %     level:        Maximal pyramid level number. If 0, pyramids are not 
 %                   used (single level). If 1, two levels are used, etc.
 %                   MATLAB data type: int32()
 %     criteria:     specific when the iteration process of finding the flow
 %                   for each point on each pyramid level should be stopped
 %                   criteria(1): type: criteria(1)==1 --> CV_TERMCRIT_ITER
 %                                      criteria(1)==2 --> CV_TERMCRIT_EPS
 %                                      criteria(1)==3 --> Both (stop when either reaches)
 %                   criteria(2): max_iter 
 %                   criteria(3): epsilon
 %                   MATLAB data type: double()
 %     flags:        miscellaneous flags: 
 %                       CV_LKFLOW_PYR_A_READY       1
 %                       CV_LKFLOW_PYR_B_READY       2
 %                       CV_LKFLOW_INITIAL_GUESSES   4
 %                       CV_LKFLOW_GET_MIN_EIGENVALS 8
 %                   MATLAB data type: int32()
 %   Output:
 %     prevPyr:      Buffer for the pyramid for the first frame. Sufficient
 %                   size: (image_width+8)*(image_height+2)/3, or a NULL pointer
 %                   will be inputted. 
 %     currPyr:      Similar to prevPyr, used for the second image
 %     currFeatures: Single precision floating-point array of 2D points 
 %                   containing the calculated new positions of the input 
 %                   features in the 2nd image. The image coord. index 
 %                   starts from 1 (to be consistent with MATLAB). 
 %                   MATLAB data type: single()
 %     status:       Array. Every element of the array is set to 1 if the 
 %                   flow for the corresponding feature has been found, 
 %                   0 otherwise.
 %     trackerror:   Array of double numbers containing the difference 
 %                   between patches around the original and moved points. 
 %                   Optional parameters. 
 %
 %     
 % Developed by Yuan-Sen Yang
 % Date: 2011.05.24
 %
 % =============================================================