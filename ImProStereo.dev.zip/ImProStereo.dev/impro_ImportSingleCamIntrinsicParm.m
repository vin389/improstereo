function handles = impro_ImportSingleCamIntrinsicParm(hObject, handles) 

[handles.CalibFile handles.CalibPath] = uigetfile('*.mat');
if ( isnumeric(handles.CalibFile) && isnumeric(handles.CalibPath) ) 
  return     
end

calibSingleCam = load([handles.CalibPath handles.CalibFile]);
handles.calibSingleCam = calibSingleCam; 

end
