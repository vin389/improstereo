function handles = impro_updSlPair(hObject, handles)

% Set the slider disable until this function completes.
set(handles.slPair,'Enable','off');

% Set ui object properties
handles.iPair = get(handles.slPair, 'Value');
handles.iPair = round(handles.iPair);
iPair = handles.iPair; 
set(handles.slPair, 'Value', iPair); 
set(handles.txPair, 'String', sprintf('Photo pair %05d', iPair) );

% Load all images on gui axes when slider object is triggered.
handles = impro_loadAll(hObject,handles);

% Set the slider disable until this function completes.
set(handles.slPair,'Enable','on');

end