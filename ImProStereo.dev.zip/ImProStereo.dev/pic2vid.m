% This function converts multiple JPG files into a video.
% Usage:
%   pic2vid(inDirectory, outFile, outInfo)
%     inDirectory - the directory that contains the JPG files
%     outFile - the video file to generate
%     outInfo - [FrameRate VideoWidth VideoHeight Quality]
% 
% Sample: 
%   pic2vid('c:\dir\', 'c:\dir\v.mp4', [30 1920 1080 85]); 
%   or
%   pic2vid() for GUI interaction 
% 
function pic2vid(inDirectory, outFile, outInfo)

    % Select pic files
    if (exist('inDirectory', 'var') == false || isempty(inDirectory))
        [picFiles, picPath] = uigetfile({'*.jpg','JPG-files (*.jpg)'}, 'MultiSelect','on');
        nPic = numel(picFiles); 
        filesInfo(nPic) = dir([picPath picFiles{nPic}]); 
        for i = 1:nPic
            filesInfo(i) = dir([picPath picFiles{i}]); 
        end
    else
        filesInfo = dir([inDirectory '*.JPG']); 
%        picPath = inDirectory; 
        nPic = numel(filesInfo); 
    end

    % Select output file
    if (exist('outFile', 'var') == false || isempty(outFile))
        [vidFile, vidPath] = uiputfile({'*.mp4','MP4 Files'}, 'Save as');
        outFile = [vidPath vidFile]; 
    end
    
    % Read first image
    img = imread([filesInfo(1).folder '\' filesInfo(1).name]); 
    [imgH0, imgW0, imgD0] = size(img);
    % Set FrameRate, Height, Width, Quality
    if (exist('outInfo', 'var') == false || isempty(outInfo)) 
        prompt={'FrameRate','Width','Height','Quality'};
        name=sprintf('Properties of video of %d pics', nPic); 
        numlines=1;
        defaultanswer={'30',num2str(imgW0),num2str(imgH0),'85'};
        options.Resize='on';
        options.WindowStyle='normal';
        options.Interpreter='tex';
        inpans=inputdlg(prompt,name,numlines,defaultanswer,options);
        if (isempty(inpans)) 
            return;
        end
    else
        inpans{1} = num2str(outInfo(1));
        inpans{2} = num2str(outInfo(2));
        inpans{3} = num2str(outInfo(3));
        inpans{4} = num2str(outInfo(4));
    end
       
    % 
    vidObj = VideoWriter(outFile);
    vidObj.FrameRate = eval(inpans{1});
    imgW = eval(inpans{2});
    imgH = eval(inpans{3}); 
    vidObj.Quality   = eval(inpans{4});

    open(vidObj);
    hWait = waitbar(0, 'Generating video...');
    vidTic = tic; 
    for i = 1: nPic
        % read image
        img = imread([filesInfo(1).folder '\' filesInfo(i).name]);
        % add text
        imgTxt = insertText(img, [0 0], sprintf('%d %s %s', i, filesInfo(i).name, filesInfo(i).date), ...
            'FontSize',30,'BoxColor', 'red', 'BoxOpacity', 0.4, 'TextColor','black');
        % write to video
        writeVideo(vidObj, imresize(imgTxt, [imgH imgW], 'bicubic')); 
        % show progress
        if (mod(i, 10) == 0)
            vidToc = toc(vidTic);
            pctgVid = i / nPic;
            tToGo = vidToc / (pctgVid) - vidToc; 
            waitbar(pctgVid, hWait, sprintf('Generating video (%d/%d) (%.1f sec to go)', i, nPic, tToGo));  
        end
    end
    close(vidObj);
    close(hWait); 
end