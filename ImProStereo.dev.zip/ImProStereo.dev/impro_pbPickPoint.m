function handles = impro_pbPickPoint(hObject, handles)
% hObject    handle to pbPickPoint (see GCBO)
% handles    structure with handles and user data (see GUIDATA)

handles = impro_pickCtrlPoints(hObject, handles);

end