function impro_drawCross( theAxes, xy, theColor )
% Draw a cross at xy ([x y]) in theAxes

% Cross size
Dx = diff(xlim(theAxes)); 
Dy = diff(ylim(theAxes)); 
Cx = 0.03 * Dx;
Cy = 0.03 * Dy;

% Draw the cross
% For performance issue, we avoid usage of axes() without output. 
% (according to MATLAB suggestion).
% (--vince, 06/18/2012)
% axes(theAxes);
%hold on;
hold(theAxes, 'on');
plot(theAxes, [xy(1)-0.5*Cx xy(1)-0.1*Cx], [xy(2) xy(2)], theColor );
plot(theAxes, [xy(1)+0.5*Cx xy(1)+0.1*Cx], [xy(2) xy(2)], theColor );
plot(theAxes, [xy(1) xy(1)], [xy(2)-0.5*Cy xy(2)-0.1*Cy], theColor );
plot(theAxes, [xy(1) xy(1)], [xy(2)+0.5*Cy xy(2)+0.1*Cy], theColor );

end