function handles = impro_pickCtrlPoints(hObject, handles)

% Ask user to input range of point picking
if ( ~isfield(handles, 'TmpltSize') )
    handles.TmpltSize = 30;
end
inpans = inputdlg( {'Range of Pair'   ...
    'Range of iLR'    ...
    'Range of Point'  ...
    'Size of Template' }, ...
    'Range of manual matching', 1, ...
    { ['1:1'] ...
    ['1:1'] ...
    ['1:'  num2str(handles.nPoint)] ...
    [num2str(handles.TmpltSize)] } );
if ( size(inpans,1) < 1 )
    return
end

iPairRange  = str2num(inpans{1});
iLRRange    = str2num(inpans{2});
iPointRange = str2num(inpans{3});
handles.TmpltSize = str2num(inpans{4});

for iPair = iPairRange
    set(handles.slPair, 'Value', iPair);
    handles.iPair = iPair;
    handles = impro_updSlPair(hObject,handles);
    for iLR = iLRRange
        handles.iLR = iLR;
        if ( isfield(handles, 'nLR') && handles.nLR >=2 )
            set(handles.slLR, 'Value', iLR);
            handles = impro_updSlLR(hObject,handles);
            refresh;
        end
        for iPoint = iPointRange
            % for each pair, pick initial control point manually without template match
            % initialize ui components
            % manual picks
            % Set iPoint
            set(handles.slPoint, 'Value', iPoint);
            handles.iPoint = iPoint;
            handles = impro_updSlPoint(hObject, handles);
            refresh;
            % Get photo image
            [handles, iPhoto] = impro_loadPhoto(hObject, handles, ...
                handles.iPair, handles.iLR );
            % Get a picked point
            axes(handles.axPhotoLeft);
            options = []; 
            if ( isfield(handles, 'TmpltSize') )
                options.TmpltSize = handles.TmpltSize;
            end
            % added 'matchMethod' option (Apr 21, 2014 by vince) 
            if ( isfield(handles, 'matchMethod') ) 
                options.tm_method = handles.matchMethod;
            end
            [pckXy, outTmImgs, refXy, mod] = impro_ginputTm( 1, iPhoto, [], [], ...
                options);
            modC(iPoint) = mod;
            % save template to memory.
            handles = impro_saveTmplt(hObject, handles, handles.iPair, ...
                handles.iLR, ...
                iPoint, outTmImgs{1}, pckXy(1,:), refXy(1,:) );
            % show template
            handles = ...
                impro_loadTmplt(hObject, handles, iPair, iLR, iPoint);
            % end of iPoint loop
        end
        for i = iPointRange
            if     modC(i) ~= 0
                fprintf('CtrlPoint NO.%d selected mode %d\n',i, modC(i));
            elseif modC(i) == 0
                fprintf('CtrlPoint NO.%d did not select any mode\n',i);
            end
        end
        % end of iLR loop
    end
    % end of iPair loop
end
% Set iPoint to 1
set(handles.slPoint, 'Value', 1);
handles.iPoint = 1;
%slPoint_Callback(hObject, eventdata, handles);
impro_updSlPoint(hObject, handles);
refresh;

end