/*
 * =============================================================
   Matlab interface of findHomography function .
   
   function h = cvFindHomography( points1, points2 )
   
     Input:
       p1:     points set 1. Dimension: 2 x N
       p2:     points set 2. Dimension: 2 x N
     Output:
       h:     3x3 matrix, that conceptually 
              [p2/d; d d d ... ] = h * [p1; 1 1 1 ...]  
       
   Developed by Yuan-Sen Yang
   Date: 2018.08.03

 * =============================================================
 */
     
#include <mex.h>
#include "opencv2\opencv.hpp"   /* Includes all OpenCV2 header files */
#include <stdlib.h>
#include <stdio.h>


void mexFunction( int nlhs, mxArray *plhs[],int nrhs, const mxArray *prhs[])
{
	
  /* Check for proper number of arguments. */
  if (nrhs != 2) {
    mexErrMsgTxt("arguments: p1, p2");
  } 
  if (nlhs > 1) {
    mexErrMsgTxt("Too many output arguments");
  }
  
  /* Check dimension */
  const mwSize* dims_p1 = mxGetDimensions(prhs[0]);
  int p1_rows = (int) dims[0];
  int p1_cols = (int) dims[1];
  const mwSize* dims_p2 = mxGetDimensions(prhs[1]);
  int p2_rows = (int) dims[0];
  int p2_cols = (int) dims[1];
  if (p1_rows != 2 || p2_rows != 2) {
      mexErrMsgTxt("p1 and p2 must be 2-by-(number of points).");
  }
  if (p1_cols != p2_cols) {
      mexErrMsgTxt("p1 and p2 must have the same width (number of points).");
  }
  int n = p1_cols; 
  
  /* convert p1 and p2 to cvMat p1mat and p2mat (32-bit) */
  cv::Mat p1mat(1, n, CV_32FC2), p2mat(1, n, CV_32FC2); 
  // copy p1 to p1mat
  if (mxIsSingle(prhs[0])) {
      float * p1data = (float*) mxGetPr(prhs[0]); 
      for (int i = 0; i < n; i++) {
          p1mat.at<float>(0,i).x = p1data[i * 2 + 0]; 
          p1mat.at<float>(0,i).y = p1data[i * 2 + 1]; ;
      }
  } else if (mxIsDouble(prhs[0])) {
      double * p1data = (double*) mxGetPr(prhs[0]); 
      for (int i = 0; i < n; i++) {
          p1mat.at<float>(0,i).x = (float) p1data[i * 2 + 0]; 
          p1mat.at<float>(0,i).y = (float) p1data[i * 2 + 1]; ;
      }
  } else {
      mexErrMsgTxt("p1 must be in either single or double.");
  }
  // copy p2 to p2mat
  if (mxIsSingle(prhs[1])) {
      float * p2data = (float*) mxGetPr(prhs[1]); 
      for (int i = 0; i < n; i++) {
          p2mat.at<float>(0,i).x = p2data[i * 2 + 0]; 
          p2mat.at<float>(0,i).y = p2data[i * 2 + 1]; ;
      }
  } else if (mxIsDouble(prhs[1])) {
      double * p2data = (double*) mxGetPr(prhs[1]); 
      for (int i = 0; i < n; i++) {
          p2mat.at<float>(0,i).x = (float) p2data[i * 2 + 0]; 
          p2mat.at<float>(0,i).y = (float) p2data[i * 2 + 1]; ;
      }
  } else {
      mexErrMsgTxt("p2 must be in either single or double.");
  }
  // Run opencv findHomography (h will be 3x3 CV_64F) 
  cv::Mat h = cv::findHomography(p1mat, p2mat);
  
  // Copy opencv mat to matlab mat 
  int matdim[2] = {3, 3} ;
  plhs[0] = mxCreateNumericArray(2, matdim, mxDOUBLE_CLASS, mxREAL); 
  double* bufmat = (double*) mxGetPr(plhs[0]);
  for (int i = 0; i < 9; i++) 
      bufmat[i] = h.ptr<double>(i);
  
}
