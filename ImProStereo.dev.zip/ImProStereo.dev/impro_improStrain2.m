function varargout = impro_improStrain2(varargin)
% IMPRO_IMPROSTRAIN2 M-file for impro_improStrain2.fig
%      IMPRO_IMPROSTRAIN2, by itself, creates a new IMPRO_IMPROSTRAIN2 or raises the existing
%      singleton*.
%
%      H = IMPRO_IMPROSTRAIN2 returns the handle to a new IMPRO_IMPROSTRAIN2 or the handle to
%      the existing singleton*.
%
%      IMPRO_IMPROSTRAIN2('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in IMPRO_IMPROSTRAIN2.M with the given input arguments.
%
%      IMPRO_IMPROSTRAIN2('Property','Value',...) creates a new IMPRO_IMPROSTRAIN2 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before impro_improStrain2_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to impro_improStrain2_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help impro_improStrain2

% Last Modified by GUIDE v2.5 03-Mar-2011 14:10:25

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @impro_improStrain2_OpeningFcn, ...
                   'gui_OutputFcn',  @impro_improStrain2_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before impro_improStrain2 is made visible.
function impro_improStrain2_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to impro_improStrain2 (see VARARGIN)

% Choose default command line output for impro_improStrain2
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes impro_improStrain2 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = impro_improStrain2_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pbLoad3DCalib.
function pbLoad3DCalib_Callback(hObject, eventdata, handles)
% hObject    handle to pbLoad3DCalib (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

[calibFile calibPath] = uigetfile('*.mat');
if ( isnumeric(calibFile) && isnumeric(calibPath) ) 
  return     
end

calib3d = load([calibPath calibFile]);
handles.calib3d = calib3d; 

guidata(hObject, handles);

% --- Executes on button press in pbDebug.
function pbDebug_Callback(hObject, eventdata, handles)
% hObject    handle to pbDebug (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
keyboard;


% --- Executes on button press in pbGetCtrlPoints.
function pbGetCtrlPoints_Callback(hObject, eventdata, handles)
% hObject    handle to pbGetCtrlPoints (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

impro_uiginput3d; 

[handles.DataFile handles.DataPath] = uigetfile('*.mat');
if ( isnumeric(handles.DataPath) && isnumeric(handles.DataFile) ) 
  return     
end
loadedUiGinput3d = load([handles.DataPath handles.DataFile]);

% Copy variables from loaded handles to the current handles
handles.ListFile       = loadedHandles.handles.ListFile;
handles.ListPath       = loadedHandles.handles.ListPath;
handles.nPair          = loadedHandles.handles.nPair;
handles.nLR            = loadedHandles.handles.nLR; 
handles.nPoint         = loadedHandles.handles.nPoint;
handles.filelistPhoto  = loadedHandles.handles.filelistPhoto;
handles.filelistTmplt  = loadedHandles.handles.filelistTmplt;
handles.filelistMatch  = loadedHandles.handles.filelistMatch;
handles.filelistRectf  = loadedHandles.handles.filelistRectf;
handles.CtrlPoints     = loadedHandles.handles.CtrlPoints;
handles.DataFile       = loadedHandles.handles.DataFile;
handles.DataPath       = loadedHandles.handles.DataPath;
handles.iPair  = 1;
handles.iLR    = 1;
handles.iPoint = 1;
clear loadedHandles;
