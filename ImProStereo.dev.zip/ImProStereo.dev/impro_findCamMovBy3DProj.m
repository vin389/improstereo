function [CamMove, err] = impro_findCamMovBy3DProj(x0,xm,f,c,k,alpha)
% This function finds an optimal movement parameters CamMove
% (CamMove = [ rz ry rz ]) 
% Input parameters:
%      x0:  image coordinates of the fixed points in the initial photo.
%           array size: (N,2). N is the number of the fixed points. 
%      xm:  image coordinates of the fixed points in the moved photo.
%           array size: (N,2). N is the number of the fixed points. 
%      f:   focal length [fx fy] or [fx fy]'
%      c:   center point [cx cy] or [cx cy]'
%      k:   distortion [k1 k2 k3 k4 k5] or [k1 k2 k3 k4 k5]'
%      alpha: skew factor
%
% Output parameters:
%      CamMove(1): estimated camera rotation w.r.t original camera rx 
%      CamMove(2): estimated camera rotation w.r.t original camera ry
%      CamMove(3): estimated camera rotation w.r.t original camera rz
%      CamMove(4): estimated camera focal length zooming factor
%                    (0 means unchanged, 0.01 means zooming by a factor 
%                     of 1.01)
%      err: average reprojection error (in pixel)

% Data check
if (size(x0, 1) ~=2 && size(x0, 2) ~= 2) 
   disp('Warning: impro_findCamRotBy3DProj() got wrong dimension of x0');
   disp('    impro_findCamMoveBy3DProj() is skipped.');
   return;
end
if (size(x0, 1) ==2 && size(x0, 2) ~= 2) 
   disp('Warning: impro_findCamRotBy3DProj() got opposite dimension of x0');
   disp('    impro_findCamRotBy3DProj() transposed x0 internally.');
   x0 = x0'; 
end

N = size(x0, 1); 

% Get 3D coord. of the 2D points (on the Z=1 plane)
X0 = normalize_pixel(x0',f,c,k,alpha)'; 
X0(1:N, 3) = 1.0;

[om, fval, EXITFLAG, output] = fminsearch(@(om) ...
        error_CamMovBy3DProj(om, f, c, k, alpha, X0', xm'), ...
        0.001 * [1 1 1 .1]);

if (EXITFLAG == 0) 
    disp('Maximum number of function evaluations or iterations reached.');
end
if (EXITFLAG == 1)
   % fprintf('Estimated camera rotation is %f, %f, %f\n', -om(1), -om(2), -om(3));
end
if (EXITFLAG == -1)
    disp('Algorithm terminated by the output function.');
end
    
CamMove = -om; 
err = fval / sqrt(N); 

end


function err = error_CamMovBy3DProj(om, f, c, k, alpha, X0_transpose, xm_transpose)

xmp_transpose = project_points2(X0_transpose, ...
                                om(1:3), [0;0;0], ...
                                f * (1 + om(4)), ...
                                c,k,alpha); 
err = norm(xm_transpose - xmp_transpose);
%fprintf('cam chage = %f %f %f %f. Err is %f\n', om(1), om(2), om(3), ...
%    om(4), err);
end


