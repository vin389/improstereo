% function [result] = cvTemplateMatch( tarImage, cmpImage, range, mag )
%
% cvTemplateMatch - 
%                  Matlab interface of OpenCV cvMatchTemplate w/ 
%                  sub-pixel processing (by 2-level matching).
%   
%   SYNTAX:
%     [result] = cvTemplateMatch2( tarImage, cmpImage, range, mag );
%
%   INPUT:
%     tarImage   - target image   (size: height * width * 3 (depth)) 
%     cmpImage   - compared image (size: height * width * 3 (depth)) 
%     range      - range of [y1 y2 x1 x2] of cmpImage
%     mag        - image resize magnification. (e.g., mag=10 --> 
%                  ideal resolution=0.1) 
%
%   OUTPUT:
%     result(1)  - location X of matched image (result(1)=(2)=0 --> 
%                  at upper-left corner) 
%     result(2)  - location Y of matched image
%     result(3)  - accuracy (result(3)=1 --> exactly identical) 
%
%   DESCRIPTION:
%
%   EXAMPLE:
%
%   ---
%   VERSION: 2.2.0.1 (Feb. 14, 2011) 
%   MATLAB: R2009a
%   AUTHOR:  Yuan-Sen Yang
%   CONTACT: ysyang@ntut.edu.tw
%
%   REVISIONS:
%
%   DISCLAIMER:
%   Provided "as is" without warranty of any kind.


     