% This function is temporarily deprecated, and is replaced with
% impro_crackField2.m

function [crack_opening, crack_sliding, crack_angledg] = ...
    impro_crack_field_2(uxGrid, uyGrid)

M = size(uxGrid, 1); 
N = size(uxGrid, 2); 

crack_opening = zeros(M, N);
crack_sliding = zeros(M, N);
crack_angledg = zeros(M, N);

uxGrid11 = zeros(M+2,N+2,'single'); 
uxGrid11(M+2,N+2) = uxGrid(M,N);
uxGrid11(M+2,1  ) = uxGrid(M,1);
uxGrid11(1  ,N+2) = uxGrid(1,N);
uxGrid11(1  ,1  ) = uxGrid(1,1);
uxGrid11(1  ,2:N+1) = uxGrid(1, 1:N); 
uxGrid11(M+2,2:N+1) = uxGrid(M, 1:N); 
uxGrid11(2:M+1,  1) = uxGrid(1:M, 1); 
uxGrid11(2:M+1,N+2) = uxGrid(1:M, N); 
uxGrid11(2:M+1,2:N+1) = uxGrid(:,:); 
uyGrid11 = zeros(M+2,N+2,'single'); 
uyGrid11(M+2,N+2) = uyGrid(M,N);
uyGrid11(M+2,1  ) = uyGrid(M,1);
uyGrid11(1  ,N+2) = uyGrid(1,N);
uyGrid11(1  ,1  ) = uyGrid(1,1);
uyGrid11(1  ,2:N+1) = uyGrid(1, 1:N); 
uyGrid11(M+2,2:N+1) = uyGrid(M, 1:N); 
uyGrid11(2:M+1,  1) = uyGrid(1:M, 1); 
uyGrid11(2:M+1,N+2) = uyGrid(1:M, N); 
uyGrid11(2:M+1,2:N+1) = uyGrid; 

for i=2:M+1
   for j=2:N+1
    ux = [uxGrid11(i-1,j-1)  uxGrid11(i-1,j  )  uxGrid11(i-1,j+1); ...
          uxGrid11(i  ,j-1)  uxGrid11(i  ,j  )  uxGrid11(i  ,j+1); ...
          uxGrid11(i+1,j-1)  uxGrid11(i+1,j  )  uxGrid11(i+1,j+1) ]; 
    uy = [uyGrid11(i-1,j-1)  uyGrid11(i-1,j  )  uyGrid11(i-1,j+1); ...
          uyGrid11(i  ,j-1)  uyGrid11(i  ,j  )  uyGrid11(i  ,j+1); ...
          uyGrid11(i+1,j-1)  uyGrid11(i+1,j  )  uyGrid11(i+1,j+1) ]; 
    ux = ux - sum(ux(:))/9;
    uy = uy - sum(uy(:))/9;
    % solve equations
    snth = impro_crack33win_snth_inverse(ux33,uy33); 
    crack_opening(i - 1, j - 1) = snth(2);
    crack_sliding(i - 1, j - 1) = snth(1); 
    crack_angledg(i - 1, j - 1) = snth(3); 
   end
   fprintf('%d ', i);
end
fprintf('\n'); 

end