

% A00 gauge: (16:17, 4). 
% Range to take average to approach A00: (14:19, 2:6) 
y1 = 14; 
y2 = 19; 
x1 = 2;
x2 = 6; 

dat1 = [];
n1 = 0;
dat2 = [];
n2 = 0;

% remove nan values
for ix = x1: x2
  for iy = y1: y2
    if ( ~isnan(plotField(iy,ix)) )
      n1 = n1 + 1;
      dat1(n1) = plotField(iy,ix);
    end
  end
end
dat1avg = sum(dat1)/n1;
dat1std = std(dat1);
% remove extreme values
for i = 1: n1
  if ( dat1(i) < dat1avg + dat1std || dat1(i) > dat1avg - dat1std )
    n2 = n2 + 1;
    dat2(n2) = dat1(i);
  end
end
eyyA00 = sum(dat2)/n2;

% A01 gauge: (16:17, 22). 
% Range to take average to approach A00: (14:19, 20:24) 

y1 = 14; 
y2 = 19; 
x1 = 20;
x2 = 24; 

dat1 = [];
n1 = 0;
dat2 = [];
n2 = 0;

% remove nan values
for ix = x1: x2
  for iy = y1: y2
    if ( ~isnan(plotField(iy,ix)) )
      n1 = n1 + 1;
      dat1(n1) = plotField(iy,ix);
    end
  end
end
dat1avg = sum(dat1)/n1;
dat1std = std(dat1);
% remove extreme values
for i = 1: n1
  if ( dat1(i) < dat1avg + dat1std || dat1(i) > dat1avg - dat1std )
    n2 = n2 + 1;
    dat2(n2) = dat1(i);
  end
end
eyyA01 = sum(dat2)/n2;

% file output 
if ( iPair == 2 )
  fid = fopen('tmpDebugStepData.txt', 'w' );
else
  fid = fopen('tmpDebugStepData.txt', 'a' );
end
fprintf( fid, ' %f %f\n', eyyA00, eyyA01 ); 
fclose( fid );
