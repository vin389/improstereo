function impro_createUnmovedPhotoBy3DProj(FilenameSrc, FilenameDst, camMov, f, c, k, alpha)
% This function creates a new photo by mapping the source photo which 
% contains a camera movement to its un-moved photo (the new one).
%
% Input parameters:
%      FilenameSrc:  file name of the source photo (with movement)
%      FilenameDst:  file name of the new photo (without movement)
%                    If FilenameDst equals to FilenameSrc, the source photo
%                    will be replaced.
%      camMov:  movement parameters [rx ry rz fc_factor]
%
% Output parameters:
%      There is no output parameters.
%
% Developer: Yuan-Sen Yang
% Date: 2016-05-07
% 

% Get source photo data
PhotoSrc = imread( FilenameSrc );
% if read image is one-channel, convert it to 3-channel (vince 2014-08-07)
if (size(PhotoSrc,3) == 1) 
    PhotoSrc = uint8(cat(3,PhotoSrc,PhotoSrc,PhotoSrc));
end

PhotoHgt = size(PhotoSrc, 1); % photo height
PhotoWdt = size(PhotoSrc, 2); % photo width
PhotoDpt = size(PhotoSrc, 3); % photo depth
if ( PhotoDpt ~= 3) 
    fprintf('Error: impro_createUnmovedPhotoBy3DProj supports 3-ch photo only.\n');
    return;
end

% Calculate mapping arrays
mapx = zeros(PhotoHgt, PhotoWdt, 'single');
mapy = zeros(PhotoHgt, PhotoWdt, 'single');

%   Create grid points on the normal plane
x_norm_um = ones(3, PhotoWdt); 
x_img_um = zeros(2, PhotoWdt); 
x_img_um(1,1:PhotoWdt) = 1:PhotoWdt; 
for irow = 1: PhotoHgt
    x_img_um(2,1:PhotoWdt) = irow; 
    x_norm_um_2 = normalize_pixel(x_img_um,f,c,k,alpha); 
    x_norm_um(1:2, 1:PhotoWdt) = x_norm_um_2(1:2, 1:PhotoWdt);     
    x_img_mv = project_points2(x_norm_um, camMov(1:3), [0;0;0], ...
                               f * (1 + camMov(4)), ...
                               c, k, alpha); 
    mapx(irow, 1:PhotoWdt) = x_img_mv(1, 1:PhotoWdt);  
    mapy(irow, 1:PhotoWdt) = x_img_mv(2, 1:PhotoWdt); 
end

% Create mapped photo
PhotoDst = cvRemap( PhotoSrc, mapx, mapy );

% Write the file.
imwrite( PhotoDst, FilenameDst, 'Quality', 98 );

end
