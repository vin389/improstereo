function [R T] = impro_FindCoordSys(X, xp, f, c, k, alpha, R, T )
% This function finds the transformation matrices R and T between the 
% user coordinate system and the camera coordinate system. 
%
% Input:
%   X:      The positions of feature points in the user coordinate.
%           size: 3*N matrix for N points
%   xp:     The positions of feature points in image
%           size: 2*N matrix for N points
%   f:      camera focal length in units of horizontal and vertical pixel units (2x1 vector)
%   c:      principal point location in pixel units (2x1 vector)
%   k:      Distortion coefficients (radial and tangential) (4x1 vector)
%   alpha:  Skew coefficient between x and y pixel (alpha = 0 <=> square pixels)
%   R:      Initial guess of the R matrix
%   T:      Initial guess of the T matrix
%
% Output: 
%   
%   (R,T):  Rigid motion parameters between world coordinate frame and camera reference frame
%           R: rotation vector (3x1 vector); T: translation vector (3x1 vector)
%      
% Developer: 
%   Yuan-Sen Yang
% 
% Date: 
%   2012-04-02
% 

% Arguments check.

if ( nargin < 8 )
    R = [0 0 0];
    if ( nargin < 7 )
        T = [0 0 0];
        if ( nargin < 6 )
            alpha = 0;
            if ( nargin < 5) 
                fprintf('Error: Insufficient input arguments ');
                fprintf('for impro_FindCoordSys.\n');
                return;
            end
        end
    end
end

RT = zeros(1,6);
RT(1:3) = R;
RT(4:6) = T;

options.Display = 'iter';
options.MaxFunEvals = 1e6;
options.MaxIter     = 1e6;
options.TolFun      = size(X,2) * 1.0e-9;
options.TolX        = 1e-9;
RT = fminsearch(@(rt) FindCoordSysErrCheck( X,xp,f,c,k,alpha,rt), RT, ...
                options); 

R = RT(1:3)';
T = RT(4:6)';

end

function err = FindCoordSysErrCheck( X, xp, f, c, k, alpha, RT ) 
    
    R = RT(1:3)';
    T = RT(4:6)';

    [xpTrial,dxpdom,dxpdT,dxpdf,dxpdc,dxpdk,dxpdalpha] = ...
        project_points2(X, R, T, f, c, k, alpha); 
      
    err = norm(xp-xpTrial);   
    fprintf('%f %f %f %f %f %f Err: %f\n', RT(1), RT(2), RT(3), RT(4), RT(5), RT(6), err );
end




















