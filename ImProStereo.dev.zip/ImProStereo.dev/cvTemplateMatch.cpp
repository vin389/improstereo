/*
 * =============================================================
   Matlab interface of modified cvTemplateMatch function.
   
   function [result] = cvTemplateMatch( tarImage, cmpImage, range, mag )
   
     Input:
       tarImage: target image   (size: height x width x 3 (depth)) 
       cmpImage: compared image (size: height x width x 3 (depth)) 
       range:    range of [y1 y2 x1 x2] of cmpImage
       mag:      image resize magnification. (e.g., mag=10 --> ideal resolution=0.1) 
     Output:
       result(1): location Y of matched image (result(1)=(2)=0 --> at upper-left corner) 
       result(2): location X of matched image
       result(3): accuracy (result(3)=1 --> exactly identical) 
	   
   Developer of this interface: 
       Yuan-Sen Yang	   
   Last revision date:
       Feb. 11, 2011
 * =============================================================
 */
     
 

#include <mex.h>
#include "opencv2\opencv.hpp"   /* Includes all OpenCV2 header files */
//#include "inc\cv.h"
//#include "inc\cxcore.h"
//#include "inc\highgui.h"

/* input two images (in 1-D array format) and 
   get the best position the target image in the comparing image. */

void cvTemplateMatch_Mex(uchar * tarImg, uchar * cmpImg, 
                          int sizeTarImgY, int sizeTarImgX, int sizeCmpImgY, int sizeCmpImgX, 
                          int rangeY1, int rangeY2, int rangeX1, int rangeX2, int imag, 
                          double * _bestX, double * _bestY, double * _bestErr )
{
	int depth = 8, nChannels=3;
    int i,j,i2,j2;
    int sizeRangeX, sizeRangeY;
    
    //
    sizeRangeX= rangeX2-rangeX1+1;
    sizeRangeY= rangeY2-rangeY1+1; 
	
	//
	CvSize size_tarImg = cvSize(sizeTarImgX, sizeTarImgY);
	IplImage* image_tarImg = cvCreateImage(size_tarImg, depth, 3);
	for(j = 0; j < sizeTarImgY; j++)
	{
		for(i = 0; i < sizeTarImgX; i++)
		{
			(image_tarImg->imageData + image_tarImg->widthStep * j) [i*3+0] = tarImg[j + i * sizeTarImgY + sizeTarImgX * sizeTarImgY * 2];
			(image_tarImg->imageData + image_tarImg->widthStep * j) [i*3+1] = tarImg[j + i * sizeTarImgY + sizeTarImgX * sizeTarImgY * 1];
			(image_tarImg->imageData + image_tarImg->widthStep * j) [i*3+2] = tarImg[j + i * sizeTarImgY + sizeTarImgX * sizeTarImgY * 0];
		}
	}

	//
	CvSize size_cmpImg = cvSize(sizeRangeX, sizeRangeY);
	IplImage* image_cmpImg = cvCreateImage(size_cmpImg, depth, 3);
	for(j = 0; j < sizeRangeY; j++)
	{
		j2=j+rangeY1;
		for(i = 0; i < sizeRangeX; i++)
		{
			i2=i+rangeX1;
			(image_cmpImg->imageData + image_cmpImg->widthStep * j) [i*3+0] = cmpImg[j2 + i2 * sizeCmpImgY + sizeCmpImgX * sizeCmpImgY * 2];
			(image_cmpImg->imageData + image_cmpImg->widthStep * j) [i*3+1] = cmpImg[j2 + i2 * sizeCmpImgY + sizeCmpImgX * sizeCmpImgY * 1];
			(image_cmpImg->imageData + image_cmpImg->widthStep * j) [i*3+2] = cmpImg[j2 + i2 * sizeCmpImgY + sizeCmpImgX * sizeCmpImgY * 0];
		}
	}

	//
	IplImage* sourceImage = cvCreateImage(cvSize(sizeRangeX, sizeRangeY), depth, 1);
	cvCvtColor(image_cmpImg, sourceImage, CV_BGR2GRAY);
	IplImage* templateImage = cvCreateImage(cvSize(sizeTarImgX, sizeTarImgY), depth, 1);
	cvCvtColor(image_tarImg, templateImage, CV_BGR2GRAY);
	CvSize size = cvSize(sizeRangeX - sizeTarImgX + 1, sizeRangeY - sizeTarImgY + 1);
	IplImage* resultImage = cvCreateImage(size, IPL_DEPTH_32F, 1);

	cvMatchTemplate(sourceImage, templateImage, resultImage, CV_TM_CCOEFF_NORMED);

	double minVal, maxVal;
	CvPoint minLoc, maxLoc;
	cvMinMaxLoc(resultImage, &minVal, &maxVal, &minLoc, &maxLoc, 0);

	*_bestX=   maxLoc.x + rangeX1; 
	*_bestY=   maxLoc.y + rangeY1; 
	*_bestErr= maxVal;

    /* size of images to resize */
    int border=5; 
    int sizeResTarImgX= sizeTarImgX* imag; 
    int sizeResTarImgY= sizeTarImgY* imag;
    CvSize sizeResTarImg = cvSize(sizeResTarImgX, sizeResTarImgY);
    /* check the new cmpImage range */
    int rangeResizeCmpX1= *_bestX-border;
    if (rangeResizeCmpX1<0) rangeResizeCmpX1=0;
    int rangeResizeCmpX2= *_bestX + sizeTarImgX -1 + border ;
    if (rangeResizeCmpX2> sizeCmpImgX-1) rangeResizeCmpX2= sizeCmpImgX-1;
    int rangeResizeCmpY1= *_bestY-border;
    if (rangeResizeCmpY1<0) rangeResizeCmpY1=0;
    int rangeResizeCmpY2= *_bestY + sizeTarImgY -1 + border ;
    if (rangeResizeCmpY2> sizeCmpImgY-1) rangeResizeCmpY2= sizeCmpImgY-1;
    int sizeResCmpImgX= (rangeResizeCmpX2-rangeResizeCmpX1+1)*imag;
    int sizeResCmpImgY= (rangeResizeCmpY2-rangeResizeCmpY1+1)*imag;   
    CvSize sizeResCmpImg = cvSize(sizeResCmpImgX, sizeResCmpImgY);
    CvRect roiCmpImage;
    roiCmpImage.x=rangeResizeCmpX1-rangeX1;
    roiCmpImage.y=rangeResizeCmpY1-rangeY1;
    
    /* allocate space for images */
  
    IplImage* imgResTarImg = cvCreateImage(sizeResTarImg, depth, nChannels); 
    IplImage* imgResCmpImg = cvCreateImage(sizeResCmpImg, depth, nChannels); 
  
    /* copy a part of cmpImage (roi) to cmpImageRoi (region of interest) */

    IplImage *cmpImageRoi = cvCreateImage( cvSize(rangeResizeCmpX2-rangeResizeCmpX1+1, rangeResizeCmpY2-rangeResizeCmpY1+1),	
                                           image_cmpImg->depth, image_cmpImg->nChannels);
	for(j = 0; j < cmpImageRoi->height; j++)
	{
		j2=j+rangeResizeCmpY1;
		for(i = 0; i < cmpImageRoi->width; i++)
		{
			i2=i+rangeResizeCmpX1;
			(cmpImageRoi->imageData + cmpImageRoi->widthStep * j) [i*3+0] = cmpImg[j2 + i2 * sizeCmpImgY + sizeCmpImgX * sizeCmpImgY * 2];
			(cmpImageRoi->imageData + cmpImageRoi->widthStep * j) [i*3+1] = cmpImg[j2 + i2 * sizeCmpImgY + sizeCmpImgX * sizeCmpImgY * 1];
			(cmpImageRoi->imageData + cmpImageRoi->widthStep * j) [i*3+2] = cmpImg[j2 + i2 * sizeCmpImgY + sizeCmpImgX * sizeCmpImgY * 0];
		}
	}    
    
    /* resize */
    cvResize(image_tarImg, imgResTarImg, CV_INTER_CUBIC );  
    cvResize(cmpImageRoi,  imgResCmpImg, CV_INTER_CUBIC );  

    /* refined template matching */
    
    cvReleaseImage(&sourceImage);
    cvReleaseImage(&templateImage);
    cvReleaseImage(&resultImage);
	sourceImage   = cvCreateImage(cvSize(imgResCmpImg->width, imgResCmpImg->height), depth, 1);
	cvCvtColor(imgResCmpImg, sourceImage, CV_BGR2GRAY);
   	templateImage = cvCreateImage(cvSize(imgResTarImg->width, imgResTarImg->height), depth, 1);
	cvCvtColor(imgResTarImg, templateImage, CV_BGR2GRAY);
	CvSize resize = cvSize(imgResCmpImg->width  - imgResTarImg->width  + 1, 
	                     imgResCmpImg->height - imgResTarImg->height + 1);
	
	resultImage = cvCreateImage(resize, IPL_DEPTH_32F, 1);

	cvMatchTemplate(sourceImage, templateImage, resultImage, CV_TM_CCOEFF_NORMED);

	minVal, maxVal;
	cvMinMaxLoc(resultImage, &minVal, &maxVal, &minLoc, &maxLoc, 0);

	*_bestX=   rangeResizeCmpX1 + (double)maxLoc.x / imag; 
	*_bestY=   rangeResizeCmpY1 + (double)maxLoc.y / imag; 
	*_bestErr= maxVal;
    	  
    /* release space for images */
    cvReleaseImage(&cmpImageRoi);
    cvReleaseImage(&imgResTarImg);
    cvReleaseImage(&imgResCmpImg);
	cvReleaseImage(&sourceImage);
	cvReleaseImage(&templateImage);
	cvReleaseImage(&image_cmpImg);
	cvReleaseImage(&image_tarImg);
	cvReleaseImage(&resultImage);
	   
}

/*  
  input arguments:
    double array tarImg,
    double array cmpImg,
  output arguments:
    double array (bestX, bestY, bestErr)
*/ 
  
void mexFunction(int nlhs, mxArray *plhs[], int nrhs,
                 const mxArray *prhs[])
{
  uchar * tarImg, * cmpImg;
  int      sizeTarImgY, sizeTarImgX, sizeCmpImgY, sizeCmpImgX;
  int      rangeY1, rangeY2, rangeX1, rangeX2; 
  double * drange;
  int      imag;
  double bestY, bestX;
  double bestErr;
  
  double *result;
  
  /* Check for proper number of arguments. */
  if (nrhs != 4) {
    mexErrMsgTxt("arguments: tarImage cmpImage range mag");
  } else if (nlhs > 1) {
    mexErrMsgTxt("Too many output arguments");
  }
 
  /* The get arguments .*/
  if (!mxIsUint8(prhs[0]) || mxIsComplex(prhs[0]) ) {
      mexErrMsgTxt("Input of image 1 must be noncomplex scalar uint8.");
  }
  tarImg= (uchar*)mxGetPr(prhs[0]);
  /* get image size. assume the image depth =3 */
  sizeTarImgY= (int) mxGetM(prhs[0]);
  sizeTarImgX= (int) mxGetN(prhs[0])/3;
    
  if (!mxIsUint8(prhs[1]) || mxIsComplex(prhs[1]) ) {
      mexErrMsgTxt("Input of image 2 must be uint8.");
  }
  cmpImg= (uchar*)mxGetPr(prhs[1]);
  /* get image size. assume the image depth =3 */
  sizeCmpImgY= (int) mxGetM(prhs[1]);
  sizeCmpImgX= (int) mxGetN(prhs[1])/3;

  if (!mxIsDouble(prhs[2]) ) {
      mexErrMsgTxt("Input of range must be a double array.");
  }
  drange= (double*) mxGetPr(prhs[2]);
  rangeY1=(int) drange[0]-1; /* transfer to 0-based index */
  rangeY2=(int) drange[1]-1;
  rangeX1=(int) drange[2]-1;
  rangeX2=(int) drange[3]-1;
    /* range check */
  if (rangeY1<0) rangeY1=0;
  if (rangeY1>sizeCmpImgY-sizeTarImgY) rangeY1=sizeCmpImgY-sizeTarImgY;
  if (rangeY2>=sizeCmpImgY) rangeY2=sizeCmpImgY-1; 
  if (rangeY2-rangeY1<sizeTarImgY-1) rangeY2=rangeY1+sizeTarImgY-1;
  if (rangeX1<0) rangeX1=0;
  if (rangeX1>sizeCmpImgX-sizeTarImgX) rangeX1=sizeCmpImgX-sizeTarImgX;
  if (rangeX2>=sizeCmpImgX) rangeX2=sizeCmpImgX-1; 
  if (rangeX2-rangeX1<sizeTarImgX-1) rangeX2=rangeX1+sizeTarImgX-1;
	  
  if (!mxIsDouble(prhs[3]) ) {
      mexErrMsgTxt("Input of mag must be a double.");
  }
  imag= (int)*(mxGetPr(prhs[3])) ;
  
  /* Create matrix for the return argument. */
  plhs[0] = mxCreateDoubleMatrix(1,3, mxREAL);
  
  result = mxGetPr(plhs[0]);
 
  /* Call the timestwo subroutine. */

  cvTemplateMatch_Mex(tarImg, cmpImg, 
                       sizeTarImgY, sizeTarImgX, sizeCmpImgY, sizeCmpImgX,
                       rangeY1, rangeY2, rangeX1, rangeX2, imag, 
                       &bestX, &bestY, &bestErr);
  result[0]= bestY; 
  result[1]= bestX; 
  result[2]= sqrt(bestErr); 

  
}
