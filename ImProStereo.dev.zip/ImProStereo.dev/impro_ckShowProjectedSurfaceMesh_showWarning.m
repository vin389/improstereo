function impro_ckShowProjectedSurfaceMesh_showWarning(hObject, handles)

showPatch = get(handles.ck_ShowProjectedSurfaceMesh, 'Value');
if (showPatch == 1) 
    h = warndlg('Showing projected mesh slows down ImProStereo and could cause MATLAB instability. Save your data before running.'); 
end

end
