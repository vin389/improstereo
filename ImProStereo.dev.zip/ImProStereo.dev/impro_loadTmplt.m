function [handles,iTmpltImg] = ...
         impro_loadTmplt(hObject, handles, iPair, iLR, iPoint)
% This function loads and shows template image and data to file
% Loaded template data is at handles.iTmplt{iLR}. 
% Loaded image is iTmpltImg 

% Template image
succRead = 0;
if ( exist([handles.TmpltPath{iLR} handles.filelistTmplt{iPair,iLR}], 'file') )
  % load Tmplt file image and show it
  iTmplt = load([handles.TmpltPath{iLR} handles.filelistTmplt{iPair,iLR}]);
  % handles.iTmplt = iTmplt.iTmplt;
  handles.iTmplt{iLR} = iTmplt.iTmplt; % Modified by vince. 2013/04/23
  if ( size(handles.iTmplt{iLR}.file,2) >= iPoint && ...   
       exist([handles.TmpltPath{iLR} handles.iTmplt{iLR}.file{iPoint}],'file') == 2) % Modified by vince 2017/7/5
    iTmpltImg = imread([handles.TmpltPath{iLR} handles.iTmplt{iLR}.file{iPoint}]);
    succRead = 1;
    % display the current
    % For performance issue, we avoid usage of axes() without output. 
    % (according to MATLAB suggestion).
    % (--vince, 06/18/2012)
    %axes(handles.axTmplt{iLR});
    cla(handles.axTmplt{iLR}); % If we do not clear axes first, the image
                               % object is added and the original image 
                               % is not cleared. Memory usage expands.
    xlim(handles.axTmplt{iLR}, [1 size(iTmpltImg,2)]);
    ylim(handles.axTmplt{iLR}, [1 size(iTmpltImg,1)]);
    %image(iTmpltImg);
    image(iTmpltImg, 'Parent', handles.axTmplt{iLR} );
    % draw a cross at the reference point
    impro_drawCross( handles.axTmplt{iLR}, ...
         handles.iTmplt{iLR}.refXy{iPoint}, 'blue' );
    % disable label
    axes(handles.axTmpltLeft);
    set(gca,'XTickLabel',[]); 
    set(gca,'YTickLabel',[]); 
    axes(handles.axTmpltRigt);
    set(gca,'XTickLabel',[]); 
    set(gca,'YTickLabel',[]);     
    % print a text message on console 
    fprintf('Template Pair:%d/LR:%d/Pnt:%d loaded.\n', iPair,iLR,iPoint);
  end
end
if ( succRead == 0 )
  cla(handles.axTmplt{iLR});
  fprintf('Template Pair:%d/LR:%d/Pnt:%d is not loaded.\n',iPair,iLR,iPoint);
  iTmpltImg = [];
  handles.iTmplt = [];
end

end




