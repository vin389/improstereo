function handles = impro_3dMesh( hObject, handles )
% This function generates 3D mesh of the current (iPair) measurement 
% region and plots the surface on the photos (left and right). 

% Control points triangulation
handles = impro_CtrlPointsTriangulation( hObject, handles );

% Find axes of the cylinder system
iCtrlPoint3D(:,:) = handles.CtrlPoints3D(handles.iPair,1,:,:);
% Find the cylinder sys.
[vx,vy,vz,ori,R,th1,th2,h1,h2] = impro_cylinderSys( iCtrlPoint3D );
% Find mesh of the cylinder face (theta=th1~th2) (height=h1~h2)
m=10; n=10;
[vtx faces] = impro_cylinFace(vx,vy,vz,ori,R,th1,th2,h1,h2, m, n);
% Convert to image coord.
%  Left
[xp] = project_points2( ...
  vtx', [0 0 0], [0;0;0], handles.calib3d.fc_left, ...
  handles.calib3d.cc_left, handles.calib3d.kc_left, ...
  handles.calib3d.alpha_c_left );
axes(handles.axPhotoLeft);
xp = [xp' zeros(size(xp,2),1)];
patch('Vertices',xp,'Faces',faces, ...
  'FaceColor','blue','FaceAlpha',0.5, ...
  'EdgeColor','white', 'EdgeAlpha', 0.5 );
%  Right
[xp] = project_points2( ...
  vtx', handles.calib3d.om, handles.calib3d.T, ...
  handles.calib3d.fc_right, ...
  handles.calib3d.cc_right, handles.calib3d.kc_right, ...
  handles.calib3d.alpha_c_right );
axes(handles.axPhotoRigt);
xp = [xp' zeros(size(xp,2),1)];
patch('Vertices',xp,'Faces',faces, ...
  'FaceColor','blue','FaceAlpha',0.5, ...
  'EdgeColor','white', 'EdgeAlpha', 0.5 );
  
end
