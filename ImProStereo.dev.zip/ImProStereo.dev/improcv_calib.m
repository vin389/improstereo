function [cameraMatrix, distCoeffs, reprojErr] = improcv_calib()

cameraMatrix = [];
distCoeffs = [];
reprojErr = [];

%% Get file lists
[filename, pathname, filterindex] = uigetfile( ...
       {'*.jpg','JPG-files (*.jpg)'; ...
        '*.bmp','BMP-files (*.bmp)'; ...
        '*.png','PNG-files (*.png)'; ...
        '*.*',  'All Files (*.*)'}, ...
        'Pick files (must be the same image size)', ...
        'MultiSelect', 'on');

if (iscell(filename) == 0) 
    return;
end
nfile = size(filename, 2); 

%% Get chessboard corners --> corners{i_img}{i_point}(1:2) 
patternSize = input('Input pattern size (default [ 9 14 ]): ');
if (size(patternSize, 1) == 0) 
    patternSize = [9 14];
end
cellSize = input('Input size of each cell (default [ 100 100 ]): ');
if (size(cellSize, 1) == 0) 
    cellSize = [100 100];
end
imageSize = [-1 -1];
clear corners;
for i_img = 1: nfile
    % read image 
    imgfile = [pathname filename{i_img}]; 
    fprintf('Reading image %d: %s ...', i_img, filename{i_img}); 
    img = imread(imgfile); 
    img = cv.cvtColor(img, 'BGR2GRAY');
    imageSize = [size(img, 2) size(img, 1)]; 
    fprintf('OK\n');
    % find corners
    fprintf('  Finding corners of image %d ...', i_img);
    [corners{i_img},ok] = cv.findChessboardCorners(img, patternSize);
    if (ok) 
        fprintf('OK\n');
        fprintf('Finding subpix corners of image %d ...', i_img);
        corners{i_img} = cv.cornerSubPix(img, corners{i_img}, ....
            'Criteria',...
             struct('type','Count+EPS', 'maxCount',30, 'epsilon',0.1));
        fprintf('OK\n');
    else
        fprintf('Failed to find corners.\n');
    end
    imshow(cv.drawChessboardCorners(img, patternSize, corners{i_img})); 
end

%% Get chessboard corners --> corners{i_img}{i_point}(1:2) 
clear objectPoints;
for i_img = 1: nfile
    i_corner = 0;
        for corners_ix = 0: patternSize(2) - 1
    for corners_iy = 0: patternSize(1) - 1
            i_corner = i_corner + 1; 
            objectPoints{i_img}{i_corner} = [ cellSize(1) * corners_ix, ...
                cellSize(2) * corners_iy, 0 ]; 
        end
    end    
end

%% Calibrate camera
[cameraMatrix, distCoeffs, reprojErr] = cv.calibrateCamera(objectPoints, corners, imageSize);

%% Save to file
[filename, pathname] = uiputfile('calibration.mat', 'Save Calibration Result as');
save([pathname filename], 'cameraMatrix', 'distCoeffs', 'reprojErr', ...
     'objectPoints', 'corners', 'imageSize', '-v7'); 
  