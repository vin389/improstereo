function [vx,vy,vz,ori,x1,x2,y1,y2] = impro_planeSys( CtrlPoint3D )
%
% Calculate the best (reasonable) plane system by a few control points.
%   INPUT:
%     CtrlPoint3D - Control points 
%                   Dimension (1:nPoint,1:3)
%
%              P3 -> P3'(0,y2) 
%                    |
%                    |
%                    |
%                    |
%                   P1(0,0)-----------------P2(x2,0)
%              (At present, x1 will be 0, y1 will be 0) 
%                   P1 to P3 are required. 
% 
%   Output: 
%     vx/vy/vz - The basic normalized axes of the coordinate system.
%                Dimension (1:3,1)
%     ori      - The origin of the coordinate system.
%                Dimension (1:3,1)
%     x1/x2    - The x range of the measurement region.
%                x1 will be 0 at present. 
%                Dimension (1,1)
%     y1/y2    - The y range of the measurement region
%                h1 is typically 0.
%                Dimension (1,1)
%

vxp  = CtrlPoint3D(2,:)' - CtrlPoint3D(1,:)';
vyp  = CtrlPoint3D(3,:)' - CtrlPoint3D(1,:)';
vzp  = cross(vxp,vyp); 

vx   = vxp/norm(vxp);
vz   = vzp/norm(vzp);
vy   = cross(vz,vx); 

x1   = 0;
x2   = norm(vxp); 
y1   = 0; 
y2   = dot(vyp, vy); 

ori  = CtrlPoint3D(1,:)'; 

end

