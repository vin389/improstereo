/*
 * =============================================================
   Matlab interface of image remap function .
   
   function imgR = cvRemap( imgOri, mapx, mapy )
   
     Input:
       imgOri:   original image  (size: height x width x 3 (depth)) 
       mapx:     The map of x-coordinates (32fC1 image).
       mapy:     The map of y-coordinates (32fC1 image). 
     Output:
       imgR:     destination image.
                 imgR(x,y)<-imgOri(mapx(x,y),mapy(x,y))
       
   Developed by Yuan-Sen Yang
   Date: 2008.10.01
   Modified: 2012.04.14 to match opcv231 64-bit

 * =============================================================
 */
     
#include <mex.h>
#include "opencv2\opencv.hpp"   /* Includes all OpenCV2 header files */
//#include "inc\cv.h"
//#include "inc\cxcore.h"
#include <stdlib.h>
#include <stdio.h>


void mexFunction( int nlhs, mxArray *plhs[],int nrhs, const mxArray *prhs[])
{
	
  /* Check for proper number of arguments. */
  if (nrhs != 3) {
    mexErrMsgTxt("arguments: imgOri, mapx, mapy");
  } 
  if (nlhs > 1) {
    mexErrMsgTxt("Too many output arguments");
  }
  
  /* get original image buffer pointer */
  
  uchar* imgOriMat    = (uchar*)mxGetPr(prhs[0]); 
  int    imgWidth     = (int) mxGetN(prhs[0])/3;
  int    imgHeight    = (int) mxGetM(prhs[0]);
  int    imgNChannels = 3;  /* must be 3. Or this function would collapse */ 
  int    imgDepth     = 8;  /* must be 8. Or this function would collapse */ 

  /* get mapx & mapy pointer. Assume mapx & mapy are arrays of float (single precision) */

  float  *mapx         = (float*) mxGetPr(prhs[1]);
  int     s1mapx       = (int)    mxGetN(prhs[1]);
  int     s2mapx       = (int)    mxGetM(prhs[1]);
  float  *mapy         = (float*) mxGetPr(prhs[2]);
  int     s1mapy       = (int)    mxGetN(prhs[2]);
  int     s2mapy       = (int)    mxGetM(prhs[2]);
  int     imgDesWidth  = (int)    s1mapx;
  int     imgDesHeight = (int)    s2mapx;
  
    /* check if the dimension of mapx and mapy are consistent */
  if ( s1mapx != s1mapy || s2mapx != s2mapy ) 
  {
    printf("cvRemap error: sizes of mapx & mapy are not consistent.\n");
    fflush(stdout);
  }

  /* create an openCV image space for source image
     and copy  matlab image (imgOriMat) to openCV image (imgOriOcv). 
     The openCV image (imgOriOcv) will be released before returning */
  
  CvSize    imgOriSize = cvSize(imgWidth, imgHeight);
  IplImage* imgOriOcv  = cvCreateImage(imgOriSize, imgDepth, imgNChannels);
  
    /* copy image from matlab format to OpenCV format */ 
  int i,j; 
  for(j = 0; j < imgHeight; j++) {
    for(i = 0; i < imgWidth; i++) {
      (imgOriOcv->imageData + imgOriOcv->widthStep * j) [i*3+0] = imgOriMat[j + i * imgHeight + imgWidth * imgHeight * 2];
      (imgOriOcv->imageData + imgOriOcv->widthStep * j) [i*3+1] = imgOriMat[j + i * imgHeight + imgWidth * imgHeight * 1];
      (imgOriOcv->imageData + imgOriOcv->widthStep * j) [i*3+2] = imgOriMat[j + i * imgHeight + imgWidth * imgHeight * 0];
  } }
  
  /* create an openCV image space for destination image.
     The created opencv image (imgDesOcv) will be deleted before returning. */

  IplImage* imgDesOcv  = cvCreateImage(cvSize(imgDesWidth, imgDesHeight), imgDepth, imgNChannels);
  IplImage* imgMapx    = cvCreateImage(cvSize(imgDesWidth, imgDesHeight), IPL_DEPTH_32F , 1);
  IplImage* imgMapy    = cvCreateImage(cvSize(imgDesWidth, imgDesHeight), IPL_DEPTH_32F , 1);

  for(j = 0; j < imgDesHeight; j++) {
    for(i = 0; i < imgDesWidth; i++) {
      ((float*)(imgMapx->imageData + imgMapx->widthStep * j )) [i*imgMapx->nChannels+0] = mapx[j + i * imgDesHeight] - 1.0;
      ((float*)(imgMapy->imageData + imgMapy->widthStep * j )) [i*imgMapy->nChannels+0] = mapy[j + i * imgDesHeight] - 1.0;
  } }
  
  /* call opencv remap function */
  /* function interface:  void cvRemap( const CvArr* src, CvArr* dst,
                               const CvArr* mapx, const CvArr* mapy,
                               int flags=CV_INTER_LINEAR+CV_WARP_FILL_OUTLIERS,
                               CvScalar fillval=cvScalarAll(0) ); 
  */
              
  cvRemap( (const CvArr*) imgOriOcv, 
                 (CvArr*) imgDesOcv,
           (const CvArr*) imgMapx, 
           (const CvArr*) imgMapy,
           CV_INTER_CUBIC+CV_WARP_FILL_OUTLIERS,
           cvScalarAll(0) ); 

  cvReleaseImage(&imgMapx);
  cvReleaseImage(&imgMapy);

  /* create a matlab image (mxArray) and
     copy the generated openCV image to matlab image */
    /* mxREAL means there is no complex part */
  mwSize bufdim[3] = { imgDesHeight, imgDesWidth, imgNChannels} ;
  plhs[0] = mxCreateNumericArray(3, bufdim, mxUINT8_CLASS, mxREAL);  
  
    /* copy the image from OpenCV format to matlab format */ 
  uchar* bufDesImg = (uchar*) mxGetPr(plhs[0]);

  for(j = 0; j < imgDesHeight; j++) {
    for(i = 0; i < imgDesWidth; i++) {
      bufDesImg[j + i * imgDesHeight + imgDesWidth * imgDesHeight * 2] = (imgDesOcv->imageData + imgDesOcv->widthStep * j) [i*3+0]; 
      bufDesImg[j + i * imgDesHeight + imgDesWidth * imgDesHeight * 1] = (imgDesOcv->imageData + imgDesOcv->widthStep * j) [i*3+1]; 
      bufDesImg[j + i * imgDesHeight + imgDesWidth * imgDesHeight * 0] = (imgDesOcv->imageData + imgDesOcv->widthStep * j) [i*3+2]; 
  } }
    
  /* release opencv images */
  cvReleaseImage(&imgOriOcv);
  cvReleaseImage(&imgDesOcv);
  
}
