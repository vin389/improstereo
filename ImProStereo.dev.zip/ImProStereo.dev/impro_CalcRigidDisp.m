function handles = impro_CalcRigidDisp( hObject, handles )
% This function calculates the rigid body displacement of a coordinate
% system wrt to another coord. system (normally the fixed coord. sys.) 
%
% 
% Advanced option dialog
dialog_prompt = { '1. Coord.Sys. ID with movement', ... 
                  '2. Fixed coord. sys. ID (0 if cam is well fixed)', ...
                  '3. Reference pair (0:import ref. matrix. Other:pair number.' }; 
dialog_title  = 'Calculate rigid-body disp. of a coord. sys.';
dialog_default= { '2', '1', '1' };
dialog_answer = inputdlg( dialog_prompt, dialog_title, 1, dialog_default );

if ( size(dialog_answer,1) == 0 )
  return;
end

if ( isfield(handles, 'CoordSys') == 0 ) 
  fprintf('No coord. is defined.\n');
  return; 
end


% Coord. sys IDs
coordID_mov = str2num(dialog_answer{1}); 
coordID_fix = str2num(dialog_answer{2}); 
refPair     = str2num(dialog_answer{3}); 

if ( coordID_mov < 0 || coordID_mov > size(handles.CoordSys, 2) )
  fprintf('Invalid input of movement coord. ID.\n');
  return;
end

if ( coordID_fix < 0 || coordID_fix > size(handles.CoordSys, 2) )
  fprintf('Invalid input of fixed coord. ID.\n');
  return;
end

% Improt reference matrix from a MAT file if refPair == 0
if ( refPair == 0 )
  [refFile, refPath, filterindex] = uigetfile( ...
          {'*.mat','MAT-files (*.mat)'}, ...
           'Pick the reference matrix file', ...
           'MultiSelect', 'off');  
  load([ refPath refFile ]); % Load refPair.
else 
  % Define the coord. sys. matrices (unitary matrix if it is cam coord.)
  if ( coordID_mov > 0 )
    CoordMat_Mov = handles.CoordSys{refPair, coordID_mov};
  else % coordID_mov == 0 
    CoordMat_Mov = [1 0 0 0;0 1 0 0;0 0 1 0;0 0 0 1];
  end
  if ( coordID_fix > 0 )
    CoordMat_Fix = handles.CoordSys{refPair, coordID_fix};
  else % coordID_mov == 0 
    CoordMat_Fix = [1 0 0 0;0 1 0 0;0 0 1 0;0 0 0 1];
  end
  refMat = inv( CoordMat_Mov ) * CoordMat_Fix ; 
  % Save the reference matrix to a MAT file.
  [refFile, refPath] = uiputfile('*.mat', ...
    'Save the reference matrix as ... CANCEL if you do not want to save');
  if ( ischar(refFile) )
    save( [refPath refFile], 'refMat' ); 
  end
end

% Calculate the rigid body disp. (6-dof) 

for iPair = 1: handles.nPair
  % Assume m denotes coordID_mov
  % Assume f denotes coordID_fix
  % TransMatrix( (m-ref) <- (m-iPair) ) = refMat * 
  %   inv( CoordSys{iPair, f} ) * CoordSys{iPair, m}  

  % Define the coord. sys. matrices (unitary matrix if it is cam coord.)
  if ( coordID_mov > 0 )
    CoordMat_Mov = handles.CoordSys{iPair, coordID_mov};
  else % coordID_mov == 0 
    CoordMat_Mov = [1 0 0 0;0 1 0 0;0 0 1 0;0 0 0 1];
  end
  if ( coordID_fix > 0 )
    CoordMat_Fix = handles.CoordSys{iPair, coordID_fix};
  else % coordID_mov == 0 
    CoordMat_Fix = [1 0 0 0;0 1 0 0;0 0 1 0;0 0 0 1];
  end
  
  TransMat = refMat * inv( CoordMat_Fix ) * CoordMat_Mov ; 
  RigidDisp(iPair, 1) = TransMat(1, 4);
  RigidDisp(iPair, 2) = TransMat(2, 4);
  RigidDisp(iPair, 3) = TransMat(3, 4);
  theta = rodrigues( TransMat(1:3,1:3) );
  RigidDisp(iPair, 4) = theta(1);
  RigidDisp(iPair, 5) = theta(2);
  RigidDisp(iPair, 6) = theta(3);
end

% Plot it 
figure('Name', 'Rigid-body displacements' );
xt = 1: handles.nPair; 
plot(xt, RigidDisp(:,1), ...
     xt, RigidDisp(:,2), ...
     xt, RigidDisp(:,3), 'LineWidth', 2 );
legend('Ux(+East)', 'Uy(+North)', 'Uz');
xlabel('Photo (every 20 sec.)'); 
ylabel('Displacements (mm)');
grid on; 

figure('Name', 'Rigid-body rotations' );
xt = 1: handles.nPair; 
plot(xt, RigidDisp(:,4)*180/pi, ...
     xt, RigidDisp(:,5)*180/pi, ...
     xt, RigidDisp(:,6)*180/pi, 'LineWidth', 2 );
legend('Rx(East)', 'Ry(North)', 'Rz');
xlabel('Photo (every 20 sec.)'); 
ylabel('Rotations (degree)');
grid on; 

% Save it to a file (ask user)
[datFile, datPath] = uiputfile('*.txt', ...
  'Save the displacement data as ... CANCEL if you do not want to save');
if ( ischar(datFile) )

  fid = fopen( [datPath datFile], 'w' );
  fprintf( fid, 'iPair\tUx\tUy\tUz\tRx\tRy\tRz\n');
  for iPair = 1: handles.nPair
    fprintf(fid, '%d\t', iPair );
    for idof = 1: 3
      fprintf( fid, '%10.2f\t', RigidDisp(iPair, idof) );
    end
    for idof = 4: 6
      fprintf( fid, '%10.2f\t', RigidDisp(iPair, idof)*180/pi );
    end
    fprintf( fid, '\n');
  end
  fclose(fid);
  
end % end if user saves data to a file. 

end % end of function














