% function [GridPoints] = rectf_cylinder( CtrlPoints, Rpx, Expan, ImgSize )
%
% Input:
%   CtrlPoints:    3D coordinates of control points. In rectf_cylinder, 
%                  four points are needed. The CtrlPoints array needs to be
%                  3*4. If it is 4*3, it will be transposed internally. 
%                  
%                   P1                     P3
%                    |\                   /
%                    | \------- P2 ------/
%                    |
%                    |
%                   P4 (the same height with Origin)  
%                     \                   /
%                      \-----------------/
%                      (Origin is at the central axis of cylinder)
%
%   Rpx:           Length per pixel. It is a scalar (1*1).
%   Expan:         Expansion of the rectified image (in pixel). 
%     Expan(1):    The expansion along X.
%     Expan(2):    The expansion along Y.
%                  The most left-lower pixel of rectified image is at 
%                  ( -Expan(1)*Rpx, -Expan(2)*Rpx ) of the rectification
%                  coord. system. 
%                  For example, if Expan is [ 200 100 ], and Rpx is 0.1 mm,
%                  the left-lower pixel is at (-20 mm, -10 mm). 
%   ImgSize:       The expected size of rectified image.
%                  ImgSize(1): Width.   
%                  ImgSize(2): Height.
%                  The range of rectified image is:
%                  X: (-Expan(1)*Rpx) --> (-Expan(1)+ImgSize(1)-1)*Rpx 
%                  Y: (-Expan(2)*Rpx) --> (-Expan(2)+ImgSize(2)-1)*Rpx 
%       
% Output:
%   GridPoints:    Coordinates of the grid of points. To save memory, this
%                  function uses single precision (single) for GridPoints.
%                  Size: 3*ImgSize(1)*ImgSize(2). I.e., 
%                        (1:3, 1:ImgSize(1), 1:ImgSize(2) ) 
% 
% Memory issue: It should be noted that the GridPoints may be a big array. 
%               If ImgSize is [3000 2000], the GridPoints would be 
%               4000*3000*3*4 bytes ==> about 140 MB. 
%     
% Developed by Yuan-Sen Yang
% Date: 2011.06.20
%
% =============================================================
 
function [GridPoints] = rectf_cylinder( CtrlPoints, Rpx, Expan, ImgSize )

% Calculate cylinder system
if ( size(CtrlPoints,1) == 3 && size(CtrlPoints,2) == 4 )
  CtrlPointsParm = CtrlPoints'; 
  [vx,vy,vz,ori,R,th1,th2,h1,h2] = impro_cylinderSys( CtrlPointsParm ); 
elseif ( size(CtrlPoints,1) == 4 && size(CtrlPoints,2) == 3 )
  [vx,vy,vz,ori,R,th1,th2,h1,h2] = impro_cylinderSys( CtrlPoints );
else
  uiwait(msgbox('rectf_cylinder needs a 3x4 or 4x3 CtrlPoints. Function incompleted.', 'Err', 'error' ));
  GridPoints = [];
  return;
end

% Re-define th1 (starting theta), h1 (starting z), dth (increment of theta)
% and dh (increment of z) according to Expan, ImgSize, and Rpx

th1 = -Expan(1) * Rpx / R; 
dth = Rpx / R; 

h1  = -Expan(2) * Rpx; 
dh  = Rpx; 

% Generate GridPoints

GridPoints = zeros([3 ImgSize(1) ImgSize(2)], 'single');

for ih = ImgSize(2):-1:1
  h = (-Expan(2) + ih - 1) * Rpx;
  for ith = 1: ImgSize(1)
    th = (-Expan(1) + ith - 1) * Rpx / R;
    % Fill out the 3D coordinates
    GridPoints(:,ith,ih) = ori + R * cos(th) * vx + R * sin(th) * vy ...
                           + h * vz; 
  end
end

end
