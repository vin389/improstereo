function DT2 = impro_sync_two_curves(ut1, ut2, t1_begin, t1_end, target, dt_lb, dt_ub)

%try_dt = linspace(dt_lb, dt_ub, 100); 
%for i = 1: 100
%    cor_dt(i) = impro_sync_two_curves_cost( try_dt(i) , ut1, ut2, t1_begin, t1_end, target); 
%end
%figure; plot(try_dt, cor_dt); grid on; 

DT2 = fminbnd(@(x) impro_sync_two_curves_cost( x, ut1, ut2, t1_begin, t1_end, target), dt_lb, dt_ub ); 
      %fminbnd(@(x) impro_sync_two_curves_cost(x, u1x, u2x, 500, 2500, 1), -100, 100 )
n1 = size(ut1(:), 1);
n2 = size(ut2(:), 1); 
tn1 = 1: n1;
tn2 = 1: n2;
%figure; subplot(2,1,1); plot(tn1, ut1(:) - sum(ut1(:)) / n1, ...
%                             tn2, ut2(:) - sum(ut2(:)) / n2); grid on; 
%                         legend('U1', 'U2');
%        subplot(2,1,2); plot(tn1, ut1(:) - sum(ut1(:)) / n1, ...
%                             tn2 - DT2, ut2(:) - sum(ut2(:)) / n2); grid on;              
%                         legend('U1', 'Phased U2');
end

                        
    