function handles = ...
         impro_loadData(hObject, handles)
% This function loads gui variable "handles" from a user selected file.
% This function is designed for ImPro Strain 2.0 only.

[handles.DataFile handles.DataPath] = uigetfile('*.mat');
if ( isnumeric(handles.DataPath) && isnumeric(handles.DataFile) ) 
  return     
end
loadedHandles = load([handles.DataPath handles.DataFile]);

% Copy variables from loaded handles to the current handles
handles.ListFile       = loadedHandles.handles.ListFile;
handles.ListPath       = loadedHandles.handles.ListPath;
handles.nPair          = loadedHandles.handles.nPair;
handles.nLR            = loadedHandles.handles.nLR; 
handles.nPoint         = loadedHandles.handles.nPoint;
handles.filelistPhoto  = loadedHandles.handles.filelistPhoto;
handles.filelistTmplt  = loadedHandles.handles.filelistTmplt;
handles.filelistMatch  = loadedHandles.handles.filelistMatch;
handles.filelistRectf  = loadedHandles.handles.filelistRectf;
handles.CtrlPoints     = loadedHandles.handles.CtrlPoints;
handles.DataFile       = loadedHandles.handles.DataFile;
handles.DataPath       = loadedHandles.handles.DataPath;
handles.iPair  = 1;
handles.iLR    = 1;
handles.iPoint = 1;
clear loadedHandles;

% Enable ui components if related information is available in handles

% Setup ui objects and display information
if ( isfield(handles, 'nPair') && handles.nPair >= 1 ) 
  nPair = handles.nPair; 
  set(handles.slPair, 'Min', 1);
  set(handles.slPair, 'Max', nPair);
  set(handles.slPair, 'Value', handles.iPair);
  set(handles.slPair, 'SliderStep', [1./(nPair-1) 1./(nPair-1)] );
  set(handles.txPair, 'String', sprintf('Photo pair %05d', 1) );
  set(handles.slPair, 'Enable', 'on');
end
  
txLR={'Left','Right'};
if ( isfield(handles, 'nLR') && handles.nLR >=2 )
  nLR = handles.nLR; 
  set(handles.slLR,   'Min', 1);
  set(handles.slLR,   'Max', nLR);
  set(handles.slLR,   'Value', handles.iLR);
  set(handles.slLR,   'SliderStep', [1./(nLR-1) 1./(nLR-1)] );
  set(handles.txLR,   'String', txLR{1} );
  set(handles.slLR,   'Enable', 'on');
else
  set(handles.slLR,'Enable','off');
end

if ( isfield(handles, 'nPoint') && handles.nPoint >=1 );
  nPoint = handles.nPoint;
  set(handles.slPoint,   'Min', 1);
  set(handles.slPoint,   'Max', nPoint);
  set(handles.slPoint,   'Value', handles.iPoint);
  set(handles.slPoint,   'SliderStep', [1./(nPoint-1) 1./(nPoint-1)] );
  set(handles.slPoint,   'Enable', 'on');
end

% Call slider call-back function
handles = impro_updSlPair(hObject, handles);
if ( isfield(handles, 'nLR') && handles.nLR >=2 )
    handles = impro_updSlLR(hObject, handles);
end
handles = impro_updSlPoint(hObject, handles);

end