function DX = impro_findCamMove2(X0, XN)
% This function finds an optimal movement parameters (dx, dy, th, sc) 
% according to a set of fixed points. 
% Input parameters:
%      X0:  image coordinates of the fixed points in the initial photo.
%           array size: (N,2). N is the number of the fixed points. 
%      XN:  image coordinates of the fixed points in the moved photo.
%           array size: (N,2). N is the number of the fixed points. 
%
% Output parameters:
%      DX(1):  pixel movement along x direction (image coordinate)
%      DX(2):  pixel movement along y direction (image coordinate)(downward) 
%      DX(3):  angular rotation about image origin (0,0) (clockwise) 
%      DX(4):  scale of size
% 
%      which is the optimal set to the equations:
% 
%      XN(1,1) = sc *(cos(th)*X0(1,1) - sin(th)*X0(1,2) + dx)
%      XN(1,2) = sc *(sin(th)*X0(1,1) + cos(th)*X0(1,2) + dy)
%
%      XN(2,1) = sc *(cos(th)*X0(2,1) - sin(th)*X0(2,2) + dx)
%      XN(2,2) = sc *(sin(th)*X0(2,1) + cos(th)*X0(2,2) + dy)
%
%      XN(3,1) = sc *(cos(th)*X0(3,1) - sin(th)*X0(3,2) + dx)
%      XN(3,2) = sc *(sin(th)*X0(3,1) + cos(th)*X0(3,2) + dy)
%
%      XN(4,1) = sc *(cos(th)*X0(4,1) - sin(th)*X0(4,2) + dx)
%      XN(4,2) = sc *(sin(th)*X0(4,1) + cos(th)*X0(4,2) + dy)
%
%      ......
%
N = size(X0,1); 
% If there is only one point, rotation and scale are not adjusted.
if ( N == 1 ) 
    [dx dy] = impro_findCamMove0( X0, XN );
    DX = [dx;dy;0;1];
    return;
end

[dx dy th] = impro_findCamMove1(X0, XN);

errMin = 1e100;
optMin = [0 0 0 0];

for i = 1: 200
        
    sc = 1;
    DX = [dx;dy;th;sc] .* [ ( 1 + (rand(1,1)-0.5)/1 ); ...
                            ( 1 + (rand(1,1)-0.5)/1 ); ...
                            ( 1 + (rand(1,1)-0.5)/100 ); ...
                            ( 1 + (rand(1,1)-0.5)/100 )];     

    % optimization options
    opt.Display = 'off'; 
    opt.FunValCheck = 'off';
    opt.TolFun = 1e-5; 
    opt.TolX = 1e-5; 

    [optimal_x, err] = ...
        fminsearch(@(x) impro_findCamMove2_Errfunc(X0,XN,x), DX, opt ); 
    
    if (err < errMin) 
        errMin = err;
        fprintf('Err2:%6.2f, Dx:%7.2f, Dy:%7.2f, Th:%8.4f, Sc:%6.3f\n', ...
            err, optimal_x(1), optimal_x(2), optimal_x(3), optimal_x(4) );
        optMin = optimal_x; 
    end

end    
    
DX(1) = optMin(1);
DX(2) = optMin(2);
DX(3) = optMin(3);
DX(4) = optMin(4);
fprintf('impro_findCamMove2 optimization completed.\n');
end 

function err = impro_findCamMove2_Errfunc(X0,XN,DX)
N = size(X0,1); 
% check 
%if ( N ~= size(XN,1) ) 
%   fprintf('impro_findCamMove_Errfunc Err: X0,XN must be same size.\n'); 
%   err = 0+1i; 
%   return; 
%end
dx = DX(1);
dy = DX(2);
th = DX(3);
sc = DX(4);
% calculate the error
err = 0;
C = cos(th); S = sin(th);
for i=1:N
  err = err ...
      + norm( [XN(i,1) - sc *(C*X0(i,1) - S*X0(i,2) + dx); ... 
               XN(i,2) - sc *(S*X0(i,1) + C*X0(i,2) + dy)],2 );
end 
% fprintf('Trial: %f %f %f. Error: %f\n', dx, dy, th, err);
end  

function [dx dy th] = impro_findCamMove1(X0, XN)
% This function finds an optimal movement parameters (dx, dy, th) 
% according to a set of fixed points. 
% Input parameters:
%      X0:  image coordinates of the fixed points in the initial photo.
%           array size: (N,2). N is the number of the fixed points. 
%      XN:  image coordinates of the fixed points in the moved photo.
%           array size: (N,2). N is the number of the fixed points. 
%
% Output parameters:
%      dx:  pixel movement along x direction (image coordinate)
%      dy:  pixel movement along y direction (image coordinate)(downward) 
%      th:  angular rotation about image origin (0,0) (clockwise) 
% 
%      which is the optimal set to the equations:
% 
%      XN(1,1) = cos(th)*X0(1,1) - sin(th)*X0(1,2) + dx
%      XN(1,2) = sin(th)*X0(1,1) + cos(th)*X0(1,2) + dy
%
%      XN(2,1) = cos(th)*X0(2,1) - sin(th)*X0(2,2) + dx
%      XN(2,2) = sin(th)*X0(2,1) + cos(th)*X0(2,2) + dy
%
%      XN(3,1) = cos(th)*X0(3,1) - sin(th)*X0(3,2) + dx
%      XN(3,2) = sin(th)*X0(3,1) + cos(th)*X0(3,2) + dy
%
%      XN(4,1) = cos(th)*X0(4,1) - sin(th)*X0(4,2) + dx
%      XN(4,2) = sin(th)*X0(4,1) + cos(th)*X0(4,2) + dy
%
%      ......
%

[dx0 dy0] = impro_findCamMove0(X0, XN);
errMin = 1e100;
% optimization options
opt.Display = 'off'; 
opt.FunValCheck = 'off';
opt.TolFun = 1e-3; 
opt.TolX = 1e-3; 

for i = 1: 50
    th0 = rand(1,1);
    DX = [dx0;dy0;th0];
    [optimal_x,err] = ... 
        fminsearch(@(x) impro_findCamMove1_Errfunc(X0,XN,x), DX, opt ); 
    if ( err < errMin )
        errMin = err; 
        dx = optimal_x(1);
        dy = optimal_x(2);
        th = optimal_x(3);
        fprintf('Err1:%6.2f, Dx:%7.2f, Dy:%7.2f, Th:%8.4f\n', ...
            err, optimal_x(1), optimal_x(2), optimal_x(3));
    end
end 
end

function err = impro_findCamMove1_Errfunc(X0,XN,DX)
dx = DX(1); 
dy = DX(2);
th = DX(3);
N = size(X0,1); 
% check 
if ( N ~= size(XN,1) ) 
   fprintf('impro_findCamMove_Errfunc Err: X0,XN must be same size.\n'); 
   err = 0+1i; 
   return; 
end
% calculate the error
err = 0;
for i=1:N
  err = err ...
      + norm( [XN(i,1) - (cos(th)*X0(i,1) - sin(th)*X0(i,2) + dx); ... 
               XN(i,2) - (sin(th)*X0(i,1) + cos(th)*X0(i,2) + dy)],2 );
end 
 %fprintf('Trial: %f %f %f. Error: %f\n', dx, dy, th, err);
end  


function [dx dy] = impro_findCamMove0(X0, XN)
% This function finds an optimal movement parameters (dx, dy) 
% according to a set of fixed points. 
% Input parameters:
%      X0:  image coordinates of the fixed points in the initial photo.
%           array size: (N,2). N is the number of the fixed points. 
%      XN:  image coordinates of the fixed points in the moved photo.
%           array size: (N,2). N is the number of the fixed points. 
%
% Output parameters:
%      dx:  pixel movement along x direction (image coordinate)
%      dy:  pixel movement along y direction (image coordinate)(downward) 
% 
%      which is the optimal set to the equations:
% 
%      XN(1,1) = X0(1,1) + dx
%      XN(1,2) = X0(1,2) + dy
%
%      XN(2,1) = X0(2,1) + dx
%      XN(2,2) = X0(2,2) + dy
%
%      XN(3,1) = X0(3,1) + dx
%      XN(3,2) = X0(3,2) + dy
%
%      XN(4,1) = X0(4,1) + dx
%      XN(4,2) = X0(4,2) + dy
%
%      ......
%
errMin = 1e100;
% optimization options
opt.Display = 'off'; 
opt.FunValCheck = 'off';
opt.TolFun = 1e-3; 
opt.TolX = 1e-3; 

for i = 1: 5
    DX = rand(2,1);
    [optimal_x, err] = ... 
        fminsearch(@(x) impro_findCamMove0_Errfunc(X0,XN,x), DX, opt );     
    if ( err < errMin) 
        errMin = err;
        dx = optimal_x(1);
        dy = optimal_x(2);
        fprintf('Err0:%6.2f, Dx:%7.2f, Dy:%7.2f\n', ...
            err, optimal_x(1), optimal_x(2) );
    end
end
end 

function err = impro_findCamMove0_Errfunc(X0,XN,DX)
dx = DX(1); 
dy = DX(2);
N = size(X0,1); 
% check 
%if ( N ~= size(XN,1) ) 
%   fprintf('impro_findCamMove0_Errfunc Err: X0,XN must be same size.\n'); 
%   err = 0+1i; 
%   return; 
%end
% calculate the error
err = 0;
for i=1:N
  err = err ...
      + norm( [XN(i,1) - (X0(i,1) + dx); ... 
               XN(i,2) - (X0(i,2) + dy)],2 );
end 
 %fprintf('Trial: %f %f %f. Error: %f\n', dx, dy, th, err);
end  



















