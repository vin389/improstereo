function handles = impro_InterpQ4( hObject, handles )
% This function generates many points over a quadratic area defined by user

% Check
if size(handles.CtrlPoints, 2) < 2
    msgbox('Define points in right camera');
    return;
end

% User inputs

prompt = {'Four corners of Q4 region (Left-low, Right-low, Left-up, Right-up)'   ...
    'Number of points along left-right'    ...
    'Number of points along low-up' ...
    'Starting index'}; 
name = 'Points Generation by Interpolation - Q4';
numlines = 1;
defaultanswer = { ['1 2 3 4'] ['10'] ['20'] [num2str(size(handles.CtrlPoints, 3) + 1)]};
options.Resize='on';
options.WindowStyle='normal';
options.Interpreter='tex';
inpans = inputdlg(prompt,name,numlines,defaultanswer,options);
if isempty(inpans) 
    return;
end

q4Points = str2num(inpans{1}); 
nPx = str2num(inpans{2});
nPy = str2num(inpans{3});
pointStart = str2num(inpans{4});

%% Append points (push-back) to handles.CtrlPoints from CtrlPoints(1,1:2,iPoint,iXy)
p1 = [0 0; 1 0; 0 1; 1 1]';
% Left 
p2L = [handles.CtrlPoints(1, 1, q4Points(1), 1)  handles.CtrlPoints(1, 1, q4Points(1), 2); ...
       handles.CtrlPoints(1, 1, q4Points(2), 1)  handles.CtrlPoints(1, 1, q4Points(2), 2); ...
       handles.CtrlPoints(1, 1, q4Points(3), 1)  handles.CtrlPoints(1, 1, q4Points(3), 2); ...
       handles.CtrlPoints(1, 1, q4Points(4), 1)  handles.CtrlPoints(1, 1, q4Points(4), 2) ]';
%    Find homography matrix of left Q4 
hL = findHomography(p1, p2L); 
%    Generate new points over left Q4 (Note: We want to generate points
%    along X first, but "meshgrid" goes Y first. So we intenionally invert
%    meshy and meshx.)
[meshy, meshx] = meshgrid(linspace(0,1,nPy), linspace(0,1,nPx)); 
p1_many = [meshx(:) meshy(:) ones(nPx*nPy,1)]';
p2L_many = hL * p1_many; 
%    Append left Q4 to CtrlPoints
pointEnd = pointStart + nPx * nPy - 1; 
handles.CtrlPoints(1, 1, pointStart:pointEnd, 1) = p2L_many(1,:) ./ p2L_many(3,:); 
handles.CtrlPoints(1, 1, pointStart:pointEnd, 2) = p2L_many(2,:) ./ p2L_many(3,:); 
% Right  
p2R = [handles.CtrlPoints(1, 2, q4Points(1), 1)  handles.CtrlPoints(1, 2, q4Points(1), 2); ...
       handles.CtrlPoints(1, 2, q4Points(2), 1)  handles.CtrlPoints(1, 2, q4Points(2), 2); ...
       handles.CtrlPoints(1, 2, q4Points(3), 1)  handles.CtrlPoints(1, 2, q4Points(3), 2); ...
       handles.CtrlPoints(1, 2, q4Points(4), 1)  handles.CtrlPoints(1, 2, q4Points(4), 2) ]';
%    Find homography matrix of right Q4 
hR = findHomography(p1, p2R); 
%    Generate new points over right Q4 
%[meshx, meshy] = meshgrid(linspace(0,1,nPx), linspace(0,1,nPy)); 
%p1_many = [meshx(:) meshy(:) ones(nPx*nPy,1)]';
p2R_many = hR * p1_many; 
%    Append right Q4 to CtrlPoints
%pointStart = handles.nPoint + 1;
%pointEnd = pointStart + nPx * nPy - 1; 
handles.CtrlPoints(1, 2, pointStart:pointEnd, 1) = p2R_many(1,:) ./ p2R_many(3,:); 
handles.CtrlPoints(1, 2, pointStart:pointEnd, 2) = p2R_many(2,:) ./ p2R_many(3,:); 

handles.nPoint = size(handles.CtrlPoints, 3); 

% Debug
% xx(:) = handles.CtrlPoints(1,1,pointStart:pointEnd,1); yy(:) = handles.CtrlPoints(1,1,pointStart:pointEnd,2); figure; plot(xx,yy,'o'); grid on; set(gca,'Ydir','reverse'); axis equal; 
% xx(:) = handles.CtrlPoints(1,2,pointStart:pointEnd,1); yy(:) = handles.CtrlPoints(1,2,pointStart:pointEnd,2); figure; plot(xx,yy,'o'); grid on; set(gca,'Ydir','reverse'); axis equal; 

%% Simulating points picking (for template data) 
iPair = 1; 
iLR = 1; 
% simulating picking on the first left image 
[handles, iPhoto] = impro_loadPhoto(hObject, handles, iPair, iLR );
% for each generated point
for iPoint = pointStart:pointEnd
    xiL = handles.CtrlPoints(1, 1, iPoint, 1);
    yiL = handles.CtrlPoints(1, 1, iPoint, 2); 
    options.autogXy = [ xiL yiL ]; 
    options.range = [0 0 0 0]; 
    if ( isfield(handles, 'TmpltSize') )
        options.TmpltSize = handles.TmpltSize;
    end
    % get the template image, picked point (assigned), and reference xy
    [pckXy, outTmImgs, refXy] = impro_ginputTm( 1, iPhoto, [], [], ...
                options);
    % save template data to file (left)
    handles = impro_saveTmplt(hObject, handles, iPair, ...
                iLR, ...
                iPoint, outTmImgs{1}, pckXy(1,:), refXy(1,:) );
    % save template data to file (right), while the template image is left
    % template image 
    xiR = handles.CtrlPoints(1, 2, iPoint, 1);
    yiR = handles.CtrlPoints(1, 2, iPoint, 2); 
    handles = impro_saveTmplt(hObject, handles, iPair, ...
                2, ...
                iPoint, outTmImgs{1}, [xiR yiR], refXy(1,:) );
end







