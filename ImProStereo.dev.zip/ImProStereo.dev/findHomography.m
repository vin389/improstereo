%   function h = cvFindHomography( points1, points2 )
%   
%     Input:
%       p1:     points set 1. Dimension: 2 x N
%       p2:     points set 2. Dimension: 2 x N
%     Output:
%       h:     3x3 matrix, that conceptually 
%              [p2/d; d d d ... ] = h * [p1; 1 1 1 ...]  
%       
%   Developed by Yuan-Sen Yang
%   Date: 2018.08.03

function h = findHomography(p1, p2)
h = eye(3); 
% Check dimension
[p1rows, p1cols] = size(p1); 
[p2rows, p2cols] = size(p2); 
if (p1rows ~= 2 || p2rows ~= 2 || p1cols ~= p2cols) 
    msgbox('Error: findHomography: p1 and p2 must be 2xN');
    return;
end
% 
n = size(p1, 2);
x1 = p1(1, :); y1 = p1(2, :);
x2 = p2(1, :); y2 = p2(2, :); 
rx = [p1; ones(1,n)];
h1 = [-rx; zeros(3, n); x2.*x1; x2.*y1; x2];
h2 = [zeros(3, n); -rx; y2.*x1; y2.*y1; y2];
[U,S,V] = svd([h1 h2]);
h = (reshape(U(:,9), 3, 3)).'; 
end
