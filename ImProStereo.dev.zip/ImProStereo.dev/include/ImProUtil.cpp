#include "ImProUtil.h"
#include <vector>
#include <opencv2/core.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/calib3d.hpp>
#include <iostream>

#if defined(WIN32) || defined(_WIN32) || defined(__WIN32) && !defined(__CYGWIN__)
#include <Windows.h> // for OPENFILENAME, GetOpenFileName
#endif 

using namespace std;
using namespace cv; 

vector<double> linspace(double a, double b, int n) {
	vector<double> array;
	if ((n == 0) || (n == 1) || (a == b))
		array.push_back(b);
	else if (n > 1) {
		double step = (b - a) / (n - 1);
		int count = 0;
		while (count < n) {
			array.push_back(a + count*step);
			++count;
		}
	}
	return array;
}

vector<float> linspace(float a, float b, int n) {
	vector<float> array;
	if ((n == 0) || (n == 1) || (a == b))
		array.push_back(b);
	else if (n > 1) {
		float step = (b - a) / (n - 1);
		int count = 0;
		while (count < n) {
			array.push_back(a + count*step);
			++count;
		}
	}
	return array;
}

void griddata(float xa, float xb, int nx, float ya, float yb, int ny, cv::Mat & X, cv::Mat & Y)
{
	if (nx <= 0 || ny <= 0) {
		cerr << "Warning: griddata() got nx <= 0 or ny <= 0. Check it.\n";
		return;
	}
	X.create(ny, nx, CV_32F);
	Y.create(ny, nx, CV_32F);
	float dx = nx > 1 ? (xb - xa) / (nx - 1) : 0.0f;
	float dy = ny > 1 ? (yb - ya) / (ny - 1) : 0.0f;
	for (int i = 0; i < ny; i++) {
		for (int j = 0; j < nx; j++)
		{
			X.at<float>(i, j) = xa + j * dx;
			Y.at<float>(i, j) = ya + i * dy;
		}
	}
}

bool findChessboardCornersSubpix(cv::Mat image, Size patternSize, vector<Point2f> & corners,
	int flags, TermCriteria criteria)
{
	// variables
	bool bres;
	bres = cv::findChessboardCorners(image, patternSize, corners, flags); 
	if (bres == false)
		return false;
	// subpix
	cv::cornerSubPix(image, corners, cv::Size(5, 5), cv::Size(0, 0), criteria);

	// check ordering. Convert to left-to-right ordering. If not, reverse points.
	if (corners[0].x > corners[corners.size() - 1].x)
		std::reverse(corners.begin(), corners.end());
	return bres; 
}

std::vector<cv::Point3f> Create3DChessboardCorners(cv::Size bsize, float squareSize_w, float squareSize_h)
{
	std::vector<cv::Point3f> corners;
	for (int i = 0; i < bsize.height; i++)
		for (int j = 0; j < bsize.width; j++)
			corners.push_back(cv::Point3f(float(j*squareSize_w),
				float(i*squareSize_h), 0));
	return corners;
}

double calibrateCameraFromChessboardImages(
	const std::vector<cv::Mat> & imgs,
	cv::Size imageSize,
	cv::Size bsize,
	float squareSize_w, float squareSize_h,
	cv::Mat & cmat,
	cv::Mat & dmat,
	std::vector<cv::Mat> & rmats,
	std::vector<cv::Mat> & tmats,
	cv::TermCriteria criteria,
	int flags // flag of calibrateCamera() 
)
{
	// variables
	int nimg;
	std::vector<std::vector<cv::Point2f> > corners; 
	std::vector<std::vector<Point3f> > objectPoints;
	bool bres;
	// find number of pairs of the calibration photos
	nimg = (int)imgs.size();
	if (nimg <= 0) {
		cerr << "calibrateCameraChessboard() error: No photos input.\n";
		return -1;
	}
	// Convert to gray level image
	corners.resize(nimg);
	for (int iimg = 0; iimg < nimg; iimg++)
	{
		cv::Mat img_m;
		if (imgs[iimg].channels() == 1)
			img_m = imgs[iimg];
		else if (imgs[iimg].channels() == 3)
			cv::cvtColor(imgs[iimg], img_m, CV_BGR2GRAY);
		// Find chessboard corner
		bres = cv::findChessboardCorners(img_m, bsize, corners[iimg]);
		if (bres == false) {
			cerr << "Calibration error: Cannot find chessboard corners in calib image.\n";
			return -1;
		}
		cv::cornerSubPix(img_m, corners[iimg], cv::Size(5, 5), cv::Size(0, 0), criteria);
		// check ordering. Convert to left-to-right ordering. If not, reverse points.
		if (corners[iimg][0].x > corners[iimg][corners[iimg].size() - 1].x)
			std::reverse(corners[iimg].begin(), corners[iimg].end());
	}
	// generate object points
	objectPoints = vector<vector<Point3f> > (nimg, Create3DChessboardCorners(bsize, squareSize_w, squareSize_h));

	// stereo calib
	if (cmat.cols != 3 || cmat.rows != 3 || 
		flags & CV_CALIB_USE_INTRINSIC_GUESS == false) {
		cmat = initCameraMatrix2D(objectPoints, corners, imageSize, 0);
		dmat = Mat::zeros(1, 8, CV_32F);
	}
	double rms = calibrateCamera(objectPoints, corners, imageSize,
		cmat, dmat,
		rmats, tmats, 
		flags, 
		//		CALIB_FIX_ASPECT_RATIO +
		//		CALIB_ZERO_TANGENT_DIST +
		//      CALIB_USE_INTRINSIC_GUESS +
		//      CALIB_SAME_FOCAL_LENGTH +
		//      CALIB_RATIONAL_MODEL +
		//      CALIB_FIX_K2 + CALIB_FIX_K3 + CALIB_FIX_K5 + CALIB_FIX_K6,
		//		CALIB_FIX_K3 + CALIB_FIX_K6,
		//		CALIB_FIX_K3 + CALIB_FIX_K4 + CALIB_FIX_K5,
		criteria);

	return rms;
}


int stereoCalibrateChessboard(
	const std::vector<cv::Mat> & imgs_L,
	const std::vector<cv::Mat> & imgs_R,
	cv::Size imageSize,
	cv::Size bsize,
	float squareSize_w, float squareSize_h,
	cv::Mat & cmat_L,
	cv::Mat & cmat_R,
	cv::Mat & dmat_L,
	cv::Mat & dmat_R,
	cv::Mat & rmat,
	cv::Mat & tmat,
	cv::Mat & emat,
	cv::Mat & fmat,
	cv::TermCriteria criteria,
	int flags
)
{
	// variables
	int npair;
	std::vector<std::vector<cv::Point2f> > corners_L, corners_R;
	std::vector<std::vector<Point3f> > objectPoints;
	bool bres;
	// find number of pairs of the calibration photos
	npair = (int) imgs_L.size(); 
	if (npair <= 0) {
		cerr << "stereoCalibrateChessboard() error: No photos input.\n";
		return -1;
	}
	if (npair != imgs_R.size()) {
		cerr << "stereoCalibrateChessboard() error: Left and right photos should have the same number of photos.\n";
		return -1; 
	}
	// Convert to gray level image
	corners_L.resize(npair); 
	corners_R.resize(npair); 
	for (int ipair = 0; ipair < npair; ipair++)
	{
		cv::Mat img_Lm, img_Rm;
		if (imgs_L[ipair].channels() == 1)
			img_Lm = imgs_L[ipair];
		else if (imgs_L[ipair].channels() == 3)
			cv::cvtColor(imgs_L[ipair], img_Lm, CV_BGR2GRAY);
		if (imgs_R[ipair].channels() == 1)
			img_Rm = imgs_R[ipair];
		else if (imgs_R[ipair].channels() == 3)
			cv::cvtColor(imgs_R[ipair], img_Rm, CV_BGR2GRAY);
		// Find chessboard color
		//   left
		bres = cv::findChessboardCorners(img_Lm, bsize, corners_L[ipair]);
		if (bres == false) {
			cerr << "Calibration error: Cannot find chessboard corners in left image.\n";
			return -1;
		}
		cv::cornerSubPix(img_Lm, corners_L[ipair], cv::Size(5, 5), cv::Size(0, 0), criteria);
		//   right
		bres = cv::findChessboardCorners(img_Rm, bsize, corners_R[ipair]);
		if (bres == false) {
			cerr << "Calibration error: Cannot find chessboard corners in right image.\n";
			return -1;
		} 
		cv::cornerSubPix(img_Rm, corners_R[ipair], cv::Size(5, 5), cv::Size(0, 0), criteria);

		// check ordering. Convert to left-to-right ordering. If not, reverse points.
		if (corners_L[ipair][0].x > corners_L[ipair][corners_L[ipair].size() - 1].x)
			std::reverse(corners_L[ipair].begin(), corners_L[ipair].end());
		if (corners_R[ipair][0].x > corners_R[ipair][corners_R[ipair].size() - 1].x)
			std::reverse(corners_R[ipair].begin(), corners_R[ipair].end());
	}
	// generate object points
	objectPoints.resize(npair);
	for (int i = 0; i < npair; i++)
	{
		for (int j = 0; j < bsize.height; j++)
			for (int k = 0; k < bsize.width; k++)
				objectPoints[i].push_back(cv::Point3f(k*squareSize_w, j*squareSize_h, 0));
	}

	// stereo calib
	cmat_L = initCameraMatrix2D(objectPoints, corners_L, imageSize, 0);
	cmat_R = initCameraMatrix2D(objectPoints, corners_R, imageSize, 0);
	dmat_L = Mat::zeros(1, 8, CV_32F); 
	dmat_R = Mat::zeros(1, 8, CV_32F);
	double rms = stereoCalibrate(objectPoints, corners_L, corners_R,
		cmat_L, dmat_L,
		cmat_R, dmat_R,
		imageSize, rmat, tmat, emat, fmat, 
//		CALIB_FIX_ASPECT_RATIO +
//		CALIB_ZERO_TANGENT_DIST +
		CALIB_USE_INTRINSIC_GUESS +
		CALIB_SAME_FOCAL_LENGTH +
		CALIB_RATIONAL_MODEL +
		CALIB_FIX_K2 + CALIB_FIX_K3 + CALIB_FIX_K5 + CALIB_FIX_K6,
//		CALIB_FIX_K3 + CALIB_FIX_K6,
//		CALIB_FIX_K3 + CALIB_FIX_K4 + CALIB_FIX_K5,
		criteria);

	return 0;
}

void griddata(double xa, double xb, int nx, double ya, double yb, int ny, cv::Mat & X, cv::Mat & Y)
{
	if (nx <= 0 || ny <= 0) {
		cerr << "Warning: griddata() got nx <= 0 or ny <= 0. Check it.\n";
		return;
	}
	X.create(ny, nx, CV_64F);
	Y.create(ny, nx, CV_64F);
	double dx = nx > 1 ? (xb - xa) / (nx - 1) : 0.0;
	double dy = ny > 1 ? (yb - ya) / (ny - 1) : 0.0;
	for (int i = 0; i < ny; i++) {
		for (int j = 0; j < nx; j++)
		{
			X.at<double>(i, j) = xa + j * dx;
			Y.at<double>(i, j) = ya + i * dy;
		}
	}
}

#if defined(WIN32) || defined(_WIN32) || defined(__WIN32) && !defined(__CYGWIN__)
std::string uigetfile(void)
{
	std::string stdstring;
	static char filename[1024]; 
	OPENFILENAME ofn;
	ZeroMemory(&filename, sizeof(filename));
	ZeroMemory(&ofn, sizeof(ofn));
	ofn.lStructSize = sizeof(ofn);
	ofn.hwndOwner = NULL;  // If you have a window to center over, put its HANDLE here
	ofn.lpstrFilter = "Any Files\0*.*\0";
	ofn.lpstrFile = filename;
	ofn.nMaxFile = MAX_PATH;
	ofn.nMaxFile = sizeof(filename);
	ofn.lpstrTitle = "Select Files";
	ofn.Flags = OFN_DONTADDTORECENT | OFN_FILEMUSTEXIST | OFN_EXPLORER;
	if (GetOpenFileName(&ofn))
	{
		stdstring = std::string(ofn.lpstrFile);
	}	
	return stdstring;
}

std::vector<std::string> uigetfiles(void)
{
	std::vector<std::string> filenames;
	static char filename[256 * 32768]; // allocate 2 MB for file names (allowing about 30,000 files with average filename length of 64 characters)
	OPENFILENAME ofn;
	ZeroMemory(&filename, sizeof(filename));
	ZeroMemory(&ofn, sizeof(ofn));
	ofn.lStructSize = sizeof(ofn);
	ofn.hwndOwner = NULL;  // If you have a window to center over, put its HANDLE here
	ofn.lpstrFilter = "Any Files\0*.*\0";
	ofn.lpstrFile = filename;
	ofn.nMaxFile = MAX_PATH;
	ofn.nMaxFile = sizeof(filename);
	ofn.lpstrTitle = "Select Files";
	ofn.Flags = OFN_DONTADDTORECENT | OFN_FILEMUSTEXIST | OFN_ALLOWMULTISELECT | OFN_EXPLORER;
	if (GetOpenFileName(&ofn))
	{
		int idx = 0;
		while (true) {
			LPSTR str = ofn.lpstrFile + idx;
			if (strlen(str) > 0)
				filenames.push_back(std::string(str));
			else
				break;
			idx += (int) strlen(str) + 1;
		}
		filenames[0] += "\\";
	}
	return filenames;
}



#endif



