#ifndef _ImProReadReferencePoints_h_
#define _ImProReadReferencePoints_h_

#include <string>
#include <vector>

#include "opencv2/core.hpp"

int readReferencePoints(
	std::string fname,
	std::vector<std::string> & headers,
	std::vector<cv::Point3f> & objPoints,
	std::vector<cv::Point2f> & imgPoints); 


#endif