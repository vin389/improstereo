#ifndef _getTime_h
#define _getTime_h_

double getCpusTime();
double getWallTime();

#endif
