#include "ImProReadReferencePoints.h"

#include <iostream>
#include <fstream>
#include <stdio.h>
#include <stdlib.h>
#include <vector>
#include <string>
using namespace std;

#include "opencv2/core.hpp"
#include "opencv2/calib3d.hpp"

int readReferencePoints(
	string fname,
	vector<std::string> & headers,
	vector<cv::Point3f> & objPoints,
	vector<cv::Point2f> & imgPoints)
{
	// clear inputs
	headers.clear();
	objPoints.clear();
	imgPoints.clear(); 

	// check if file exists
	std::ifstream csvfile(fname.c_str()); 
	if (csvfile.is_open() == false)
		return -1; 

	// Read line by line
	string csvline;
	// read header line
	std::getline(csvfile, csvline);
	try {
		std::stringstream  lineStream(csvline);
		for (int i = 0; i < 5; i++) {
			std::string        cell;
			std::getline(lineStream, cell, ',');
			headers.push_back(cell);
		}
	}
	catch (...) {
		cerr << "Warning: ImProReadReferncePoint did not get headers properly. \n"; 
	}
	// read data
	while (csvfile.eof() == false)
	{
		// read a line
		std::getline(csvfile, csvline); 
		std::stringstream  lineStream(csvline);
		std::string        cell;
		try {
			// read object points (3D)
			cv::Point3f objpoint;
			std::getline(lineStream, cell, ',');
			objpoint.x = stof(cell);
			std::getline(lineStream, cell, ',');
			objpoint.y = stof(cell);
			std::getline(lineStream, cell, ',');
			objpoint.z = stof(cell);
			// read image points (2D)
			cv::Point2f imgpoint;
			std::getline(lineStream, cell, ',');
			imgpoint.x = stof(cell);
			std::getline(lineStream, cell, ',');
			imgpoint.y = stof(cell);
			// if image point is (0,0) or any of it is negative, it means this point is not seen in this image.
			if (imgpoint.x == 0.0f && imgpoint.y == 0.0f) continue;
			if (imgpoint.x < 0.0f || imgpoint.y < 0.0f) continue;
			// add point
			imgPoints.push_back(imgpoint); 
			objPoints.push_back(objpoint);
		}
		catch (...) {
			break;
		}
	}





	return 0;
}