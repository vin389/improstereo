#ifndef _ImProUtil_h_
#define _ImProUtil_h_

#include <vector>
#include <string>
#include "opencv2/core.hpp"
#include "opencv2/calib3d.hpp"

#include "triangulatepoints2.h"

std::vector<double> linspace(double a, double b, int n);
std::vector<float>  linspace(float a, float b, int n);

void griddata(float xa, float xb, int nx, float ya, float yb, int ny, cv::Mat & X, cv::Mat & Y);
void griddata(double xa, double xb, int nx, double ya, double yb, int ny, cv::Mat & X, cv::Mat & Y);

bool findChessboardCornersSubpix(cv::Mat image, cv::Size patternSize, std::vector<cv::Point2f> & corners,
	int flags = cv::CALIB_CB_ADAPTIVE_THRESH + cv::CALIB_CB_NORMALIZE_IMAGE,
	cv::TermCriteria criteria = cv::TermCriteria(cv::TermCriteria::COUNT + cv::TermCriteria::EPS, 30, 1e-6)); 

std::vector<cv::Point3f> Create3DChessboardCorners(cv::Size bsize, float squareSize_w, float squareSize_h); 

double calibrateCameraFromChessboardImages(
	const std::vector<cv::Mat> & imgs, 
	cv::Size imageSize, 
	cv::Size bsize, 
	float squareSize_w, float squareSize_h,
	cv::Mat & cmat,
	cv::Mat & dmat,
	std::vector<cv::Mat> & rmats,
	std::vector<cv::Mat> & tmats,
	cv::TermCriteria criteria = cv::TermCriteria(cv::TermCriteria::COUNT + cv::TermCriteria::EPS, 30, 1e-6),
	int flags = 0  // flag of calibrateCamera() 
);


int stereoCalibrateChessboard(
	const std::vector<cv::Mat> & imgs_L, 
	const std::vector<cv::Mat> & imgs_R,
	cv::Size imageSize,
	cv::Size bsize, 
	float squareSize_w, float squareSize_h,
	cv::Mat & cmat_L,
	cv::Mat & cmat_R, 
	cv::Mat & dmat_L, 
	cv::Mat & dmat_R, 
	cv::Mat & rmat, 
	cv::Mat & tmat, 
	cv::Mat & emat, 
	cv::Mat & fmat, 
	cv::TermCriteria criteria = cv::TermCriteria(cv::TermCriteria::COUNT + cv::TermCriteria::EPS, 30, 1e-6),
	int flags = 0  // flag of stereoCalibrate() 
);




#if defined(WIN32) || defined(_WIN32) || defined(__WIN32) && !defined(__CYGWIN__)
std::string              uigetfile(void);
std::vector<std::string> uigetfiles(void);
#endif 

#endif
