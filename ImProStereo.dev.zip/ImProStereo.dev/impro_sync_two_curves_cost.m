function cost = impro_sync_two_curves_cost(DT, ut1, ut2, t1_begin, t1_end, target)
cost = 1e9;
n1_total = size(ut1(:),1);
n2_total = size(ut2(:),1);
t1_begin = max(1, t1_begin);
t1_end   = min(t1_end, n1_total);
t2_begin = t1_begin + DT;
t2_end   = t1_end   + DT;
if (t2_end > n2_total)
    t2_end = n2_total;
    t1_end = t2_end - DT;
end
if (t2_begin < 1) 
    t2_begin = 1;
    t1_begin = t2_begin - DT;
end
if (t2_end <= t2_begin || t1_end <= t1_begin)
    return;
end
ut1_trim = interp1(1:n1_total, ut1, linspace(t1_begin, t1_end, 1000) );
ut2_trim = interp1(1:n2_total, ut2, linspace(t2_begin, t2_end, 1000) );
cost = corr(ut1_trim(:), ut2_trim(:));
cost = abs(cost - target); 
% figure; subplot(2,1,1); plot(ut1_trim(:)); subplot(2,1,2); plot(ut2_trim(:))
end