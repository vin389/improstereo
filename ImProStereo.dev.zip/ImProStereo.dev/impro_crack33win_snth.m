% This function calculates the 3x3 displacement field window at a 
% perfect crack point with sliding(s), opening(n), along theta(th, in deg)

function [ux33,uy33] = impro_crack33win_snth(s, n, th)
th = mod(th, 180); 
cth = cos(th * 3.14159265359 / 180);
sth = sin(th * 3.14159265359 / 180);
if th == 0
    psgn = [1 1 1; 0 0 0; -1 -1 -1]; 
elseif th < 45
    psgn = [1 1 1; 1 0 -1; -1 -1 -1];
elseif th == 45
    psgn = [1 1 0; 1 0 -1; 0 -1 -1];
elseif th < 90
    psgn = [1 1 -1;1 0 -1; 1 -1 -1];
elseif th == 90
    psgn = [1 0 -1;1 0 -1;1 0 -1];
elseif th < 135
    psgn = [1 -1 -1;1 0 -1;1 1 -1];
elseif th == 135
    psgn = [0 -1 -1; 1 0 -1;1 1 0];
else
    psgn = [-1 -1 -1;1 0 -1;1 1 1];
end
uxval = 0.5 * (cth * s - sth * n);
uyval = 0.5 * (sth * s + cth * n);
ux33 = uxval * psgn;
uy33 = uyval * psgn; 
end




