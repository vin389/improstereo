function handles = impro_CtrlPointDisp( hObject, handles )
% This function calculates the rigid body displacement of a coordinate
% system wrt to another coord. system (normally the fixed coord. sys.) 
%
% Modified by vince (2015-05-06, 2015-05-14)
%    Allows that only partial ctrl points have been tracked. 
%      Original: CtrlPosit( :  , ......) = handles.CtrlPoints( :  , ......) ; 
%                iPair = 2: handles.nPair (etc)
%      Modified: CtrlPosit(1:nPair_Tracked, ......) = handles.CtrlPoints(1:nPair_Tracked, ......) ;
%                iPair = 2: size(......)  (etc)
% 

% Advanced option dialog
dialog_prompt = { '1. Ctrl point(s):', ...
                  '2. Coord. sys. ID (-1 for left image coord. -2 for right image coord.' };                
dialog_title  = 'Plot/save control point disp.';
dialog_default= { '1', '1'};
dialog_answer = inputdlg( dialog_prompt, dialog_title, 1, dialog_default );

if ( size(dialog_answer,1) == 0 )
  return;
end

% Coord. sys IDs
CtrlPointRange = str2num(dialog_answer{1}); 
coordID_ref    = str2num(dialog_answer{2}); 

% number of pairs that have been tracked. 
nPair_Tracked = size(handles.CtrlPoints3D, 1);

% Check if handles.CoordSys is empty
if (exist('handles.CoordSys', 'var') == 0) 
  % if no coord. sys is defined, at least define:
  % handles.CoordSys{1:handles.nPair,1} = identity(4,4); 
  for iPair = 1: nPair_Tracked
    handles.CoordSys{iPair,1} = [1 0 0 0; 0 1 0 0; 0 0 1 0; 0 0 0 1];   
  end
end

if ( (coordID_ref < -2) || ... 
     (coordID_ref >= 1 && coordID_ref > size(handles.CoordSys, 2))) 
  fprintf('Invalid input of movement coord. ID.\n');
  return;
end

nPointPlot = size( CtrlPointRange, 2 ); 

% if left/right image coord.
if ( coordID_ref == -2 )
  CtrlPosit  = zeros( nPair_Tracked, 3 * nPointPlot );
  for iiPoint = 1: nPointPlot
    iPoint = CtrlPointRange(iiPoint);
    CtrlPosit(1:nPair_Tracked, (iiPoint-1)*3+1 ) = handles.CtrlPoints(1:nPair_Tracked, 2, iPoint, 1) ;
    CtrlPosit(1:nPair_Tracked, (iiPoint-1)*3+2 ) = handles.CtrlPoints(1:nPair_Tracked, 2, iPoint, 2) ;
    CtrlPosit(1:nPair_Tracked, (iiPoint-1)*3+3 ) = 0; 
  end
end
if ( coordID_ref == -1 )
  CtrlPosit  = zeros( nPair_Tracked, 3 * nPointPlot );
  for iiPoint = 1: nPointPlot
    iPoint = CtrlPointRange(iiPoint);
    CtrlPosit(1:nPair_Tracked, (iiPoint-1)*3+1 ) = handles.CtrlPoints(1:nPair_Tracked, 1, iPoint, 1);
    CtrlPosit(1:nPair_Tracked, (iiPoint-1)*3+2 ) = handles.CtrlPoints(1:nPair_Tracked, 1, iPoint, 2);
    CtrlPosit(1:nPair_Tracked, (iiPoint-1)*3+3 ) = 0; 
  end
end
  
% if cam. coord.
if ( coordID_ref == 0 )
  CtrlPosit  = zeros( nPair_Tracked, 3 * nPointPlot );
  for iiPoint = 1: nPointPlot
    iPoint = CtrlPointRange(iiPoint);
    CtrlPosit(1:nPair_Tracked, (iiPoint-1)*3+1 ) = handles.CtrlPoints3D(1:nPair_Tracked, 1, iPoint, 1);
    CtrlPosit(1:nPair_Tracked, (iiPoint-1)*3+2 ) = handles.CtrlPoints3D(1:nPair_Tracked, 1, iPoint, 2);
    CtrlPosit(1:nPair_Tracked, (iiPoint-1)*3+3 ) = handles.CtrlPoints3D(1:nPair_Tracked, 1, iPoint, 3);
  end
end

% if user-defined coord.
if ( coordID_ref >= 1 )
  CtrlPosit  = zeros( nPair_Tracked, 3 * nPointPlot );
  for iPair = 1: nPair_Tracked
    % Transform matrix from cam coord. to ref coord.
    refMat = handles.CoordSys{iPair, coordID_ref}; 
    refMat = inv(refMat); 
    for iiPoint = 1: nPointPlot
      iPoint = CtrlPointRange(iiPoint);
      thePoint4      = zeros(4,1);
      thePoint4(1:3) = handles.CtrlPoints3D(iPair, 1, iPoint, 1:3);
      thePoint4(4)   = 1.0; 
      thePoint4 = refMat * thePoint4; 
      CtrlPosit( iPair, (iiPoint-1)*3+1 ) = thePoint4(1);
      CtrlPosit( iPair, (iiPoint-1)*3+2 ) = thePoint4(2);
      CtrlPosit( iPair, (iiPoint-1)*3+3 ) = thePoint4(3);
    end
  end
end

% calculate the displacements from the positions
CtrlDisps = zeros(size(CtrlPosit)); 
nPair_Tracked = size(handles.CtrlPoints, 1);
for iPair = 2: nPair_Tracked
  for iiPoint = 1: nPointPlot
    CtrlDisps( iPair, (iiPoint-1)*3+1 ) =  CtrlPosit( iPair, (iiPoint-1)*3+1 ) - CtrlPosit( 1, (iiPoint-1)*3+1 );
    CtrlDisps( iPair, (iiPoint-1)*3+2 ) =  CtrlPosit( iPair, (iiPoint-1)*3+2 ) - CtrlPosit( 1, (iiPoint-1)*3+2 );
    CtrlDisps( iPair, (iiPoint-1)*3+3 ) =  CtrlPosit( iPair, (iiPoint-1)*3+3 ) - CtrlPosit( 1, (iiPoint-1)*3+3 );
  end
end

% Plot it 

for iiPoint = 1: nPointPlot
  iPoint = CtrlPointRange(iiPoint);
  figure('Name', sprintf('Control points displacements P-%02d', iPoint) );
  xt = 1: size(CtrlDisps, 1); 
  if ( coordID_ref < 0) 
      plot(xt, CtrlDisps(:,(iiPoint-1)*3+1), ...
           xt, CtrlDisps(:,(iiPoint-1)*3+2), 'LineWidth', 2 );
      legend('Ux', 'Uy');
      ylabel('Displacements (pixel)');
  else
      plot(xt, CtrlDisps(:,(iiPoint-1)*3+1), ...
           xt, CtrlDisps(:,(iiPoint-1)*3+2), ...
           xt, CtrlDisps(:,(iiPoint-1)*3+3), 'LineWidth', 2 );
      legend('Ux', 'Uy', 'Uz');
      ylabel('Displacements (mm)');
  end
  xlabel('Photo pair'); 
  grid on; 
end

% Save it to a file (ask user)
[datFile, datPath] = uiputfile('*.txt', ...
  'Save the control point displacement data as ... CANCEL if you do not want to save');
if ( ischar(datFile) )
  fid = fopen( [datPath datFile], 'w' );
  % fprintf title row
  fprintf( fid, 'iPair\t');  
  for iiPoint = 1: nPointPlot
%    iPoint = CtrlPointRange(iiPoint);
    if ( coordID_ref < 0) 
        fprintf( fid, 'Ux\tUy\t');
    else
        fprintf( fid, 'Ux-%d\tUy-%d\tUz-%d\t', ...
            CtrlPointRange(iiPoint), CtrlPointRange(iiPoint), CtrlPointRange(iiPoint) ); % point number added. modified by vince, 21-Mar-2015
    end
  end
  fprintf( fid, '\n');
  % fprintf data rows
  for iPair = 1: nPair_Tracked
    fprintf(fid, '%d\t', iPair );
    for iiPoint = 1: nPointPlot
%      iPoint = CtrlPointRange(iiPoint);
      if ( coordID_ref < 0) 
          for idof = 1: 2
            fprintf( fid, '%10.2f\t', ...
              CtrlDisps(iPair, (iiPoint-1)*3 + idof) );
          end
      else
          for idof = 1: 3
            fprintf( fid, '%10.2f\t', ...
              CtrlDisps(iPair, (iiPoint-1)*3 + idof) );
          end
      end
    end % end of iiPoint
    fprintf( fid, '\n');
  end % end of iPair
  fclose(fid);
  
end % end if user saves data to a file. 














