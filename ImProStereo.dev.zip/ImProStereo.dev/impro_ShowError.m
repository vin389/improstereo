function handles = impro_ShowError( hObject, handles )
% This function shows template matching errors and triangulation errors
% of all control points in each pair

if ( isfield( handles, 'measurementErr' ) ) 
  % Template matching error 
  if ( isfield( handles.measurementErr, 'TmpltErr' ) )
    TmpltErrL(:,:)=handles.measurementErr.TmpltErr(:,1,:); 
    figure('Name', 'Template matching correlation (L)'); 
    imagesc(TmpltErrL); colorbar; 
    TmpltErrR(:,:)=handles.measurementErr.TmpltErr(:,2,:); 
    figure('Name', 'Template matching correlation (R)'); 
    imagesc(TmpltErrR); colorbar; 
  end
  % Triangulation error
  if ( isfield( handles.measurementErr, 'StereoErr' ) )
    figure('Name', 'Triangulation error'); 
    imagesc(handles.measurementErr.StereoErr); colorbar; 
  end
end



