/*
 * =============================================================
 * Matlab interface of OpenCV optical flow for a sparse feature set using 
 * the iterative Lucas-Kanade method with pyramids (cvCalcOpticalFlowPyrLK)
 * 
 * function [prevPyr, currPyr, currFeatures, status, track_error] = ...
 *          cvCalcOpticalFlowPyrLK( prev, curr, ...
 *                                  prevPyr, currPyr, ...
 *                                  prevFeatures, ...
 *                                  count, winSize, level, ...
 *                                  criteria, flags )
 * 
 *   Input:
 *     prev:         Image of the first frame. If it is a color image (i.e.,
 *                   3-channel) it is converted to a gray image.
 *                   MATLAB data type: uint8()
 *     curr:         Image of the second frame. If it is a color image (i.e.,
 *                   3-channel) it is converted to a gray image.
 *                   MATLAB data type: uint8()
 *     prevPyr:      Buffer for the pyramid for the first frame. Sufficient
 *                   size: (image_width+8)*(image_height+2)/3, or a NULL pointer
 *                   will be inputted. 
 *                   Note: OpenCV's cvCalcOpticalFlowPyrLK changes its 
 *                         prevPyr and/or currPyr internally. However, 
 *                         this function does in a different way. It makes
 *                         a clone of prevPyr for OpenCV. The clone is 
 *                         changed by OpenCV and returned to MATLAB. 
 *                         Therefore, the original inputted MATLAB array 
 *                         prevPyr/currPyr is not changed unless the user 
 *                         uses the same array at output (the left-hand-
 *                         side prevPyr/currPyr).
 *     currPyr:      Similar to prevPyr, used for the second image
 *     prevFeatures: Single precision floating-point array of points for 
 *                   which the flow needs to be found. The image coord. 
 *                   index starts from 1 (to be consistent with MATLAB). 
 *                   MATLAB data type: single()
 *     count:        an integer number of feature points
 *                   MATLAB data type: int32()
 *     winSize:      size of the search window of each pyramid level
 *                   MATLAB data type: int32()
 *     level:        Maximal pyramid level number. If 0, pyramids are not 
 *                   used (single level). If 1, two levels are used, etc.
 *                   MATLAB data type: int32()
 *     criteria:     specific when the iteration process of finding the flow
 *                   for each point on each pyramid level should be stopped
 *                   criteria(1): type: criteria(1)==1 --> CV_TERMCRIT_ITER
 *                                      criteria(1)==2 --> CV_TERMCRIT_EPS
 *                   criteria(2): max_iter 
 *                   criteria(3): epsilon
 *                   MATLAB data type: double()
 *     flags:        miscellaneous flags: 
 *                       CV_LKFLOW_PYR_A_READY       1
 *                       CV_LKFLOW_PYR_B_READY       2
 *                       CV_LKFLOW_INITIAL_GUESSES   4
 *                   MATLAB data type: int32()
 *   Output:
 *     prevPyr:      Buffer for the pyramid for the first frame. Sufficient
 *                   size: (image_width+8)*(image_height+2)/3, or a NULL pointer
 *                   will be inputted. 
 *     currPyr:      Similar to prevPyr, used for the second image
 *     currFeatures: Single precision floating-point array of 2D points 
 *                   containing the calculated new positions of the input 
 *                   features in the 2nd image. The image coord. index 
 *                   starts from 1 (to be consistent with MATLAB). 
 *                   MATLAB data type: single()
 *     status:       Array. Every element of the array is set to 1 if the 
 *                   flow for the corresponding feature has been found, 
 *                   0 otherwise.
 *     trackerror:   Array of double numbers containing the difference 
 *                   between patches around the original and moved points. 
 *                   Optional parameters. 
 *
 *     
 * Developed by Yuan-Sen Yang
 * Date: 2011.05.24
 * Date: 2013.03.19 bug fixed (
 *
 * =============================================================
 */
     
#include <mex.h>
#include <matrix.h>
#include "opencv2\core\core.hpp"
#include "opencv2\imgproc\imgproc_c.h"
#include "opencv2\video\tracking.hpp"
#include "opencv2\video\tracking_c.h"
#include "opencv2\highgui\highgui.hpp"

#include <stdlib.h>
#include <stdio.h>

CvMat* newCvGrayImageFromMatlab( const mxArray* prhsx, int w=0, int h=0 );
CvMat* newCvMat2D32fFromMatlab( const mxArray* prhsx ); 
CvPoint2D32f* newCvPoint2D32fArrayFromMatlab( const mxArray* prhsx );
CvTermCriteria* newCvTermCriteriaFromMatlab( const mxArray* prhsx );
double GetDoubleScalarFromMatlab( const mxArray* prhsx, int index = 0 ); 

void mexFunction( int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
 
  // Check for proper number of arguments.
  if (nrhs < 10) {
    mexErrMsgTxt("arguments: prev, curr, prevPyr, currPyr, prevFeatures, count, winSize, level, criteria, flag\n");
  } 
  if (nlhs > 5) {
    mexErrMsgTxt("Too many output arguments. Output: [prevPyr, currPyr, currFeatures, status, track_error]\n");
  }

  // Check if two images are the same size. If not, get the larger width
  // and the larger height. 
  const mwSize* prevSize  = mxGetDimensions( prhs[0] );
  const mwSize* currSize  = mxGetDimensions( prhs[1] );
  int prevWidth  = prevSize[1]; 
  int prevHeight = prevSize[0]; 
  int currWidth  = currSize[1]; 
  int currHeight = currSize[0]; 
  if ( prevWidth != currWidth || prevHeight != currHeight ) {
    mexWarnMsgTxt("Warning: Two inputted images are not in the same size.");
    mexWarnMsgTxt("   The larger width and the larger height are used.\n");
  }
  int imgWidth  = prevWidth  > currWidth  ? prevWidth  : currWidth ; 
  int imgHeight = prevHeight > currHeight ? prevHeight : currHeight; 
  
  // Input parameters 1 and 2: MATLAB image to new OpenCV image 
  CvMat* cvPrev = newCvGrayImageFromMatlab( prhs[0], imgWidth, imgHeight ); 
  CvMat* cvCurr = newCvGrayImageFromMatlab( prhs[1], imgWidth, imgHeight ); 

  // Input parameters 3 and 4: MATLAB image to new OpenCV image. 
     // These parameters are actually one-D CV_U8 (uchar) arrays sized
     // (image_width+8)*(image_height+2)/3. See OpenCV manual for details. 
	 // If the input arrays are too small, use minimal required size. 
  const mwSize* prevPyrSize  = mxGetDimensions( prhs[2] );
  int prevPyrWidth  = prevPyrSize[1]; 
  int prevPyrHeight = prevPyrSize[0];   
  CvMat* cvPrevPyr; 
  if ( prevPyrWidth*prevPyrHeight >= ((prevWidth+8)*(prevHeight+2)+2)/3 )
  {        // The array size is sufficient. Information is kept and cloned. 
    cvPrevPyr = newCvGrayImageFromMatlab( prhs[2] );
  } else { // The array size is too small. Information is ignored. 
    cvPrevPyr = cvCreateMat(1, ((prevWidth+8)*(prevHeight+2)+2)/3, CV_8U);
    cvSetZero( cvPrevPyr ); 
    printf("Renew a working array for cvPrevPyr sized %d.\n", ((prevWidth+8)*(prevHeight+2)+2)/3);
  }
  
  const mwSize* currPyrSize  = mxGetDimensions( prhs[3] );
  int currPyrWidth  = currPyrSize[1]; 
  int currPyrHeight = currPyrSize[0];  
  CvMat* cvCurrPyr; 
  if ( currPyrWidth*currPyrHeight >= ((currWidth+8)*(currHeight+2)+2)/3 )
  {        // The array size is sufficient. Information is kept and cloned. 
    cvCurrPyr = newCvGrayImageFromMatlab( prhs[3] );
  } else { // The array size is too small. Information is ignored. 
    cvCurrPyr = cvCreateMat(1, ((currWidth+8)*(currHeight+2)+2)/3, CV_8U);
    cvSetZero( cvCurrPyr ); 
    printf("Renew a working array for cvCurrPyr sized %d.\n", ((currWidth+8)*(currHeight+2)+2)/3);
  }

  // Input parameter 5: MATLAB 2D array to new OpenCV CvMat 
  //   Also decrease by 1 for 0-base OpenCV image coord. 
  CvPoint2D32f* cvPrevFea = newCvPoint2D32fArrayFromMatlab( prhs[4] );
  int nFeatures = mxGetN( prhs[4] ); 
  for (int i=0; i<nFeatures; i++) {
    cvPrevFea[i].x -= 1.0f; 
    cvPrevFea[i].y -= 1.0f; 
  }
  
  // Input parameter 6: count
  int count   = (int) (GetDoubleScalarFromMatlab(prhs[5])+0.5); 
  
  // Input parameter 7: winSize
  CvSize winSize;
  winSize.width  = (int) (GetDoubleScalarFromMatlab(prhs[6],0)+0.5); 
  winSize.height = (int) (GetDoubleScalarFromMatlab(prhs[6],1)+0.5); 
  
  // Input parameter 8: level
  int level   = (int) (GetDoubleScalarFromMatlab(prhs[7])+0.5); 
  
  // Input parameter 9: CvTermCriteria
  CvTermCriteria* theCriteria = newCvTermCriteriaFromMatlab( prhs[8] ); 
  
  // Input parameter 10: flat (an integer)  
  int flags   = (int) (GetDoubleScalarFromMatlab(prhs[9])+0.5); 
    
  // Allocate MATLAB arrays for some output parameters

  // Output parameter 3: currFeatures 
  //   cvCurrFea: a float array sized 2*count. 
  //              Also seen as a CvPoint2D32f array sized 1*count. 
  //              Increase by 1 for 1-base MATLAB image coord. 
  int ndim; mwSize dims[2];  
  ndim = 2; 
  dims[0] = 2; dims[1] = count; 
  plhs[2] = mxCreateNumericArray(ndim, dims, mxSINGLE_CLASS, mxREAL );
  CvPoint2D32f* cvCurrFea = (CvPoint2D32f*) mxGetPr( plhs[2] ); 

  // Output parameter 4: status 
  //   status: a char array sized count. 
  ndim = 2; 
  dims[0] = 1; dims[1] = count; 
  plhs[3] = mxCreateNumericArray(ndim, dims, mxINT8_CLASS, mxREAL );
  char * status = (char*) mxGetPr( plhs[3] ); 

  // Output parameter 5: trackerror
  //   status: a char array sized count. 
  ndim = 2; 
  dims[0] = 1; dims[1] = count; 
  plhs[4] = mxCreateNumericArray(ndim, dims, mxSINGLE_CLASS, mxREAL );
  float* trackerror = (float*) mxGetPr( plhs[4] ); 
   
  // Call cvCalcOpticalFlowPyrLK  
  cvCalcOpticalFlowPyrLK( cvPrev, cvCurr, 
                          cvPrevPyr, cvCurrPyr, 
                          cvPrevFea, cvCurrFea, 
                          count, winSize, level, 
                          status, 
                          trackerror,
                          *theCriteria,  
                          flags );

  // Output parameter 1: cvPrevPyr 
  //   cvPrevPyr: a buffer (char array) with the same size as prevPyr:  
  //              (image_width+8)*(image_height+2)/3. We simply copy and 
  //              return it without changing anything. 
  ndim = 2; 
  if ( prevPyrWidth*prevPyrHeight >= ((prevWidth+8)*(prevHeight+2)+2)/3 )
  {        // The array size is sufficient. 
    dims[0] = prevPyrHeight;
    dims[1] = prevPyrWidth;
  } else { // The array size is too small. 
    dims[0] = 1;
    dims[1] = ((prevWidth+8)*(prevHeight+2)+2)/3;
  }
  plhs[0] = mxCreateNumericArray(ndim, dims, mxINT8_CLASS, mxREAL );
  memcpy( (void*) mxGetPr( plhs[0] ), (void*) cvPrevPyr->data.ptr, 
          dims[0]*dims[1] ); 
                          
  // Output parameter 2: cvCurrPyr 
  //   cvPrevPyr: a buffer (char array) with the same size as currPyr:  
  //              (image_width+8)*(image_height+2)/3. We simply copy and 
  //              return it without changing anything. 
  ndim = 2; 
  if ( currPyrWidth*currPyrHeight >= ((currWidth+8)*(currHeight+2)+2)/3 )
  {        // The array size is sufficient. 
    dims[0] = currPyrHeight; 
    dims[1] = currPyrWidth;
  } else { // The array size is too small. 
    dims[0] = 1;
    dims[1] = ((currWidth+8)*(currHeight+2)+2)/3;
  }
  plhs[1] = mxCreateNumericArray(ndim, dims, mxINT8_CLASS, mxREAL );
  memcpy( (void*) mxGetPr( plhs[1] ), (void*) cvCurrPyr->data.ptr, 
          dims[0]*dims[1] ); 

  // Output parameters 3 to 5: currFeatures, status, and trackerror
  //    have been taken care of. 
  //    currFeatures needs to increase by 1 for 1-base MATLAB img. coord.
  for (int i=0; i<nFeatures; i++) {
    cvCurrFea[i].x += 1.0f; 
    cvCurrFea[i].y += 1.0f; 
  }
  
  /* release opencv images */
  cvReleaseMat(&cvPrev);
  cvReleaseMat(&cvCurr);
  //delete [] cvPrevFea;   // marked this line on 2013.03.19. Did not remember why this line was written in 2011.
  //delete [] cvCurrFea;   // marked this line on 2013.03.19. Did not remember why this line was written in 2011.
  delete theCriteria;   
}


// This function creates an OpenCV gray-scale image and copies a MATLAB
// image to the new OpenCV image.
// Limit: The MATLAB image must be either a 3-channel (RGB) color image or
//        a 1-channel gray-scale image. 
CvMat* newCvGrayImageFromMatlab( const mxArray* prhsx, int newW, int newH )
{
  /* Get dimensional information of the MATLAB array */ 
  uchar*  matImage        = (uchar*) mxGetPr(prhsx);
  mwSize  nDim            = mxGetNumberOfDimensions( prhsx );  
  const mwSize* imgDim    = mxGetDimensions( prhsx );
  int     imgWidth        = (int) imgDim[1];
  int     imgHeight       = (int) imgDim[0];
  int     imgDepth        = 8;  /* must be 8. Or this function would collapse */ 
  int     imgNChannels; 
  int     i, j; 
  if ( nDim == 3 ) 
  {
    /* This is a color image (3D or multi-channel) */
    imgNChannels = (int) imgDim[2];  
  } 
  else if ( nDim == 2 ) 
  {
    /* This is a gray image (2D or single-channel) */
    imgNChannels = 1; 
  }
  else 
  {
    mexErrMsgTxt("Error: This function does not support 4-dim (or more) array.\n");
    return NULL;     
  } 
  if ( newW <= 0 ) 
    newW = imgWidth;  // The width of new image
  if ( newH <= 0 ) 
    newH = imgHeight; // The height of new image.
  
  /* allocate an OpenCV gray image */ 
  CvMat* cvImg = cvCreateMat(newH, newW, CV_8U);
  if ( cvImg == NULL ) 
  {
    mexErrMsgTxt("Error: Out of memory when allocating a CvMat.\n");
    return NULL;     
  }
  cvSet( cvImg, cvScalar(0) );
  
  /* copy MATLAB image to an OpenCV gray image */ 
  if ( imgNChannels == 3 ) 
  {
    /* if MATLAB image is a color image */
    for(j = 0; j < imgHeight; j++) {
      for(i = 0; i < imgWidth; i++) {
        cvImg->data.ptr[j*newW+i] = 
              (uchar) ((matImage[j + i * imgHeight + imgWidth * imgHeight * 0] + 
                        matImage[j + i * imgHeight + imgWidth * imgHeight * 1] +
                        matImage[j + i * imgHeight + imgWidth * imgHeight * 2] )/3.f+0.5f); 
    } }
  }
  else if ( imgNChannels == 1 ) 
  {
    /* if MATLAB image is a gray image */
    for(j = 0; j < imgHeight; j++) {
      for(i = 0; i < imgWidth; i++) {
        cvImg->data.ptr[j*newW+i] = 
              (uchar) (matImage[j + i * imgHeight] ); 
    } }
  }
  else  
  {
    mexErrMsgTxt("Error: This function only supports 1- and 3-channel image.\n");
    cvReleaseMat(&cvImg); 
    return NULL;     
  } 
  
  return cvImg; 
}


CvMat* newCvMat2D32fFromMatlab( const mxArray* prhsx )
{
  /* Get dimensional information of the MATLAB array */ 
  float*  mat2D           = (float*) mxGetPr(prhsx);
//  size_t  nDim            = mxGetNumberOfDimensions( prhsx );
//  const mwSize* imgDim    = mxGetDimensions( prhsx );
  int     matWidth        = (int) mxGetN( prhsx ); // the product of dim 2 through nDim.
  int     matHeight       = (int) mxGetM( prhsx );
  int     i, j; 
  
  /* allocate an OpenCV gray image */ 
  CvMat* cvMat2D32f = cvCreateMat(matHeight, matWidth, CV_32FC1);
  if ( cvMat2D32f == NULL ) 
  {
    mexErrMsgTxt("Error: Out of memory when allocating a CvMat.\n");
    return NULL;     
  }

  /* Copy data from MATLAB array to the new CvMat */
  if ( mxIsSingle( prhsx ) ) 
  {
    for(i = 0; i < matHeight; i++) {
      for(j = 0; j < matWidth; j++) {
        cvMat2D32f->data.fl[i*matWidth+j] =
                (float) (mat2D[i + j * matHeight] );
      } 
    }
  }
  else if ( mxIsDouble( prhsx ) )
  {
    double * mat2DDouble = (double*) mat2D; 
    for(i = 0; i < matHeight; i++) {
      for(j = 0; j < matWidth; j++) {
        cvMat2D32f->data.fl[i*matWidth+j] =
                (float) (mat2DDouble[i + j * matHeight] );
      } 
    }
  }
  else
  {
    mexErrMsgTxt("Error: Supports only single and double array.\n");
    cvReleaseMat(&cvMat2D32f); 
    return NULL;     
  }
  
  return cvMat2D32f; 
}

CvPoint2D32f* newCvPoint2D32fArrayFromMatlab( const mxArray* prhsx )
{
  /* Get dimensional information of the MATLAB array */ 
  float*  mat2D           = (float*) mxGetPr(prhsx);
//  size_t  nDim            = mxGetNumberOfDimensions( prhsx );
//  const mwSize* imgDim    = mxGetDimensions( prhsx );
  int     matWidth        = (int) mxGetN( prhsx ); // the product of dim 2 through nDim.
  int     matHeight       = (int) mxGetM( prhsx );
  int     j; 
  
  if ( matHeight != 2 )
  {
    mexErrMsgTxt("Error: The height dimension of prevFeatures must be 2.\n");
    return NULL;     
  }
  
  /* allocate an OpenCV array of CvPoint2D32f */ 
  CvPoint2D32f* theCvPoint2D32fArray = new CvPoint2D32f[matWidth*matHeight/2]; 
  if ( theCvPoint2D32fArray == NULL ) 
  {
    mexErrMsgTxt("Error: Out of memory when allocating a CvPoint2D32f array.\n");
    return NULL;     
  }

  /* Copy data from MATLAB array to the new CvPoint2D32f array  */
  if ( mxIsSingle( prhsx ) ) 
  {
    for(j = 0; j < matWidth; j++) {
      theCvPoint2D32fArray[j].x = (float) (mat2D[j * matHeight + 0] );
      theCvPoint2D32fArray[j].y = (float) (mat2D[j * matHeight + 1] );
    }
  }
  else if ( mxIsDouble( prhsx ) )
  {
    double * mat2DDouble = (double*) mat2D; 
    for(j = 0; j < matWidth; j++) {
      theCvPoint2D32fArray[j].x = (float) (mat2DDouble[j * matHeight + 0] );
      theCvPoint2D32fArray[j].y = (float) (mat2DDouble[j * matHeight + 1] );
    }
  }
  else
  {
    mexErrMsgTxt("Error: Supports only single and double array.\n");
    delete [] theCvPoint2D32fArray;  
    return NULL;     
  }
  
  return theCvPoint2D32fArray; 
}

CvTermCriteria* newCvTermCriteriaFromMatlab( const mxArray* prhsx )
{
  CvTermCriteria * criteriaPtr = new CvTermCriteria; 
  
  if ( mxIsDouble( prhsx ) )
  {
    double* criteriaMat   = (double*) mxGetPr(prhsx);
    criteriaPtr->type     = (int) ( criteriaMat[0] + 0.5 ); 
    criteriaPtr->max_iter = (int) ( criteriaMat[1] + 0.5 ); 
    criteriaPtr->epsilon  = criteriaMat[2]; 
  } 
  else if ( mxIsSingle( prhsx ) ) 
  {
    float* criteriaMat    = (float*) mxGetPr(prhsx);
    criteriaPtr->type     = (int) ( criteriaMat[0] + 0.5f ); 
    criteriaPtr->max_iter = (int) ( criteriaMat[1] + 0.5f ); 
    criteriaPtr->epsilon  = (double) criteriaMat[2]; 
  }
  else
  {
    mexErrMsgTxt("Error: Supports only single and double array.\n");
    delete criteriaPtr; 
    return NULL;     
  }
  
  return criteriaPtr; 
}

double GetDoubleScalarFromMatlab( const mxArray* prhsx, int index )
{
  double ret; 
  if ( mxIsDouble( prhsx ) )
  {
    ret = *( ((double*) mxGetPr(prhsx)) + index ) ;
  } 
  else if ( mxIsSingle( prhsx ) )
  {
    ret = (double) *( ((float*) mxGetPr(prhsx)) + index ) ;
  }
  else if ( mxIsInt8( prhsx ) )
  {
    ret = (double) *( ((char*) mxGetPr(prhsx))  + index ) ;
  }
  else if ( mxIsUint8( prhsx ) )
  {
    ret = (double) *( ((uchar*) mxGetPr(prhsx)) + index ) ;
  }
  else if ( mxIsInt16( prhsx ) )
  {
    ret = (double) *( ((short*) mxGetPr(prhsx)) + index ) ;
  }
  else if ( mxIsInt32( prhsx ) )
  {
    ret = (double) *( ((int*) mxGetPr(prhsx)) + index ) ;
  }
  else
  {
    mexErrMsgTxt("Error: Unsupported data type.\n");
    return 0.0;     
  }
  return ret; 
}

