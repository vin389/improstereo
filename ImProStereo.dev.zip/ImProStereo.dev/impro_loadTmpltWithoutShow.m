function [handles,iTmpltImg] = ...
         impro_loadTmpltWithoutShow(hObject, handles, iPair, iLR, iPoint)
% This function loads and shows template image and data to file
% Loaded template data is at handles.iTmplt{iLR} without showing it on 
% axes. This is for performance issue.
% Loaded image is iTmpltImg 

% Template image
succRead = 0;
if ( exist([handles.TmpltPath{iLR} handles.filelistTmplt{iPair,iLR}], 'file') )
  % load Tmplt file image and show it
  iTmplt = load([handles.TmpltPath{iLR} handles.filelistTmplt{iPair,iLR}]);
  % handles.iTmplt = iTmplt.iTmplt;
  handles.iTmplt{iLR} = iTmplt.iTmplt; % Modified by vince. 2013/04/23
  if ( size(handles.iTmplt{iLR}.file,2) >= iPoint && ...   
       exist([handles.TmpltPath{iLR} handles.iTmplt{iLR}.file{iPoint}],'file') )
    iTmpltImg = imread([handles.TmpltPath{iLR} handles.iTmplt{iLR}.file{iPoint}]);
    succRead = 1;
    % display the current
%    axes(handles.axTmplt{iLR});
%    cla(handles.axTmplt{iLR}); % If we do not clear axes first, the image
                               % object is added and the original image 
                               % is not cleared. Memory usage expands.
%    image(iTmpltImg);
    % draw a cross at the reference point
%    impro_drawCross( handles.axTmplt{iLR}, ...
%         handles.iTmplt{iLR}.refXy{iPoint}, 'blue' );
    % print a text message on console 
    fprintf('Template Pair:%d/LR:%d/Pnt:%d loaded.\n', iPair,iLR,iPoint);
  end
end
if ( succRead == 0 )
  cla(handles.axTmplt{iLR});
  fprintf('Template Pair:%d/LR:%d/Pnt:%d is not loaded.\n',iPair,iLR,iPoint);
  iTmpltImg = [];
  handles.iTmplt = [];
end

end
