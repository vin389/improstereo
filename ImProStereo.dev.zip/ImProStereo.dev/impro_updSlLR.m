function handles = impro_updSlLR(hObject, handles)

if ( isfield(handles, 'nLR') && handles.nLR < 2 )      
    return;
end

% Set the slider disable until this function completes.

set(handles.slLR,'Enable','off');

% Set ui object properties
handles.iLR = get(handles.slLR, 'Value');
handles.iLR = round(handles.iLR);
iLR = handles.iLR; 
set(handles.slLR, 'Value', iLR); 
txLR={'Left','Right'};
set(handles.txLR, 'String', txLR{iLR} );

% Set the slider disable until this function completes.
set(handles.slLR,'Enable','on');

end