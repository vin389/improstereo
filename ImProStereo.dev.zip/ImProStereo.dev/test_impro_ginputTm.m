
mex -O cvTemplateMatch220.cpp -Iopcv/include opcv/lib/cv.lib opcv/lib/opencv_core220.lib opcv/lib/opencv_imgproc220.lib
close all; clear all;
timg=imread('Examples\NDP4\L\IMG_7164.JPG');
tmpl=timg(1001:1050,1101:1150,:);
[result] = cvTemplateMatch220( tmpl, timg, [980 1099 1059 1199 ], 10 ); fprintf('%10.4f\n',result);

figure; image(timg);

nPoint = 1;
theImg = timg;
inpTmImgs = { tmpl };
inpXy = [25.5 25.5];
[xy, outTmImgs, outXy] = impro_ginputTmCf( nPoint, theImg, inpTmImgs, inpXy  )
fprintf('%10.4f \n', xy );


