function [vtx faces] = impro_cylinFace(vx,vy,vz,ori,R,th1,th2,h1,h2, m, n)
% This function generates vertices and faces of the cylinder surface. 

vtx   = zeros( (m+1)*(n+1), 3 );
faces = zeros(  m   * n   , 4 ); 

% Generate vertices coordinates.
ivtx = 0; 
for im = 1: m+1
  h = h1 + (h2-h1)/m * (im-1); 
  for in = 1: n+1
    ivtx = ivtx+1; 
    th = th1 + (th2-th1)/n * (in-1); 
    vtx(ivtx,1:3) = ori + R*cos(th)*vx + R*sin(th)*vy + h * vz;
%   for th = 0:(th2/180*pi)/n:(th2/180*pi)
%     ivtx = ivtx+1;
%     vtx(ivtx,1:3) = ori + R*cos(th)*vx + R*sin(th)*vy + h * vz;
  end
end

% Generate faces connectivity
iface = 0; 
for im = 1: m
  for in = 1: n
    iface = iface + 1;
    faces(iface, 1) = (im-1)*(n+1) + in ; 
    faces(iface, 2) = (im-1)*(n+1) + in+1; 
    faces(iface, 3) = (im-0)*(n+1) + in+1 ; 
    faces(iface, 4) = (im-0)*(n+1) + in ;     
  end
end

end