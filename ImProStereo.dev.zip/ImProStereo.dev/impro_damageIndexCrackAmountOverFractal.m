function di = impro_damageIndexCrackAmountOverFractal(hObject, handles)
% This version sees 0-degree as flexural cracks, and
% 45,90,135-degree as shear cracks. (2019/5/30)
% Then divided by fractal method (2019/6/24)

di_amount = impro_damageIndexCrackAmount_F0_S4590135(hObject, handles);
dif = impro_damageIndexFractal_m1(hObject, handles);
rshear = di_amount.data_4590135 ./ (di_amount.data_0 + di_amount.data_4590135);
rflex = di_amount.data_0 ./ (di_amount.data_0 + di_amount.data_4590135);

dif_data = reshape(dif.data, size(rshear));
di_shear = rshear .* dif_data;
for i = 1:size(di_shear,1)
    for j = 1:size(di_shear, 2)
        di_shear(i,j) = max(di_shear(i, 1:j));  
    end
end
di_flex = rflex .* dif_data;
for i = 1:size(di_flex,1)
    for j = 1:size(di_flex, 2)
        di_flex(i,j) = max(di_flex(i, 1:j));  
    end
end

di.crackThresholds = di_amount.crackThresholds;
di.steps = di_amount.steps;
di.data = di_shear + di_flex; 
di.data_flexural = di_flex;
di.data_shear = di_shear; 

% plot 
figure;
num_thresholdCrack = size(di.data, 1); 
for thresholdCrack_idx = 1: num_thresholdCrack
    thresholdCrack = di.crackThresholds(thresholdCrack_idx); 
    ydata(:) = di.data(thresholdCrack_idx, :); 
    iPair_i_range = di.steps; 
    plot(iPair_i_range, ydata, ...
            'o-', 'LineWidth', 2); grid on; 
    hold on; 
    legendStrings{thresholdCrack_idx} = sprintf('Crack Threshold %f', thresholdCrack); 
end
title(sprintf('Damage Index History. (Amount over fractal)')); 
xlabel('Photo Step');
ylabel('Damage Index'); 
legend(legendStrings); 

figure; % flexural 
num_thresholdCrack = size(di.data, 1); 
for thresholdCrack_idx = 1: num_thresholdCrack
    thresholdCrack = di.crackThresholds(thresholdCrack_idx); 
    ydata(:) = di.data_flexural(thresholdCrack_idx, :); 
    iPair_i_range = di.steps; 
    plot(iPair_i_range, ydata, ...
            'o-', 'LineWidth', 2); grid on; 
    hold on; 
    legendStrings{thresholdCrack_idx} = sprintf('Crack Threshold %f', thresholdCrack); 
end
title(sprintf('Damage Index History. (Amount over fractal - Flexural)')); 
xlabel('Photo Step');
ylabel('Damage Index (Flexural)'); 
legend(legendStrings); 

figure;
num_thresholdCrack = size(di.data, 1); 
for thresholdCrack_idx = 1: num_thresholdCrack
    thresholdCrack = di.crackThresholds(thresholdCrack_idx); 
    ydata(:) = di.data_shear(thresholdCrack_idx, :); 
    iPair_i_range = di.steps; 
    plot(iPair_i_range, ydata, ...
            'o-', 'LineWidth', 2); grid on; 
    hold on; 
    legendStrings{thresholdCrack_idx} = sprintf('Crack Threshold %f', thresholdCrack); 
end
title(sprintf('Damage Index History. (Amount over fractal - Shear)')); 
xlabel('Photo Step');
ylabel('Damage Index (Shear)'); 
legend(legendStrings); 




% save
filePath = handles.ListPath; 
diFilenameMat = [filePath sprintf('damage_index_amountOverFractal.mat')]; 
save(diFilenameMat, 'di'); 

