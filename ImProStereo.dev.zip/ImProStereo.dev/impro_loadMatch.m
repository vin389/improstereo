function [handles,iMatchImg] = ...
         impro_loadMatch(hObject, handles, iPair, iLR, iPoint)
% This function loads and shows matched image and data from file
% Loaded match data is at handles.iMatch{iLR} 
% and handles.iMatchImg{iLR,iPoint}

% Matched image
succRead = 0;
if ( exist([handles.MatchPath{iLR} handles.filelistMatch{iPair,iLR}], 'file') )
  % load Match file image and show it
  iMatch = load([handles.MatchPath{iLR} handles.filelistMatch{iPair,iLR}]);
  % handles.iMatch = iMatch.iMatch;
  handles.iMatch{iLR} = iMatch.iMatch; % Modified by vince. 2013/4/23
  if ( size(handles.iMatch{iLR}.file,2) >= iPoint && ...   
       exist([handles.MatchPath{iLR} handles.iMatch{iLR}.file{iPoint}], 'file') == 2) % Modified by vince. 2017/07/06    
    % Read matched image 
    iMatchImg = imread([handles.MatchPath{iLR} handles.iMatch{iLR}.file{iPoint}]);
    % Duplicate control point image coordinate
    handles.CtrlPoints(iPair,iLR,iPoint,1:2) = ...
      handles.iMatch{iLR}.mchXy{iPoint}(1,1:2);     
    succRead = 1;
    % display the current images
    % For performance issue, we avoid usage of axes() without output. 
    % (according to MATLAB suggestion).
    % (--vince, 06/18/2012)
    % axes(handles.axMatch{iLR});
    cla(handles.axMatch{iLR}); % If we do not clear axes first, the image
                               % object is added and the original image 
                               % is not cleared. Memory usage expands.
    xlim(handles.axMatch{iLR}, [1 size(iMatchImg,2)]);
    ylim(handles.axMatch{iLR}, [1 size(iMatchImg,1)]);
    % image(iMatchImg);
    image(iMatchImg, 'Parent', handles.axMatch{iLR});
    % draw a cross at the reference point in small Match axes
    impro_drawCross( handles.axMatch{iLR}, ...
         handles.iMatch{iLR}.refXy{iPoint}, 'red' );
    % draw a cross at the reference point in large photo axes
    impro_drawCross( handles.axPhoto{iLR}, ...
         handles.iMatch{iLR}.mchXy{iPoint}, 'red' );
    % disable label
    axes(handles.axMatchLeft);
    set(gca,'XTickLabel',[]); 
    set(gca,'YTickLabel',[]); 
    axes(handles.axMatchRigt);
    set(gca,'XTickLabel',[]); 
    set(gca,'YTickLabel',[]);     
    % print a text message on console 
    fprintf('Match Pair:%d/LR:%d/Pnt:%d loaded.\n', iPair, iLR, iPoint );
    % display the current correlations
    set(handles.txCorr{iLR},'String',sprintf('Correlation=%6.3f',...
      handles.iMatch{iLR}.corr{iPoint}) );
  end
end
if ( succRead == 0 )
  cla(handles.axMatch{iLR});
  set(handles.txCorr{iLR},'String',sprintf('Correlation=%6.3f',0));
  fprintf('Match Pair:%d/LR:%d/Pnt:%d is not loaded.\n',iPair,iLR,iPoint);
  iMatchImg = [];
  handles.iMatch = [];
end

end



