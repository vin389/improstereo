function Xk = impro_find3dOnSurface( xk, SurfaceFunction, ...
              fc, cc, kc, ac, om, T, initGuess)
% This function finds the 3D position (3D) of a point in the image (2D). 
% As a 2D image coord is not insufficient to find its 3D position, the
% user requires to additionally specify a surface that contains the point. 
% The user needs to input: 
%    (1) Image coord. positions of the control points.
%    (2) Surface function that reads 2D coord (a1, a2) and 
%        outputs 3D coord (X,Y,Z) 
%    (3) camera intrinsic parameters. 
%
% Input parameters:
%     xk              - Feature locations on the images (2xN) 
%     SurfaceFunction - Surface function that converts a 2D coord to 
%                       3D coord.
%                       Format: X = SurfaceFunction( a ), where
%                       X is a 3xN array, and a is a 2xN array.
%     fc              - Camera focal length
%     cc              - Principal point coordinates
%     kc              - Distortion coefficients
%     alpha_c         - Skew coefficient
%     (om,T)          - Rigid motion parameters between world coordinate
%                       frame and camera reference frame
%     initGuess       - Initial guess of paramters of surface paramter.
%                       (2x1)
% Output parameters: 
%     Xk  - Feature locations in 3D coord. (3xN)

if (nargin < 9) 
    initGuess = [0;0];
end

% Check dimensions
Nchk = size(xk, 1); 
if ( Nchk ~= 2 )
    errordlg( ['Error - Wrong array size.' ...
         'xk for impro_Find3dOnSurface() must have a size of 2xN.']);
    Xk = [];
end
N = size( xk, 2 );
Xk = zeros(3, N);

if strcmp( class(SurfaceFunction), 'char') 
    if ( strcmpi(SurfaceFunction, 'XY' ) || ...
         strcmpi(SurfaceFunction, 'YX' ) || ...
         strcmpi(SurfaceFunction, 'zplane') ) 
        SurfaceFunction = @(alpha) impro_Surface_XY( alpha, [0 0 0]);
    elseif ( strcmpi(SurfaceFunction, 'YZ' ) || ...
             strcmpi(SurfaceFunction, 'ZY' ) || ...
             strcmpi(SurfaceFunction, 'xplane') ) 
        SurfaceFunction = @(alpha) impro_Surface_YZ( alpha, [0 0 0] );
    elseif ( strcmpi(SurfaceFunction, 'ZX' ) || ...
             strcmpi(SurfaceFunction, 'XZ' ) || ...
             strcmpi(SurfaceFunction, 'yplane') ) 
        SurfaceFunction = @(alpha) impro_Surface_XZ( alpha, [0 0 0] );
    end
end

for i = 1: N
   foptions.MaxFunEvals = 1e4;
   foptions.MaxIter = 1e4;
   [a,err] = fminsearch( @(a) objF(xk(:,i), a, ...
                                   SurfaceFunction, ...
                                   om, T, fc, cc, kc, ac ), ...
                                   initGuess, ...
                                   foptions);
   Xk(:,i) = SurfaceFunction(a);
end
end

function err = objF(xk,aTrial,Surf,om,T,f,c,k,alpha)

XkTrial = Surf(aTrial);
xkTrial = project_points2(XkTrial,om,T,f,c,k,alpha);

err = norm(xk(:)-xkTrial(:));

end



%
% Example SurfaceFunction for tests.
%
% Xk = impro_Find3dOnSurface( xk, @(a) Surface_XY(a, 0), fc,cc,kc,ac );
%

function X = Surface_XY( alpha, basepoint )
N = size(alpha,2);
X = zeros(3,N);
X(1,:)   = alpha(1,:) + basepoint(1);
X(2,:)   = alpha(2,:) + basepoint(2);
X(3,1:N) = basepoint(3);
end

function X = Surface_XZ( alpha, basepoint )
N = size(alpha,2);
X = zeros(3,N);
X(1,:)   = alpha(1,:) + basepoint(1);
X(2,1:N) = basepoint(2);
X(3,:)   = alpha(2,:) + basepoint(3);
end

function X = Surface_YZ( alpha, basepoint )
N = size(alpha,2);
X = zeros(3,N);
X(1,1:N) = basepoint(1);
X(2,:)   = alpha(1,:) + basepoint(2);
X(3,:)   = alpha(2,:) + basepoint(3);
end
