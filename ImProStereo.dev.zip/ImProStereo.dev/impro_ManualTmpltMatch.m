function handles = impro_ManualTmpltMatch(hObject, handles, iPair, iLR, iPoint, Dx, Dy)

% Load template data and image
% Loaded template data is at handles.iTmplt{iLR} 
%           iTmplt{iLR}.nPoint   -- number of control points in each photo
%           iTmplt{iLR}.file{iP} -- file name of template image file (.JPG)
%           iTmplt{iLR}.pckXy{iP}(1,1:2) -- picked point in image
%           iTmplt{iLR}.refXy{iP}(1,1:2) -- picked point in template
[handles,iTmpltImg]= impro_loadTmplt(hObject, handles, iPair, iLR, iPoint);

% Load photo 
% The loaded photo is at handles.iPhoto{iLR}; 
[handles,iPhotoImg]= impro_loadPhoto(hObject, handles, iPair, iLR); 

% % Calculate matching range [y1 y2 x1 x2]
% expRange = [100 100 100 100];
% matchRange(1,1) = handles.iTmplt{iLR}.pckXy{iPoint}(2) - ...
%                   handles.iTmplt{iLR}.refXy{iPoint}(2) - expRange(1);
% matchRange(1,2) = matchRange(1,1) + ...
%                   size(iTmpltImg,2) + ...
%                   expRange(1) + expRange(2); 
% matchRange(1,3) = handles.iTmplt{iLR}.pckXy{iPoint}(1) - ...
%                   handles.iTmplt{iLR}.refXy{iPoint}(1) - expRange(3);
% matchRange(1,4) = matchRange(1,3) + ...
%                   size(iTmpltImg,1) + ...
%                   expRange(3) + expRange(4); 
     
% Template matching using impro_ginputTm

ginputTmOptions.autogXy = [];
ginputTmOptions.range   = [Dy Dy Dx Dx]; 
if ( isfield(handles, 'TmpltSize') ) 
    ginputTmOptions.TmpltSize = handles.TmpltSize;
end
% added 'matchMethod' option (21-Apr-2014 by vince) 
if ( isfield(handles, 'matchMethod') ) 
    ginputTmOptions.tm_method = handles.matchMethod;
end
% added 'tmPrecision' option (08-Oct-2014 by vince) 
if ( isfield(handles, 'tmPrecision') ) 
    ginputTmOptions.tm_precision = handles.tmPrecision;
end

tmpImg{1} = iTmpltImg; % Must input cell(s) of image(s)
[xy, mchImg, refXy] = impro_ginputTm( 1, iPhotoImg, ...
                         tmpImg, ...
                         handles.iTmplt{iLR}.refXy{iPoint}, ...
                         ginputTmOptions ); 
mchXy = xy(1,1:2);                       
corr  = xy(1,3);
handles.measurementErr.TmpltErr(iPair, iLR, iPoint) = corr; % added by vince (2012/05/01) 
                
% Save matched image to iMatch
handles = impro_saveMatch(hObject, handles, iPair, iLR, iPoint, ...
          mchImg{1}, mchXy, refXy, corr ); 
% Show it.        
handles = impro_loadMatch(hObject, handles, iPair, iLR, iPoint); 

end