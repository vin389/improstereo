function [xy, outTmImgs, outXy, mod] = ...
    impro_ginputTm( nPoint, theImg, inpTmImgs, inpXy, options )
%
%impro_ginputTm     Graphical input from mouse with zoom, pan, plot,
%                   scaling, and supports template matching selecting.
%
%   SYNTAX:
%        [xy, outTmImgs, outXy] = ...
%        impro_ginputTm( nPoint, theImg, inpTmImgs, inpXy  )
%
%   INPUT:
%     nPoint     - Number of points to be selected. One of 1,2,...,Inf
%     theImg     - The background image on the axe
%     inpTmImgs  - The template image(s) that is(are) used for template
%                  matching. If its size is [0 0] then the template
%                  matching function turns off.
%                  The inpTmImgs{iP} is the template for the iP-th point.
%     inpXy      - The reference point position in the inpTmimgs
%                  The inpXy(iP,1:2) is the ref point of the iP-th point.
%                  The inpXy(ip,1:2) is X:Y (X first, Y later).
%     options (optional) - options of this function
%                - options.autogXy
%                  If options.autogXy (autogXy=[mx my]) is assigned,
%                  the inputted [mx my] replaces the ginput function
%                  and the function does not need the user to click
%                  the mouse. If this option is not given,
%                  the mouse click(s) is(are) required.
%                - options.range ([expY1 expY2 expX1 expX2])
%                  The expension (from template boundaries) of matching
%                  search range. If this option is not given, it is
%                  set to [100 100 100 100].
%                  If any number in the range of matching is zero or less,
%                  it means the user does not need help from template
%                  matching. In this case, the clicked position is returned
%                  without using template matching.
%                - options.tm_method (one of the following strings)
%                  'CV_TM_SQDIFF_NORMED', 'CV_TM_CCORR', 
%                  'CV_TM_CCORR_NORMED',  'CV_TM_CCOEFF', 
%                  'CV_TM_CCOEFF_NORMED'
%
%   OUTPUT:
%     xy        - [x(:) y(:) correlation(:) ] axis coordinate(s).
%                 The size of xy is [nPoint 2].
%                 The xy(iP,1:2) is the matched point of the iP-th point.
%                 The inpXy(ip,1:2) is X:Y (X first, Y later).
%     outTmImgs - A cell list of images around selected points.
%                 The size of outTmImgs is [1 nPoint].
%                 The size of each image outTmImgs{i} is
%                 [ Tsize Tsize 3 ].
%                 The outTmImgs{iP} is the output matched image of the
%                 iP-th point.
%     outXy -     [selx(:) sely(:)]
%                 The selected points in the selTmImgs. Normally they are
%                 around [ Tsize/2 Tsize/2 ].
%                 The outXy(iP,1:2) is the ref point of in the matched
%                 image.
%     mod       - Mode of ctrlpoints selected.
%
%   DESCRIPTION:
%
%   EXAMPLE:
%
%   ---
%   VERSION: 2.x.x (Apr. 21, 2014) - add options.tm_method
%   VERSION: 2.x.x (Dec. 11, 2013) - add timing and its printing.
%   VERSION: 2.1.0 (Jun. 15, 2012) - remove options.TmpltSize. Each match
%            image size is the same as its template.
%   VERSION: 2.0.1 (Feb. 23, 2011) - add an input argument autogXy
%   VERSION: 2.0 (Feb. 13, 2011)
%   MATLAB: R2009a
%   AUTHOR:  Yuan-Sen Yang
%   CONTACT: ysyang@ntut.edu.tw
%
%   DISCLAIMER:
%   Provided "as is" without warranty of any kind.

% initialization
theImgW = size(theImg, 2);
theImgH = size(theImg, 1);

% timing
tic;  

% Check option arguments
if (nargin == 4)
    options = [];
    options.autogXy = [];
    options.range   = [ 100 100 100 100 ];
end

% Get options
if ( ~exist('options') || ~isfield(options, 'autogXy') )
    options.autogXy = [];
    options.range   = [ 100 100 100 100 ];
end
if ( ~exist('options') || ~isfield(options, 'range') )
    options.range   = [ 100 100 100 100 ];
end
if ( ~exist('options') || ~isfield(options, 'TmpltSize') )
    options.TmpltSize   = 30;
end
if ( ~exist('options') || ~isfield(options, 'tm_method') )
    options.tm_method = 'CV_TM_CCORR_NORMED'; 
end
if ( ~exist('options') || ~isfield(options, 'tm_precision') )
    options.tm_precision = 0.02; 
end
Tsize = options.TmpltSize;

% Main loop (through control points)
for iP = 1: nPoint
    if ( ~isempty(inpTmImgs) && ~isempty(inpTmImgs{iP}))
        Tsize = size(inpTmImgs{iP},2); % assume template image is square.
    end
    % Step 1: Calls ginputzp to get a point from mouse
    
    if ( size(options.autogXy,1)==0 )
        gxy = [];
        % Get a click from mouse
        while (size(gxy,1)==0)
            [mx,my,mb] = ginput2zp(1);
            gxy = [mx my];
            %
            % If user presses SPACE, open an advanced picking dialog
            %
            if (mb==32)
                % Advanced option dialog
                dialog_prompt = { 'Picking method (1:Corner. 2. Edge centroid. 3. Manual Centroid)', ...
                    '1:corner window [wx xy]', ...
                    '2:ObjSize [size_x size_y]', ...
                    '3:# of clicks for centroid' };
                dialog_title  = 'Advanced picking';
                dialog_default= { '1', '[3 3]', '[150 150]', '20' };
                dialog_answer = inputdlg( dialog_prompt, dialog_title, 1, dialog_default );
                % invalid input
                if ( size(dialog_answer,1) == 0 )
                    gxy = [];
                    continue;
                end
                % 1. Corner finder
                if ( str2num(dialog_answer{1}) == 1 )
                    fprintf('Corner finder chosen.\n');
                    winxy = str2num(dialog_answer{2});
                    xt = ginput2zp(1);
                    [xc] = cornerfinder(xt', theImg, winxy(1), winxy(2) );
                    gxy = [xc(1) xc(2)];
                    mod = 1;
                end % end of if centroid
                % 2. Centroid of edge points
                if ( str2num(dialog_answer{1}) == 2 )
                    fprintf('Edge centroid finder chosen.\n');
                    mod = 2;
                    objsize = str2num(dialog_answer{3});
                    xt = ginput2zp(1);
                    % range of picture of object
                    y1 = max(      1, round( xt(2)-objsize(2) ) );
                    y2 = min(theImgH, round( xt(2)+objsize(2) ) );
                    x1 = max(      1, round( xt(1)-objsize(1) ) );
                    x2 = min(theImgW, round( xt(1)+objsize(1) ) );
                    % Canny edge detection
                    objImg = theImg(y1:y2, x1:x2, :);
                    edgeMap = cvCannyAuto( objImg );
                    % User picks an edge
                    hFig = figure('Name', 'Pick the edge you prefer');
                    image((edgeMap-90)*6); axis image;
                    xtedge = ginput2zp(1);
                    close(hFig);
                    edgeId = edgeMap(round(xtedge(2)), round(xtedge(1)) );
                    % Calculate centroid of the polygon surrounded by picked edge
                    [area,cx,cy] = impro_centroidEdge(edgeMap, edgeId);
                    gxy = [cx+x1-1 cy+y1-1];
                end % end of if centroid
                % 3. Manual centroid (centroid of manually picked points)
                if ( str2num(dialog_answer{1}) == 3 )
                    fprintf('Manual centroid finder chosen.\n');
                    mod = 3;
                    np = str2num(dialog_answer{4});
                    [centx,centy] = ginput2zp(np);
                    [polyArea, polyCx, polyCy]=polycenter(centx,centy);
                    gxy = [polyCx polyCy];
                end % end of if centroid
            else
                mod = 0;
            end % end of if mb==32
        end % end of while gxy==[]
    else
        gxy = options.autogXy(1:2);
    end
    xy(iP,:) = gxy;
    
    % Step 2: Calls template matching to find an approximation position
    if ( size(inpTmImgs,1)>=1 && size(inpTmImgs,2)>=1 && ...
            size(inpXy,    1)>=1 && size(inpXy,    2)>=1 )
        % Search range of template matching.
        % It is around xy(iP,:).
        % Search range of Y
        searchRangeY1 = round( xy(iP,2) - options.range(1) - inpXy(iP,2) );
        searchRangeY2 = round( xy(iP,2) + options.range(2) - inpXy(iP,2) + ...
            size( inpTmImgs{iP}, 1) );
        % Search range of X
        searchRangeX1 = round( xy(iP,1) - options.range(3) - inpXy(iP,1) );
        searchRangeX2 = round( xy(iP,1) + options.range(4) - inpXy(iP,1) + ...
            size( inpTmImgs{iP}, 2) );
        %     % lower bound check of range Y
        %     if ( searchRangeY1 < 1 )
        %       searchRangeY1 = 1;
        %       searchRangeY2 = searchRangeY1 + 2 *Tsize -1;
        %     end
        %     % upper bound check of range Y
        %     if ( searchRangeY2 > size(theImg,1) )
        %       searchRangeY2 = size(theImg,1);
        %       searchRangeY1 = searchRangeY2 - 2 *Tsize +1;
        %     end
        %     % lower bound check of range X
        %     if ( searchRangeX1 < 1 )
        %       searchRangeX1 = 1;
        %       searchRangeX2 = searchRangeX1 + 2 *Tsize -1;
        %     end
        %     % upper bound check of range X
        %     if ( searchRangeX2 > size(theImg,2) )
        %       searchRangeX2 = size(theImg,2);
        %       searchRangeX1 = searchRangeX2 - 2 *Tsize +1;
        %     end
        
        % Template matching
        if ( options.range(1)>0 && options.range(2)>0 && ...
                options.range(3)>0 && options.range(4)>0 )
            % Template matching
            % Template matching precision (function added on 08-Oct-2014)
            tmResizing = round(1 / options.tm_precision); 
            if ( exist('cvTemplateMatchOptn') == 3)
                cvtm_options = zeros(1, 10, 'int32');
                % Set template matching method
                cvtm_options(1) = 3; % CV_TM_CCORR_NORMED %default
                if (strcmpi(options.tm_method, 'CV_TM_SQDIFF'))
                    cvtm_options(1) = 0; 
                elseif (strcmpi(options.tm_method, 'CV_TM_SQDIFF_NORMED'))
                    cvtm_options(1) = 1; 
                elseif (strcmpi(options.tm_method, 'CV_TM_CCORR'))
                    cvtm_options(1) = 2; 
                elseif (strcmpi(options.tm_method, 'CV_TM_CCORR_NORMED'))
                    cvtm_options(1) = 3; 
                elseif (strcmpi(options.tm_method, 'CV_TM_CCOEFF'))
                    cvtm_options(1) = 4; 
                elseif (strcmpi(options.tm_method, 'CV_TM_CCOEFF_NORMED'))
                    cvtm_options(1) = 5; 
                else
                    cvtm_options(1) = 3; 
                end               
                [result] = cvTemplateMatchOptn( inpTmImgs{iP}, theImg, ...
                    [ searchRangeY1 searchRangeY2 searchRangeX1 searchRangeX2],...
                    tmResizing, cvtm_options ); % tmResizing added on 08-Oct-2014
            elseif ( exist('cvTemplateMatch') == 3 )
                [result] = cvTemplateMatch( inpTmImgs{iP}, theImg, ...
                    [ searchRangeY1 searchRangeY2 searchRangeX1 searchRangeX2],...
                    tmResizing );               % tmResizing added on 08-Oct-2014
            else
                fprintf('Error: Cannot find a template match mex file.\n');
                toc; 
                return;
            end
            % check result
            if ( result(3) < 0.8 )
                fprintf('Warning: impro_ginputTm P-%d got low corr: %f.\n',...
                    iP, result(3) );
            end
            % Calculate xy
            xy(iP,1) = result(2) + inpXy(iP,1);
            xy(iP,2) = result(1) + inpXy(iP,2);
            xy(iP,3) = result(3);
        else
            %      xy(iP,1) = xy(iP,1);  % This is exact the position user clicked.
            %      xy(iP,2) = xy(iP,2);  % This is exact the position user clicked.
            xy(iP,3) = 1.0;
            % end of check template matching range is positive or not
        end
        
        % end of if there is template matching image
    end
    
    % Get output template and output reference point
    % Output template range of Y
    outY1 = round(xy(iP,2) -(Tsize-1)/2 );
    outY2 = outY1 + Tsize -1;
    % lower bound check of output template range Y
    if ( outY1 < 1 )
        outY1 = 1;
        outY2 = outY1 +Tsize -1;
    end
    % upper bound check of output template range Y
    if ( outY2 > size(theImg,1) )
        outY2 = size(theImg,1);
        outY1 = outY2 -Tsize +1;
    end
    % Output template range of X
    outX1 = round(xy(iP,1) -(Tsize-1)/2 );
    outX2 = outX1 + Tsize -1;
    % lower bound check of output template range X
    if ( outX1 < 1 )
        outX1 = 1;
        outX2 = outX1 +Tsize -1;
    end
    % upper bound check of output template range X
    if ( outX2 > size(theImg,2) )
        outX2 = size(theImg,2);
        outX1 = outX2 -Tsize +1;
    end
    
    % output template image
    outTmImgs{iP} = theImg(outY1:outY2,outX1:outX2,:);
    
    % output reference point (of template image)
    %    outXy(iP,1) = result(1) +inpXy(iP,1) -(outY1-1);
    %    outXy(iP,2) = result(2) +inpXy(iP,2) -(outX1-1);
    outXy(iP,1) = xy(iP,1) -(outX1-1);
    outXy(iP,2) = xy(iP,2) -(outY1-1);
    
    % end of iP (i-th point) loop
end

% timing
t_ginputTm = toc;
fprintf('  timing: ginputTm costs %6.2f sec.\n', t_ginputTm);
% end of function
end