function varargout = impro_guiRectfCoordTypeSelection(varargin)
% IMPRO_GUIRECTFCOORDTYPESELECTION M-file for impro_guiRectfCoordTypeSelection.fig
%      IMPRO_GUIRECTFCOORDTYPESELECTION, by itself, creates a new IMPRO_GUIRECTFCOORDTYPESELECTION or raises the existing
%      singleton*.
%
%      H = IMPRO_GUIRECTFCOORDTYPESELECTION returns the handle to a new IMPRO_GUIRECTFCOORDTYPESELECTION or the handle to
%      the existing singleton*.
%
%      IMPRO_GUIRECTFCOORDTYPESELECTION('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in IMPRO_GUIRECTFCOORDTYPESELECTION.M with the given input arguments.
%
%      IMPRO_GUIRECTFCOORDTYPESELECTION('Property','Value',...) creates a new IMPRO_GUIRECTFCOORDTYPESELECTION or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before impro_guiRectfCoordTypeSelection_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to impro_guiRectfCoordTypeSelection_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help impro_guiRectfCoordTypeSelection

% Last Modified by GUIDE v2.5 05-Sep-2014 15:13:21

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @impro_guiRectfCoordTypeSelection_OpeningFcn, ...
                   'gui_OutputFcn',  @impro_guiRectfCoordTypeSelection_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before impro_guiRectfCoordTypeSelection is made visible.
function impro_guiRectfCoordTypeSelection_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to impro_guiRectfCoordTypeSelection (see VARARGIN)

% Choose default command line output for impro_guiRectfCoordTypeSelection
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes impro_guiRectfCoordTypeSelection wait for user response (see UIRESUME)
uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = impro_guiRectfCoordTypeSelection_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;
close

% --- Executes on button press in pb_ok.
function pb_ok_Callback(hObject, eventdata, handles)
% hObject    handle to pb_ok (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pb_cancel.
function pb_cancel_Callback(hObject, eventdata, handles)
% hObject    handle to pb_cancel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



% --- Executes during object creation, after setting all properties.
function ed_ctrlpnts_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ed_ctrlpnts (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes when user attempts to close figure1.
function figure1_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if isequal(get(hObject, 'waitstatus'), 'waiting')
     % The GUI is still in UIWAIT, us UIRESUME
     uiresume(hObject);
else
     % The GUI is no longer waiting, just close it
     delete(hObject);
end


% --- Executes on key press with focus on ed_ctrlpnts and none of its controls.
function ed_ctrlpnts_KeyPressFcn(hObject, eventdata, handles)
% hObject    handle to ed_ctrlpnts (see GCBO)
% eventdata  structure with the following fields (see UICONTROL)
%	Key: name of the key that was pressed, in lower case
%	Character: character interpretation of the key(s) that was pressed
%	Modifier: name(s) of the modifier key(s) (i.e., control, shift) pressed
% handles    structure with handles and user data (see GUIDATA)
check_ctrlPnts(hObject, eventdata, handles); 



function check_ctrlPnts(hObject, eventdata, handles)
% Check the textbox content is correct or not.
%   Check 1: Is it a valid MATLAB array?
%   Check 2: Does it contain correct number of control points?
%            Plane requires 3; Cylinder and L-plane require 4. 
%   Check 3: Are control points indices integers? 
% If all of them are valid, enable OK button, else unable it. 

    % 'String' value of edit box only updating after Enter or losing focus
    % update handles.ed_ctrlpnts String (don't know why)
    import java.awt.Robot;
    import java.awt.event.KeyEvent;
    robot=Robot;
    robot.keyPress(KeyEvent.VK_ENTER);
    pause on
    pause(0.01)
    robot.keyRelease(KeyEvent.VK_ENTER);
    pause(0.01)
    pause off

textboxContent = get(handles.ed_ctrlpnts, 'String'); 
set(handles.text2, 'String', textboxContent); 
array = str2num(textboxContent); 
array = array(:);   % convert to 1-d array
nCtrlPntsSelected = size(array,1); 
% Find the correct number of ctrlPoints
nExpectedCtrlPoints = 0; 
if (get(handles.rb_plane, 'Value') == 1) 
    nExpectedCtrlPoints = 3; 
end
if (get(handles.rb_cylinder, 'Value') == 1) 
    nExpectedCtrlPoints = 4; 
end
if (get(handles.rb_lplane, 'Value') == 1) 
    nExpectedCtrlPoints = 4; 
end
% Check nCtrlPntsSelected
if (nExpectedCtrlPoints > 0 && ...
    nExpectedCtrlPoints == nCtrlPntsSelected) 
    set(handles.pb_ok, 'Enable', 'on'); 
else
    set(handles.pb_ok, 'Enable', 'off'); 
end

    
    
    
    
