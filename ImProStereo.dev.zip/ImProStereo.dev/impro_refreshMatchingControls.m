function handles = impro_refreshMatchingControls(hObject, handles)
return
% This function refreshes the Ctrl Points Matching UI Values

% Template size 
strTmpltSize = get(handles.popmenuTmpltSizeLeft, 'String'); 
found = 0; 
for i = 1: size(strTmpltSize, 1)
  if (round(str2num(strTmpltSize{i})) == round(handles.TmpltSize)) 
    set(handles.popmenuTmpltSizeLeft, 'Value', i); 
    set(handles.popmenuTmpltSizeRigt, 'Value', i); 
    found = 1;
    break; 
  end
end
% If handles.TmpltSize is not in the list of handles.popmenuTmpltSizeLeft
% then select the closest one and change the value in the list
if (found == 0) 
    mindist = abs(str2num(strTmpltSize{1}) - handles.TmpltSize);
    minitem = 1;
    for i = 2: size(strTmpltSize, 1)
      dist = abs(str2num(strTmpltSize{i}) - handles.TmpltSize);
      if (dist < mindist) 
          mindist = dist; 
          minitem = i;
      end      
    end
    % change the String 
    strTmpltSize{minitem} = num2str(handles.TmpltSize);
    set(handles.popmenuTmpltSizeLeft, 'String', strTmpltSize);
    set(handles.popmenuTmpltSizeRigt, 'String', strTmpltSize);
    set(handles.popmenuTmpltSizeLeft, 'Value', minitem); 
    set(handles.popmenuTmpltSizeRigt, 'Value', minitem);   
    fprintf('Warning: Loaded template size is not in the list.\n');    
end

% No. of Ctrl Points 
strNoCtrlPoints = get(handles.popmenuNPointLeft, 'String'); 
found = 0; 
for i = 1: size(strNoCtrlPoints, 1)
  if (round(str2num(strNoCtrlPoints{i})) == round(handles.nPoint)) 
    set(handles.popmenuNPointLeft, 'Value', i); 
    set(handles.popmenuNPointRigt, 'Value', i); 
    found = 1;
    break; 
  end
end
% If handles.nPoint is not in the list of handles.popmenuNPointLeft
% then select the closest one and change the value in the list
if (found == 0) 
    mindist = abs(str2num(strNoCtrlPoints{1}) - handles.nPoint);
    minitem = 1;
    for i = 2: size(strNoCtrlPoints, 1)
      dist = abs(str2num(strNoCtrlPoints{i}) - handles.nPoint);
      if (dist < mindist) 
          mindist = dist; 
          minitem = i;
      end      
    end
    % change the String 
    strNoCtrlPoints{minitem} = num2str(handles.nPoint);
    set(handles.popmenuNPointLeft, 'String', strNoCtrlPoints);
    set(handles.popmenuNPointRigt, 'String', strNoCtrlPoints);
    set(handles.popmenuNPointLeft, 'Value', minitem); 
    set(handles.popmenuNPointRigt, 'Value', minitem);   
    fprintf('Warning: Loaded No. of Ctrl Points is not in the list.\n');    
end


end





