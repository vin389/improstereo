function handles = impro_CtrlPointsTriangulation( hObject, handles )
% This function runs stereo triangulation of all control points
% Modified by vince (2015-05-14)
%    Allows that only partial ctrl points have been tracked. 
%      Original: handles.nPair (at many places in the code)
%                handles.nPoint (at many places in the code)  
%      Modified: nPair_CtrlPoints = size(handles.CtrlPoints, 1);
%                nPoint_CtrlPoints = size(handles.CtrlPoints, 3); 
%                nPair_CtrlPoints (at many places in the code)
%                nPoint_CtrlPoints (at many places in the code)
% 

% Check
if ( isfield( handles, 'calib3d') == 0 )
  msgbox('Load 3D Calib Data first.','Warning');
  return;
end

% Control points triangulation
% Reshape CtrlPoints from 4-D array to 2-D array (FORTRAN based ordering)
nPair_CtrlPoints = size(handles.CtrlPoints, 1);
nPoint_CtrlPoints = size(handles.CtrlPoints, 3); 
xL = handles.CtrlPoints(:, 1, :, :);
xR = handles.CtrlPoints(:, 2, :, :);
xL = reshape(xL, [ nPair_CtrlPoints * nPoint_CtrlPoints 2] );
xR = reshape(xR, [ nPair_CtrlPoints * nPoint_CtrlPoints 2] );
xL = xL';
xR = xR';

[XL,XR,err]  = stereo_triangulation_err( xL, xR, ...
  handles.calib3d.om,       handles.calib3d.T, ...
  handles.calib3d.fc_left,  handles.calib3d.cc_left, ...
  handles.calib3d.kc_left,  handles.calib3d.alpha_c_left, ...
  handles.calib3d.fc_right, handles.calib3d.cc_right, ...
  handles.calib3d.kc_right, handles.calib3d.alpha_c_right );
% Reshape data to fit CtrlPoints3D
XL = XL';
XR = XR';
handles.CtrlPoints3D(1:nPair_CtrlPoints, 1, 1:nPoint_CtrlPoints, 1:3) = ...
  reshape( XL, [ nPair_CtrlPoints nPoint_CtrlPoints 3 ] );
handles.CtrlPoints3D(1:nPair_CtrlPoints, 2, 1:nPoint_CtrlPoints, 1:3) = ...
  reshape( XR, [ nPair_CtrlPoints nPoint_CtrlPoints 3 ] );
handles.CtrlPoints3Derr(1:nPair_CtrlPoints, 1:nPoint_CtrlPoints) = ...
  reshape( err, [ nPair_CtrlPoints nPoint_CtrlPoints ] );
handles.measurementErr.StereoErr = handles.CtrlPoints3Derr; 

fprintf('Control points triangulation completed.\n');
end