function handles = impro_CamMovCorrect(hObject, handles)

% Ask user to input range of movement correction
options.Resize='on'; 
inpans = inputdlg( {'Range of Pair'   ...
                    'Range of iLR'    ...
                    'Fixed Points'  ...
                    'Reference Pair' ...
                    'File prefix' }, ...
        'CamMov Correction', 1, ...
                   { ['1:'  num2str(handles.nPair) ] ...
                     ['1:'  num2str(handles.nLR)   ] ...
                     ['1:'  num2str(handles.nPoint)] ...
                      '1' ...
                      'Unmv_' }, ...
        options);
if ( size(inpans,1) < 1 )
  return
end

iPairRange  = str2num(inpans{1});
iLRRange    = str2num(inpans{2});
iFixedRange = str2num(inpans{3});
RefPair     = str2num(inpans{4});
filePrefix  = inpans{5};

% create a waitbar
hWaitBar = waitbar(0, 'Creating movement corrected photos...' );

% create handles.camMove if it does not exist
if ( ~isfield(handles, 'camMove') )
    handles.camMove = zeros(handles.nPair, handles.nLR, 4);
end

% Get fixed points of reference pair
nFixedPoints = size(iFixedRange(:), 1 );
if ( nFixedPoints < 2 ) 
    msgbox('# of fixed points must be >= 2.');
    return;
end

% Start the loop 
for iPair = iPairRange
%  set(handles.slPair, 'Value', iPair);
%  handles.iPair = iPair;
%  handles = impro_updSlPair(hObject,handles);
  for iLR = iLRRange
%    set(handles.slLR, 'Value', iLR);
%    handles.iLR = iLR;
%    handles = impro_updSlLR(hObject,handles);
%    refresh;
    
    if ( ~isfield(handles, 'CtrlPoints') )
        msgbox('Define Ctrl points first.');
        return;
    end
    if ( RefPair > size(handles.CtrlPoints,1) ) 
        msgbox('Invalid reference pair.');
        return;
    end
    x0(1:nFixedPoints, 1:2) = ... 
        handles.CtrlPoints(RefPair, iLR, iFixedRange, 1:2);
    
    % Get fixed points of this pair
    xm(1:nFixedPoints, 1:2) = ... 
        handles.CtrlPoints(iPair, iLR, iFixedRange, 1:2);
    
    % Get intrinsic parameters
    if (iLR == 1) 
        f = handles.calib3d.fc_left;
        c = handles.calib3d.cc_left;
        k = handles.calib3d.kc_left;
        alpha = handles.calib3d.alpha_c_left;
    else
        f = handles.calib3d.fc_right;
        c = handles.calib3d.cc_right;
        k = handles.calib3d.kc_right;
        alpha = handles.calib3d.alpha_c_right;
    end    
    
    % Calculate movement 
    if (iPair == RefPair) 
        camMove = [ 0; 0; 0; 0]; 
        err = 0; 
    else
        [camMove, err] = impro_findCamMovBy3DProj(x0,xm,f,c,k,alpha); 
    end    
    handles.camMove(iPair, iLR, 1:4) = camMove(:);
    
    % create corrected photo
    pathname = handles.PhotoPath{iLR};
    filename = handles.filelistPhoto{iPair,iLR};
    if (iPair == RefPair) 
        copyfile([pathname filename], [pathname filePrefix filename], 'f');
    else
        impro_createUnmovedPhotoBy3DProj( ...
            [pathname filename], ...
            [pathname filePrefix filename], ...
            (-1) * camMove, f, c, k, alpha); 
    end    
  % end of iLR loop
  end
  waitbar((iPair-iPairRange(1)+1) / size(iPairRange(:),1), hWaitBar );
% end of iPair loop 
end
close(hWaitBar);


guidata(hObject, handles);

end
