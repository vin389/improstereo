function markers_xyz = impro_readObjectPointsFromExcel(fpathname)
markers_xyz = [];
% User selects Excel from uigetfile
[filename, pathname] = uigetfile( {'*.xlsx';'*.xls'}, 'Pick Excel file of markers coordinates');
if (exist([pathname filename], 'file') ~= 2)
    return;
end
% Read markers coordinates (to markers_xyz(1:nMarker, 1:3)) 
% Marker ID ordering can be arbitrary 
[markersxls,txt,raw]=xlsread([pathname filename]); 
nMarkerxls = size(markersxls, 1);
nMarker = max(markersxls(:,1));
markers_xyz = zeros(nMarker, 3); 
for i = 1: nMarkerxls
    markers_xyz(markersxls(i, 1), 1:3) = markersxls(i, 2:4); 
end


