% This function is similar to impro_copyTmplt2Tmplt but allows 
% the user to specify the source (srcPair) and the destination (dstPair) 
% templates.
% (The impro_copyTmplt2Tmplt copies from Pair to Pair+1).
function handles = impro_copyFromTmpltToTmplt(hObject, handles, ...
                   srcPair, dstPair, ...
                   iLR, iPoint)
% Copy the this source template data to destination template
if (srcPair <= handles.nPair && dstPair <= handles.nPair )
  % Load data to handles.iTmplt{iLR} and and iTmpltImg{iLR,iPoint}
  [handles,iTmpltImg] = impro_loadTmplt(hObject, handles, srcPair, iLR, iPoint); 
  % Save data to template of next pair 
  handles = impro_saveTmplt(hObject, handles, dstPair, iLR, iPoint, ...
            iTmpltImg, ...
            handles.iTmplt{iLR}.pckXy{iPoint}, ...
            handles.iTmplt{iLR}.refXy{iPoint} ); 
  % print a message to the console
  fprintf('Copy Tmplt(Pr:%d/LR:%d/CPnt:%d)->Tmplt(%d)\n', ...
          srcPair,iLR,iPoint, dstPair );
end
end
