function deg = impro_crack_deg(ux33, uy33)
    degs = [0 45 90 135]; 
    psgn{1} = [1 1 1; 0 0 0; -1 -1 -1];
    psgn{2} = [1 1 0; 1 0 -1; 0 -1 -1];
    psgn{3} = [1 0 -1;1 0 -1;1 0 -1];
    psgn{4} = [0 -1 -1; 1 0 -1;1 1 0];
    ssum = zeros(1, 4);
    for i = 1:4
        mdotx = abs(ux33(:) .* psgn{i}(:));
        mdoty = abs(uy33(:) .* psgn{i}(:));
        ssum(i) = sum(mdotx) + sum(mdoty);
    end
    [smax, idmax] = max(ssum); 
    deg = degs(idmax); 
end

    
    