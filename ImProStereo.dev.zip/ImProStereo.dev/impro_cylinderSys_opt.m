function [vx,vy,vz,ori,R,th1,th2,h1,h2] = impro_cylinderSys_opt( CtrlPoint3D )
%
% Calculate the best (reasonable) cylinder system by a few control points.
%   INPUT:
%     CtrlPoint3D - Control points 
%                   Dimension (1:nPoint,1:3)
%                   P1                     P3
%                    |\                   /
%                    | \------- P2 ------/
%                    |
%                    |
%                   P4                    (P6)
%                     \                   /
%                      \-------(P5)------/
%                 
%                   P1 to P4 are required. P5 and more are optional.
% 
%   Output: 
%     vx/vy/vz - The basic normalized axes of the coordinate system.
%                Dimension (1:3,1)
%     ori      - The origin of the coordinate system.
%                Dimension (1:3,1)
%     R        - The radius of the cylinder.
%                Dimension (1,1)
%     th1/th2  - The theta range in the cylinder range.
%                th1 is typically 0. 
%                Dimension (1,1)
%     h1/h2    - The height range in the cylinder range
%                h1 is typically 0.
%                Dimension (1,1)
%     Note:
%       For parallelVx==1 or 3:
%        P1 is exactly at th=th1 and h=h2
%        P2 is close to th=something and h=h2
%        P3 is exactly at th = th2
%        P4 is close to th=th1 and h = h1
%       Else
%        P1 is exactly at th=th1 and h=h2
%        P2 is close to th=something and h=h2
%        P3 is close to th = th2
%        P4 is exactly at th=th1 and h = h1
%       For parallelVx == 3, the above is used as initial guess for optim.
%   
%   Date:
%      Created by Vincent on Apr 11 2011
%      Modified by Vincent on Oct 23 2013
%        1. Adding optimization 
%      Modified by Vincent on May 2  2014
%        1. Bug fix 
%             original: if (parallelVx == 1 && parallelVx == 3)
%             modified: if (parallelVx == 1 || parallelVx == 3)
%

parallelVx = 3;
if (parallelVx == 1 || parallelVx == 3)
  % vz (z axis) is preliminary defined as the direction of P1-P4
  % and is corrected by P3-P1. 
  % This ensures that the horizontal axis rectified image is parallel to 
  % P3-P1. 
  vxp  = CtrlPoint3D(3,:)' - CtrlPoint3D(1,:)';
  vxp  = vxp/norm(vxp);
  vzp  = CtrlPoint3D(1,:)' - CtrlPoint3D(4,:)';
  h2   = norm(vzp);
  vyp  = cross(vzp,vxp);
  vyp  = vyp/norm(vyp);
  vz   = cross(vxp,vyp);
else
  vz    = CtrlPoint3D(1,:)' - CtrlPoint3D(4,:)';
  h2    = norm(vz);
  vz    = vz/h2;
end
  

vx12  = CtrlPoint3D(2,:)' - CtrlPoint3D(1,:)';
vx12  = vx12/norm(vx12);
vy12  = cross(vz,vx12);
vy12  = vy12/norm(vy12);
vx12p = cross(vy12,vz);
vx12p = vx12p/norm(vx12p);
vx13  = CtrlPoint3D(3,:)' - CtrlPoint3D(1,:)';
vx13  = vx13/norm(vx13);
vy13  = cross(vz,vx13);
vy13  = vy13/norm(vy13);
vx13p = cross(vy13,vz);
vx13p = vx13p/norm(vx13p);
x2p   = CtrlPoint3D(1,:)' + ...
        dot((CtrlPoint3D(2,:) - CtrlPoint3D(1,:)),vx12p) * vx12p ; 
x3p   = CtrlPoint3D(1,:)' + ...
        dot((CtrlPoint3D(3,:) - CtrlPoint3D(1,:)),vx13p) * vx13p ; 

x12m  = (CtrlPoint3D(1,:)'+x2p)/2; 
x13m  = (CtrlPoint3D(1,:)'+x3p)/2; 

matA = [vy12 -vy13]; % [matA] * {a1;a2} = {vecB}. 
vecB = x13m - x12m;  % size(matA)=[3 2]. size(vecB)=[3 1];

AA     = matA'*matA; BB = matA'*vecB;
af     = inv(AA)*BB; 
ori2   = 0.5*(x12m+af(1)*vy12) + 0.5*(x13m+af(2)*vy13) ; 

vx     = CtrlPoint3D(1,:)' - ori2; 
R      = norm(vx);
vx     = vx/R; 
vy     = cross(vz,vx);
vy     = vy/norm(vy);

th1    = 0; 
th2    = acos(dot(vx,(x3p-ori2)/norm(x3p-ori2)));

h1     = 0;

ori    = ori2 - h2*vz;

% The above parameters are used as initial guess for further optimization
% assuming h1 = 0. th1 = 0.
%   initial guess
if ( parallelVx == 3 )
    rot33 = zeros([3 3]);
    rot33(1:3,1) = vx;
    rot33(1:3,2) = vy;
    rot33(1:3,3) = vz;
    vrot3 = rodrigues(rot33);
    initArg = zeros([1 5]);
    initArg(1:3) = vrot3(1:3);
    initArg(4) = R; 
    initArg(5) = h2; 
    %   optimization
    optArg = fminsearch( @(x) cylinderObjFunc(x, CtrlPoint3D), initArg );
    %   get final result
    vrot3(1:3)  = optArg(1:3);
    R           = optArg(4);
    h2          = optArg(5);
    rot33 = rodrigues(vrot3);
    vx = rot33(1:3, 1); 
    vy = rot33(1:3, 2);
    vz = rot33(1:3, 3);
    ori = CtrlPoint3D(1,:)' - R * vx - h2 * vz; 
    n3  = (CtrlPoint3D(3,:)' - ori) - dot(CtrlPoint3D(3,:)' - ori, vz) * vz; 
    n3  = n3 / norm(n3); 
    th2 = acos( dot(n3,vx) );
end

    function obj = cylinderObjFunc(searchArg, fixedArg)
        % Get parameters
        vrot3       = zeros([1 3]);        
        vrot3(1:3)  = searchArg(1:3);
        r           = searchArg(4);
        h2          = searchArg(5);
        CtrlPoint3D = fixedArg; 
        % Get number of ctrl points
        np = size(CtrlPoint3D, 1);
        % Get vx, vy and vz (the cylinder coord. sys) 
        rot33 = rodrigues(vrot3);
        vx = rot33(1:3, 1); 
        vy = rot33(1:3, 2);
        vz = rot33(1:3, 3);
        % Get Ori (Ori = P1 - r * vx - h * vz)
        % (the origin of the cylinder coord.)
        Ori = CtrlPoint3D(1,:)' - r * vx - h2 * vz; 
        % Calculate obj func (err)
        obj = 0;
        % obj += (r(Pi) - r) ^ 2, for each control point i 
        for i = 1: np
            % h(Pi) = (Pi - Ori) .dot. vz
            % c(Pi) = || (Pi - Ori) ||
            hPi = dot( (CtrlPoint3D(i,:)' - Ori), vz );
            cPi = norm(CtrlPoint3D(i,:)' - Ori); 
            rPi = sqrt(cPi ^2 - hPi ^2);
            % obj += (rPi - r) ^2
            obj = obj + (rPi - r) ^2; 
        end
        % obj += (hP4 - h) ^2
        hP4 = dot( (CtrlPoint3D(4,:)' - Ori), vz );
        obj = obj + hP4 ^2;         
    end
    
end

