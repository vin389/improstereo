function handles = impro_fieldAnalysis_Cylinder(hObject, handles)

% Estimate paremeters M and N (# of cells) according to size of 
% measurement region of Pair 1 Left. 

measureWidth  = handles.rectfMeasureRange(1, 1, 2) - ...
                handles.rectfMeasureRange(1, 1, 1) + 1; 
measureHeight = handles.rectfMeasureRange(1, 1, 4) - ...
                handles.rectfMeasureRange(1, 1, 3) + 1; 
MN = 1500;  % Make estimated M*N is about MN (say 1000, M=25 and N=40)
              
estM = round( measureHeight*sqrt(MN/(measureWidth*measureHeight)) );
estN = round( measureWidth *sqrt(MN/(measureWidth*measureHeight)) );

% Ask user to input range of field analysis
inpans = inputdlg( ...
  { ...
    'Range of Pair'   ...
    'Range of iLR'    ...
    'M (# of cells along Y)'  ...
    'N (# of cells along X)'  ...
    'Patch field (1:Ux. 2:Uy. 3:exx. 4:eyy. 5:exy. 6:crack_opening_45. 7:crack_sliding_45. 8:crack_opening_135. 9:crack_sliding_135. 10:crack_opening_general. 11.crack_sliding_general)' ...
    'Patch caxis [min max]' ...
  }, ...
  'Range of plane field analysis', 1, ...
  { ...
    ['2:'  num2str(handles.nPair) ] ...
    ['1:'  num2str(handles.nLR)   ] ...
    num2str(estM) ...
    num2str(estN) ...
    ' [1 2 3 4 ]' ...
    'auto' ... 
  } );

% If user press CANCEL, this function returns. 
if ( size(inpans,1) < 1 )
  return
end

% Get inputs. 
iPairRange  = str2num(inpans{1});
iLRRange    = str2num(inpans{2});
M           = str2num(inpans{3});
N           = str2num(inpans{4});
patchOptions.field = str2num(inpans{5});
patchOptions.caxis = inpans{6}; 

% Process input 6 (caxis) (added by vince 2013/10/14)
patchOptionsCaxis = str2num( patchOptions.caxis );
if (size(patchOptionsCaxis,1) * size(patchOptionsCaxis,2) == 2) 
    patchOptions.caxis = [patchOptionsCaxis(1) patchOptionsCaxis(2)];
else
    patchOptions.caxis = [];
end    

% Loop for iLR
for iLR = iLRRange
  % Load rectified image of Pair 1 from file and save to variable iRectfImg
  iPair = 1;
  [handles, imgInitial] = impro_loadRectf(hObject, handles, iPair, iLR);
  
  % Loop for iPair
  for iPair = iPairRange
    
    [handles, imgDeformd] = impro_loadRectf(hObject, handles, iPair, iLR);
    initPair = 1;
    rangeTracing(1:4) = handles.rectfMeasureRange( initPair, iLR, 1:4 );
    options.M     = M;
    options.N     = N;
    options.Mu    = M;
    options.Nu    = N;    
    options.ZmFct = 50;
    % plane disp/strain analysis
    if (get(handles.rd_opticalflow, 'value') == 0) 
        [uxGrid,uyGrid,strain2Dxx,strain2Dyy,strain2Dxy,xGrid,yGrid, infoTM ] = ...
          impro_planeStrain20(imgInitial, imgDeformd, rangeTracing, options);
    else
        % Pyramid LK method
        tic;
        [uxGrid,uyGrid,strain2Dxx,strain2Dyy,strain2Dxy,xGrid,yGrid, infoTM ] = ...
          impro_planeStrainLK(imgInitial, imgDeformd, rangeTracing, options);
        optFlowLkTime = toc;   % cpu timing added by vince (2013/10/15)
        fprintf('Optical flow analysis time: %f sec.\n', optFlowLkTime);
    end
    
    % Normally in 3D the Y is upward, so the strain2Dxy will be inverted.
    uxGrid = uxGrid * handles.rpxRectf ;
    uyGrid = uyGrid * (-handles.rpxRectf) ;

    % Filter low acc. (high error) cells.
%    accFilter = 0.97; 
    uxGridPlot = uxGrid; 
    uyGridPlot = uyGrid; 
    strain2DxxPlot = strain2Dxx ;
    strain2DyyPlot = strain2Dyy ;
    strain2DxyPlot = strain2Dxy ;   
    
    % filter values that are out of user-defined range (1/4/2014 by vince) 
    filterMin = str2num(get(handles.edVisibleMatchRangeMin, 'String'));
    filterMax = str2num(get(handles.edVisibleMatchRangeMax, 'String'));
    uxGridPlot(or(infoTM.Acc < filterMin, infoTM.Acc > filterMax)) = nan; 
    uyGridPlot(or(infoTM.Acc < filterMin, infoTM.Acc > filterMax)) = nan; 
    strain2DxxPlot(or(infoTM.Acc < filterMin, infoTM.Acc > filterMax)) = nan; 
    strain2DyyPlot(or(infoTM.Acc < filterMin, infoTM.Acc > filterMax)) = nan; 
    strain2DxyPlot(or(infoTM.Acc < filterMin, infoTM.Acc > filterMax)) = nan;
%    uxGridPlot(or(uxGrid < patchOptions.caxis(1), uxGrid > patchOptions.caxis(2) )) = nan; 
%    uyGridPlot(or(uyGrid < patchOptions.caxis(1), uyGrid > patchOptions.caxis(2) )) = nan; 
%    strain2DxxPlot(or(strain2Dxx < patchOptions.caxis(1), strain2Dxx > patchOptions.caxis(2))) = nan; 
%    strain2DyyPlot(or(strain2Dyy < patchOptions.caxis(1), strain2Dyy > patchOptions.caxis(2))) = nan; 
%    strain2DxyPlot(or(strain2Dxy < patchOptions.caxis(1), strain2Dxy > patchOptions.caxis(2))) = nan;         
    
%    uxGridPlot( infoTM.Acc < accFilter ) = nan; 
%    uyGridPlot( infoTM.Acc < accFilter ) = nan; 
%    strain2DxxPlot( infoTM.Acc < accFilter ) = nan; 
%    strain2DyyPlot( infoTM.Acc < accFilter ) = nan; 
%    strain2DxyPlot( infoTM.Acc < accFilter ) = nan;     
    
    % output the analyzed patch on photo
    if (get(handles.ck_ShowProjectedSurfaceMesh, 'Value') == 1) 
        impro_3dMeshStrain_Cylinder( hObject, handles, iPair, iLR, ...
                        uxGrid, uyGrid, strain2Dxx, strain2Dyy, ...
                        strain2Dxy, ...
                        xGrid, yGrid, ...
                        infoTM, patchOptions );  % add patchOptions as a parameter (by vince 2013/10/14)
    end              
    % Plot results to new figures    
    % filter values that are out of user-defined range (1/4/2014 by vince) 
    pFieldFilter(or(infoTM.Acc < filterMin, infoTM.Acc > filterMax)) = nan; 
%    pFieldFilter( infoTM.Acc < 0.97 ) = nan; 

    impro_MeshStrainPlots_General( hObject, handles, iPair, iLR, ...
                        uxGridPlot, uyGridPlot, ... 
                        strain2DxxPlot, strain2DyyPlot, strain2DxyPlot, ...
                        xGrid, yGrid, ...
                        infoTM, patchOptions );
    % end of iPair loop
  end
  
  % end of iLR loop
end

end




% function handles = impro_fieldAnalysis_Cylinder(hObject, handles)
% 
% % Estimate paremeters M and N (# of cells) according to size of 
% % measurement region of Pair 1 Left. 
% 
% measureWidth  = handles.rectfMeasureRange(1, 1, 2) - ...
%                 handles.rectfMeasureRange(1, 1, 1) + 1; 
% measureHeight = handles.rectfMeasureRange(1, 1, 4) - ...
%                 handles.rectfMeasureRange(1, 1, 3) + 1; 
% MN = 1500;  % Make estimated M*N is about MN (say 1000, M=25 and N=40)
%               
% estM = round( measureHeight*sqrt(MN/(measureWidth*measureHeight)) );
% estN = round( measureWidth *sqrt(MN/(measureWidth*measureHeight)) );
% 
% % Ask user to input range of field analysis
% inpans = inputdlg( {'Range of Pair'   ...
%   'Range of iLR'    ...
%   'M (# of cells along Y)', ...
%   'N (# of cells along X)', ...
%   'TM zoom factor' }, ...
%   'Range of field analysis', 1, ...
%   { ['2:'  num2str(handles.nPair) ] ...
%   ['1:'  num2str(handles.nLR)   ] ...
%   num2str(estM) num2str(estN) '20' } );
% 
% % If user press CANCEL, this function returns. 
% if ( size(inpans,1) < 1 )
%   return
% end
% 
% % Get inputs. 
% iPairRange  = str2num(inpans{1});
% iLRRange    = str2num(inpans{2});
% M           = str2num(inpans{3});
% N           = str2num(inpans{4});
% 
% % Loop for iLR
% for iLR = iLRRange
%   % Load rectified image of Pair 1 from file and save to variable iRectfImg
%   iPair = 1;
%   [handles, imgInitial] = impro_loadRectf(hObject, handles, iPair, iLR);
%   
%   % Loop for iPair
%   for iPair = iPairRange
%     
%     [handles, imgDeformd] = impro_loadRectf(hObject, handles, iPair, iLR);
%     initPair = 1;
%     rangeTracing(1:4) = handles.rectfMeasureRange( initPair, iLR, 1:4 );
%     options.M     = M;
%     options.N     = N;
%     
%     % plane disp/strain analysis
% %    [uxGrid,uyGrid,strain2Dxx,strain2Dyy,strain2Dxy,xGrid,yGrid, infoTM ] = ...
% %      impro_planeStrain20(imgInitial, imgDeformd, rangeTracing, options);
%     [uxGrid,uyGrid,strain2Dxx,strain2Dyy,strain2Dxy,xGrid,yGrid, infoTM ] = ...
%       impro_planeStrainLK(imgInitial, imgDeformd, rangeTracing, options);
%     
%     % Normally in 3D the Y is upward, so the strain2Dxy will be inverted.
%     uxGrid = uxGrid * handles.rpxRectf ;
%     uyGrid = uyGrid * (-handles.rpxRectf) ;
%        
%     % output the analysis result
%     impro_3dMeshStrain_Cylinder( hObject, handles, iPair, iLR, ...
%                         uxGrid, uyGrid, strain2Dxx, strain2Dyy, ...
%                         strain2Dxy, ...
%                         xGrid, yGrid, ...
%                         infoTM );
%     
%     % end of iPair loop
%   end
%   
%   % end of iLR loop
% end
% 
% 
% 
% 
% 
% end
