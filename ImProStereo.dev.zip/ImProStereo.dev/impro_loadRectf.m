function [handles,iRectfImg] = ...
         impro_loadRectf(hObject, handles, iPair, iLR)
% This function loads rectified image and data from file and show image
% To save memory, rectified images are not stored in handles memory.

% Rectified image
%   Define handles.iRectf{iLR}
if ( exist([handles.RectfPath{iLR} handles.filelistRectf{iPair,iLR}],'file') )
   % Load the rectified data (which is a .mat file)
   iRectf = load([handles.RectfPath{iLR} handles.filelistRectf{iPair,iLR}]);
   % handles.iRectf = iRectf.iRectf;
   handles.iRectf{iLR} = iRectf.iRectf; % Modified by vince. 2013/4/23
   if (isfield(handles.iRectf{iLR}, 'file') == 0 && ...  % 2014/5/19
       isfield(handles.iRectf{iLR}{iLR}, 'file') == 1) 
       handles.iRectf{iLR} = handles.iRectf{iLR}{iLR}; 
   end
   % Load the rectified image 
   iRectfImg = imread( [handles.RectfPath{iLR} handles.iRectf{iLR}.file] );   
   % For performance issue, we avoid usage of axes() without output. 
   % (according to MATLAB suggestion).
   % (--vince, 06/18/2012)
   % axes(handles.axRectf{iLR});
   cla(handles.axRectf{iLR}); % If we do not clear axes first, the image
                              % object is added and the original image 
                              % is not cleared. Memory usage expands.
   xlim(handles.axRectf{iLR}, [1 size(iRectfImg,2)]);
   ylim(handles.axRectf{iLR}, [1 size(iRectfImg,1)]);
%   image(iRectfImg); 
   image(iRectfImg, 'Parent', handles.axRectf{iLR});
   axis image; 
    % disable label
   axes(handles.axRectfLeft);
   set(gca,'XTickLabel',[]); 
   set(gca,'YTickLabel',[]); 
   axes(handles.axRectfRigt);
   set(gca,'XTickLabel',[]); 
   set(gca,'YTickLabel',[]);  
   fprintf('Rectified image Pair:%d/LR:%d loaded.\n', iPair, iLR );
else
   cla(handles.axRectf{iLR});
   fprintf('Rectified image Pair:%d/LR:%d is not loaded.\n', iPair, iLR );
   iRectf = [];
   handles.iRectf = [];
end

end