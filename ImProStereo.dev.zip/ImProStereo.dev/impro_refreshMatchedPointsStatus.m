function handles = impro_refreshMatchedPointsStatus(hObject, handles)
return
% This function refreshes the matched points status indicator
% check if matched control points are defined or not. Show C/i/.
%   C:Complete   - has sufficient matched files, pckXy, refXy, and 
%                  template size is the same as system setting
%   i:Incomplete - has insufficient matched files, pckXy, refXy, or
%                  template size is not the same as system setting
%   .:Not available - no data
matchedStringArray{handles.nPair + 1} = {}; % pre-locate the cell array
matchedStringArray{1} = 'Matched Points Status';
for iPair = 1: handles.nPair
  matchedStringArray{iPair + 1} = strcat(sprintf('Pair%03d:', iPair), ...
                               repmat('.', 1, handles.nPoint), ...
                          '_', repmat('.', 1, handles.nPoint) );
end
set(handles.popmenuMatchedPointsStatus, 'String', matchedStringArray);

for iPair = 1: handles.nPair
  for iLR = 1: handles.nLR  
    checkFileExist = 0;
    % Check the template data file
    if ( exist([handles.MatchPath{iLR} handles.filelistMatch{iPair,iLR}], 'file') )
      iTmplt = load([handles.MatchPath{iLR} handles.filelistMatch{iPair,iLR}]);
      % the file exists             
      checkFileExist = 1;
      % check template size for each iPoint
      for iPoint = 1: min(iTmplt.iMatch.nPoint, handles.nPoint) 
        % 
        checkMatchSize = 0;
        iMatchImg = imread([handles.MatchPath{iLR} handles.iMatch{iLR}.file{iPoint}]);
        if (size(iMatchImg,1) == handles.TmpltSize) 
          checkMatchSize = 1;
        end  % end of if matched size checking
        if (checkFileExist > 0) 
            strIndex = 8 + (iLR - 1) * (handles.nPoint + 1) + iPoint; 
            if (checkMatchSize > 0) 
                matchedStringArray{iPair + 1}(strIndex) = 'C';            
            else
                matchedStringArray{iPair + 1}(strIndex) = 'i';
            end
        end  % end of if incomplete
      end  % end of for iPoint = 1: min(iTmplt.iMatch.nPoint, handles.nPoint) 
    end  % end of if exist([handles.MatchPath{iLR} handles.filelistMatch{iPair,iLR}]
  end  % end of for iLR = 1: handles.nLR  
end  % end of for iPair = 1: handles.nPair 

set(handles.popmenuMatchedPointsStatus, 'String', matchedStringArray);
end





