function [vtx faces] = impro_planeFace(vx,vy,vz,ori,x1,x2,y1,y2, m, n)
% This function generates vertices and faces of the plnae surface. 

vtx   = zeros( (m+1)*(n+1), 3 );
faces = zeros(  m   * n   , 4 ); 

% Generate vertices coordinates.
ivtx = 0; 
for im = 1: m+1
  yy = y1 + (y2-y1)/m * (im-1); 
  for in = 1: n+1
    ivtx = ivtx+1; 
    xx = x1 + (x2-x1)/n * (in-1); 
    vtx(ivtx,1:3) = ori + xx*vx + yy*vy;
  end
end

% Generate faces connectivity
iface = 0; 
for im = 1: m
  for in = 1: n
    iface = iface + 1;
    faces(iface, 1) = (im-1)*(n+1) + in ; 
    faces(iface, 2) = (im-1)*(n+1) + in+1; 
    faces(iface, 3) = (im-0)*(n+1) + in+1 ; 
    faces(iface, 4) = (im-0)*(n+1) + in ;     
  end
end

end