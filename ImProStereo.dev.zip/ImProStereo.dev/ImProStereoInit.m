function handles = ImProStereoInit(hObject, handles )
% Initialization 

handles.nPair  = 0; 
handles.nLR    = 0; 
handles.nPoint = 0; 

% Misc initialization 
 % ui component variables
handles.axPhoto = { handles.axPhotoLeft, handles.axPhotoRigt };
handles.axTmplt = { handles.axTmpltLeft, handles.axTmpltRigt };
handles.axMatch = { handles.axMatchLeft, handles.axMatchRigt };
handles.axRectf = { handles.axRectfLeft, handles.axRectfRigt };
handles.txCorr  = { handles.txCorrLeft,  handles.txCorrRigt  };

% initialize handles.matchMethod by UI
handles.matchMethod = get(handles.popmenuMatchMethodLeft, 'Value'); 
set(handles.popmenuMatchMethodRigt, 'Value', handles.matchMethod); 

% initialize handles.TmpltSize by UI
theTmpltSizeOption = get(handles.popmenuTmpltSizeLeft, 'Value'); 
set(handles.popmenuTmpltSizeRigt, 'Value', theTmpltSizeOption); 
strArray = get(handles.popmenuTmpltSizeLeft, 'String');
handles.TmpltSize = str2num(strArray{theTmpltSizeOption});

% initialize handles.nPoint by UI
theNPointOption = get(handles.popmenuNPointLeft, 'Value'); 
set(handles.popmenuNPointRigt, 'Value', theNPointOption); 
strArray = get(handles.popmenuNPointLeft, 'String');
handles.nPoint = str2num(strArray{theNPointOption});

% initialize handles.searchRangeX/Y by UI
searchRangeXOption = get(handles.popmenuTmSearchRangeXLeft, 'Value'); 
set(handles.popmenuTmSearchRangeXRigt, 'Value', searchRangeXOption); 
strArray = get(handles.popmenuTmSearchRangeXLeft, 'String');
handles.searchRangeX = str2num(strArray{searchRangeXOption});
searchRangeYOption = get(handles.popmenuTmSearchRangeYLeft, 'Value'); 
set(handles.popmenuTmSearchRangeYRigt, 'Value', searchRangeYOption); 
strArray = get(handles.popmenuTmSearchRangeYLeft, 'String');
handles.searchRangeY = str2num(strArray{searchRangeYOption});

% initialize handles.matchingPrecision by UI
theTmPrecisionOption = get(handles.popmenuTmPrecisionLeft, 'Value'); 
% set(handles.popmenuTmPrecisionRigt, 'Value', theTmPrecisionOption); 
strArray = get(handles.popmenuTmPrecisionLeft, 'String');
handles.tmPrecision = str2num(strArray{theTmPrecisionOption});

 % disable sub-images' labels
 axes(handles.axTmpltLeft);
 set(gca,'XTickLabel',[]); 
 set(gca,'YTickLabel',[]); 
 axes(handles.axMatchLeft);
 set(gca,'XTickLabel',[]); 
 set(gca,'YTickLabel',[]); 
 axes(handles.axRectfLeft);
 set(gca,'XTickLabel',[]); 
 set(gca,'YTickLabel',[]); 
 axes(handles.axTmpltRigt);
 set(gca,'XTickLabel',[]); 
 set(gca,'YTickLabel',[]); 
 axes(handles.axMatchRigt);
 set(gca,'XTickLabel',[]); 
 set(gca,'YTickLabel',[]); 
 axes(handles.axRectfRigt);
 set(gca,'XTickLabel',[]); 
 set(gca,'YTickLabel',[]); 

 guidata(hObject, handles);
end
