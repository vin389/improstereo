%
% imgResized = impro_resize( imgOri, fact ) 
%              resizes an image using interp2 'linear'
%      INPUTS:
%         imgOri:  original image to resize
%         fact:    resizing factor
%      OUTPUTS: 
%         imgResized: resized image
function imgResized = impro_resize( imgOri, fact ) 

sxOri= size(imgOri,2);
syOri= size(imgOri,1);
sxRes= round(sxOri * fact);
syRes= round(syOri * fact);

imgResized = cvResize( imgOri, sxRes, syRes );
