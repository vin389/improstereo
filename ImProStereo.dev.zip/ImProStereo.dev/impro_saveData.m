function handles = ...
         impro_saveData(hObject, handles)
% This function saves gui variable "handles" into a user selected file.
% This function is designed for ImPro Strain 2.0 only.

% Create the folder if it does not exist
if ( ~exist(handles.DataPath, 'dir') )
    mkdir(handles.DataPath);
end

[handles.DataFile handles.DataPath] = uiputfile('*.mat');
if ( isnumeric(handles.DataPath) && isnumeric(handles.DataFile) ) 
  return     
end
save([handles.DataPath handles.DataFile], 'handles');

end