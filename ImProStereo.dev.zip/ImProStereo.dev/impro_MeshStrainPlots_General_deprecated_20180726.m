function handles = impro_MeshStrainPlots_General( ...
  hObject, handles, iPair, iLR, ...
  uxGrid, uyGrid, strain2Dxx, strain2Dyy, ...
  strain2Dxy, ...
  xGrid, yGrid, ...
  infoTM, patchOptions )
% This function plots 2D figures (imagesc) of the measured results
% plots the surface on the photos.

M = size(uxGrid,1);
N = size(uxGrid,2);

for iField = patchOptions.field
   
  if ( iField == 1 )
    % Ux
    figName = sprintf('Pair-%d.Cam-%d.Ux', iPair, iLR) ;
    plotField = uxGrid ;
  elseif ( iField == 2 )
    % Uy
    figName = sprintf('Pair-%d.Cam-%d.Uy', iPair, iLR) ;
    plotField = uyGrid ;
  elseif ( iField == 3 )
    % exx
    figName = sprintf('Pair-%d.Cam-%d.Exx', iPair, iLR) ;
    plotField = strain2Dxx ;
  elseif ( iField == 4 )
    % eyy
    figName = sprintf('Pair-%d.Cam-%d.Eyy', iPair, iLR) ;
    plotField = strain2Dyy ;
  elseif ( iField == 5 )
    % exy
    figName = sprintf('Pair-%d.Cam-%d.Exy', iPair, iLR) ;
    plotField = strain2Dxy ;
  elseif (iField == 6)   
    % crack opening (45), added by vince 2015/6/23
    [crack_opening crack_sliding] = ...
        impro_crackField(uxGrid, uyGrid, 45); 
    figName = sprintf('Pair-%d.Cam-%d.Cr45_opn', iPair, iLR) ;
    plotField = crack_opening;   
  elseif (iField == 7)   
    % crack sliding (45), added by vince 2015/6/23
    [crack_opening crack_sliding] = ...
        impro_crackField(uxGrid, uyGrid, 45); 
    figName = sprintf('Pair-%d.Cam-%d.Cr45_sld', iPair, iLR) ;
    plotField = crack_sliding;   
  elseif (iField == 8)   
    % crack opening (135), added by vince 2015/6/23
    [crack_opening crack_sliding] = ...
        impro_crackField(uxGrid, uyGrid, 135); 
    figName = sprintf('Pair-%d.Cam-%d.Cr135_opn', iPair, iLR) ;
    plotField = crack_opening;   
  elseif (iField == 9)   
    % crack opening (135), added by vince 2015/6/23
    [crack_opening crack_sliding] = ...
        impro_crackField(uxGrid, uyGrid, 135); 
    figName = sprintf('Pair-%d.Cam-%d.Cr135_sld', iPair, iLR) ;
    plotField = crack_sliding;   
  elseif (iField == 10)   % crack sliding maximal, modified by vince 2016/5/1
      figName = sprintf('Pair-%d.Cam-%d.Crack_opn', iPair, iLR) ;
	  for crackDeg = [0 45 135]
		  [crack_opening crack_sliding] = ...
			  impro_crackField(uxGrid, uyGrid, crackDeg); 
	      if (crackDeg == 0) 
			max_crack = crack_opening; 
	      else 
		    max_crack = max(crack_opening, max_crack);
		  end
	  end
      plotField = max_crack;   
  elseif (iField == 11)   % field 7 + 9, added by vince 2016/4/19
      figName = sprintf('Pair-%d.Cam-%d.Crack_sld', iPair, iLR) ;
	  for crackDeg = [0 45 135]
		  [crack_opening crack_sliding] = ...
			  impro_crackField(uxGrid, uyGrid, crackDeg); 
	      if (crackDeg == 0) 
			max_crack = crack_sliding; 
	      else 
		    max_crack = max(crack_sliding, max_crack);
		  end
	  end
      plotField = max_crack;
  end
 
  hfig = figure('name', figName );
  imagesc([xGrid(1) xGrid(N)], [yGrid(1) yGrid(M)], plotField );
  % Set colormap and caxis range (added by vince, 19-Mar-2015)
  reversed = 0; 
  colormapUserValue   = get(handles.popmenuColormap, 'Value'); 
  if (colormapUserValue > 13) % there are 13 colormaps and 13 reversed ones
     colormapUserValue = colormapUserValue - 13; 
     reversed = 1;
  end
  colormapUserStrings = get(handles.popmenuColormap, 'String'); 
  thecolormap = colormap(colormapUserStrings{colormapUserValue});
  if (reversed == 1) 
      colormapsize = size(thecolormap, 1); 
      thecolormap(1:colormapsize,:) = thecolormap(colormapsize:-1:1,:);
  end
  thecolormap(1,:) = 1.0;    % set white to those out of range
  thecolormap(end,:) = 1.0;  % set white to those out of range
  colormap(thecolormap);
  colorbar;
%  set(gca, 'clim', climit);
  axis equal;  % Added by vince. 2013/04/23 

  % set climit according to users assignment (added by vince 2013/10/14)
  if ( size(patchOptions.caxis,1) * size(patchOptions.caxis,2) == 2) 
    caxis( patchOptions.caxis );
  else
    caxis([min(plotField(:)) max(plotField(:))]);
  end  
  
  % Save figures to files. 
  
  saveas(hfig, [handles.ListPath figName '.fig' ] );
  save( [handles.ListPath figName '.mat'], 'plotField' );
  theFigFrame = getframe(hfig);
  imwrite(theFigFrame.cdata, [handles.ListPath figName '_fig.jpg']);
  close(hfig);
  
  % Save plotfield (...mat) to CSV format (added on 2018/6/13) 
  
  csvwrite( [handles.ListPath figName '.csv'], ...
      plotField .* (plotField >= patchOptions.caxis(1) & plotField <= patchOptions.caxis(2)) );
  
  % Only for debug. (Calculate and output specific values)
  
  % tmpDebugStep; 
  

end
