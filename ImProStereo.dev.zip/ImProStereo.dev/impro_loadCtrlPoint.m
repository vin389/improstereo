function handles = ...
         impro_loadCtrlPoint(hObject, handles)
% This function loads gui variable "handles" from a user selected file.
% This function is designed for ImPro Strain 2.0 only.

% Deals with that DataPath is changed to a new path
%   thisDataFile: the file name of the data file (.mat)
%   thisDataPath: the path      of the data file (.mat)
[thisDataFile thisDataPath] = uigetfile('*.mat');
if ( isnumeric(thisDataPath) && isnumeric(thisDataFile) ) 
  return     
end
loadedHandles = load([thisDataPath thisDataFile]);

% Copy variables from loaded handles to the current handles
%fieldnames_save_data = fieldnames(loadedHandles.handles);
%n_fields = max(size(fieldnames_save_data)); 
%for i_field = 1: n_fields
%    handles.(fieldnames_save_data{i_field}) = ...
%        loadedHandles.handles.(fieldnames_save_data{i_field}); 
%end

handles.ListFile       = loadedHandles.handles.ListFile;
handles.ListPath       = loadedHandles.handles.ListPath;
handles.nPair          = loadedHandles.handles.nPair;
handles.nLR            = loadedHandles.handles.nLR; 
handles.nPoint         = loadedHandles.handles.nPoint;
handles.PhotoPath      = loadedHandles.handles.PhotoPath;
handles.TmpltPath      = loadedHandles.handles.TmpltPath;
handles.MatchPath      = loadedHandles.handles.MatchPath;
handles.RectfPath      = loadedHandles.handles.RectfPath;
handles.filelistPhoto  = loadedHandles.handles.filelistPhoto;
handles.filelistTmplt  = loadedHandles.handles.filelistTmplt;
handles.filelistMatch  = loadedHandles.handles.filelistMatch;
handles.filelistRectf  = loadedHandles.handles.filelistRectf;
handles.DataFile       = loadedHandles.handles.DataFile;
handles.DataPath       = loadedHandles.handles.DataPath;

% Check if thisDataPath equals to loaded handles.DataPath.
% If not, ask the user if she/he wants to change to thisDataPath
% Note: These checks are case insensitive (for Windows only)
% Check and ask about DataPath (by vince, 2014-07-28)
if ( strcmpi(handles.DataPath, thisDataPath) == 0)
    % ask user about DataPath
    qstring = ['Data path is changed. Do you want to update to new path?  ' ...
               '(from ' handles.DataPath '  to ' thisDataPath]; 
    userResponse = questdlg(qstring,'DataPath changed?','Yes'); 
    % 
    if (strcmpi(userResponse, 'Yes') == 1) 
        oldDataPath = handles.DataPath; 
        handles.DataPath = thisDataPath;
    end   
end % end if handles.DataPath is not equal to thisDataPath

% Check if thisDataFile equals to loaded handles.DataFile.
% If not, ask the user if she/he wants to change to thisDataFile
% Note: These checks are case insensitive (for Windows only)
% Check and ask about DataFile (by vince, 2014-07-28)
if ( strcmpi(handles.DataFile, thisDataFile) == 0)
    % ask user about DataFile
    qstring = ['Data file is changed. Do you want to update to new path?  ' ...
               '(from ' handles.DataFile '  to ' thisDataFile]; 
    userResponse = questdlg(qstring,'DataFile changed?','Yes'); 
    % 
    if (strcmpi(userResponse, 'Yes') == 1) 
        handles.DataFile = thisDataFile;
    end   
end % end if handles.DataFile is not equal to thisDataFile

% Check if handles.ListPath equals to loaded handles.DataPath.
% If not, and exist([handles.DataPath handles.ListFile],'dir') is true (7)
% then ask the user if she/he wants to change to DataPath
% Note: These checks are case insensitive (for Windows only)
% Check and ask about ListPath (by vince, 2014-07-28)
if ( strcmpi(handles.ListPath, handles.DataPath) == 0 && ...
     exist([handles.DataPath handles.ListFile], 'file') ~= 0 ) 
    % ask user about ListPath
    qstring = ['Do you want to update ListPath ' ...
               '(from ' handles.ListPath '  to ' handles.DataPath]; 
    userResponse = questdlg(qstring,'ListPath changed?','Yes'); 
    % 
    if (strcmpi(userResponse, 'Yes') == 1) 
        oldListPath = handles.ListPath; 
        handles.ListPath = handles.DataPath;
    end   
end % end if ListPath ~= DataPath and [DataPath ListFile] exists

% Check if handles.PhotoPath contains oldDataPath
% If yes, try to replace part of handles.PhotoPath with handles.DataPath
% and if exist(newPhotoPath,'dir') is true (7)
% then ask the user if she/he wants to change to the new path.
% Note: These checks are case insensitive (for Windows only)
% Check and ask about PhotoPath (by vince, 2014-07-28)
if (exist('oldDataPath', 'var') ~= 0) 
    % check if handles.PhotoPath{1} contains oldDataPath
    if (isempty(strfind(lower(handles.PhotoPath{1}), lower(oldDataPath))) == 0)
        possibleNewPath = strrep(lower(handles.PhotoPath{1}), lower(oldDataPath), handles.DataPath);         
        % check if possibleNewPath exist
        if (exist(possibleNewPath, 'dir') ~= 0) 
            % ask user about PhotoPath{1}
            qstring = ['Do you want to update PhotoPath{1} ' ...
                       '(from ' handles.PhotoPath{1} '  to ' possibleNewPath]; 
            userResponse = questdlg(qstring,'PhotoPath{1} changed?','Yes'); 
            % 
            if (strcmpi(userResponse, 'Yes') == 1) 
                handles.PhotoPath{1} = possibleNewPath;
            end              
        end % end if possibleNewPath exists
    end % end if handles.PhotoPath{1} contains oldDataPath
    
    % check if handles.PhotoPath{2} contains oldDataPath
    if (isempty(strfind(lower(handles.PhotoPath{2}), lower(oldDataPath))) == 0)
        possibleNewPath = strrep(lower(handles.PhotoPath{2}), lower(oldDataPath), handles.DataPath);         
        % check if possibleNewPath exist
        if (exist(possibleNewPath, 'dir') ~= 0) 
            % ask user about PhotoPath{1}
            qstring = ['Do you want to update PhotoPath{2} ' ...
                       '(from ' handles.PhotoPath{2} '  to ' possibleNewPath]; 
            userResponse = questdlg(qstring,'PhotoPath{2} changed?','Yes'); 
            % 
            if (strcmpi(userResponse, 'Yes') == 1) 
                handles.PhotoPath{2} = possibleNewPath;
            end              
        end % end if possibleNewPath exists
    end % end if handles.PhotoPath{2} contains oldDataPath
end % end if oldDataPath variable exists 

% Check if handles.TmpltPath contains oldDataPath
% If yes, try to replace part of handles.TmpltPath with handles.DataPath
% and if exist(newTmpltPath,'dir') is true (7)
% then ask the user if she/he wants to change to the new path.
% Note: These checks are case insensitive (for Windows only)
% Check and ask about TmpltPath (by vince, 2014-07-28)
if (exist('oldDataPath', 'var') ~= 0) 
    % check if handles.TmpltPath{1} contains oldDataPath
    if (isempty(strfind(lower(handles.TmpltPath{1}), lower(oldDataPath))) == 0)
        possibleNewPath = strrep(lower(handles.TmpltPath{1}), lower(oldDataPath), handles.DataPath);         
        % check if possibleNewPath exist
        if (exist(possibleNewPath, 'dir') ~= 0) 
            % ask user about TmpltPath{1}
            qstring = ['Do you want to update TmpltPath{1} ' ...
                       '(from ' handles.TmpltPath{1} '  to ' possibleNewPath]; 
            userResponse = questdlg(qstring,'TmpltPath{1} changed?','Yes'); 
            % 
            if (strcmpi(userResponse, 'Yes') == 1) 
                handles.TmpltPath{1} = possibleNewPath;
            end              
        end % end if possibleNewPath exists
    end % end if handles.TmpltPath{1} contains oldDataPath
    
    % check if handles.TmpltPath{2} contains oldDataPath
    if (isempty(strfind(lower(handles.TmpltPath{2}), lower(oldDataPath))) == 0)
        possibleNewPath = strrep(lower(handles.TmpltPath{2}), lower(oldDataPath), handles.DataPath);         
        % check if possibleNewPath exist
        if (exist(possibleNewPath, 'dir') ~= 0) 
            % ask user about TmpltPath{2}
            qstring = ['Do you want to update TmpltPath{2} ' ...
                       '(from ' handles.TmpltPath{2} '  to ' possibleNewPath]; 
            userResponse = questdlg(qstring,'TmpltPath{2} changed?','Yes'); 
            % 
            if (strcmpi(userResponse, 'Yes') == 1) 
                handles.TmpltPath{2} = possibleNewPath;
            end              
        end % end if possibleNewPath exists
    end % end if handles.TmpltPath{2} contains oldDataPath
end % end if oldDataPath variable exists 

% Check if handles.MatchPath contains oldDataPath
% If yes, try to replace part of handles.MatchPath with handles.DataPath
% and if exist(newMatchPath,'dir') is true (7)
% then ask the user if she/he wants to change to the new path.
% Note: These checks are case insensitive (for Windows only)
% Check and ask about MatchPath (by vince, 2014-07-28)
if (exist('oldDataPath', 'var') ~= 0) 
    % check if handles.MatchPath{1} contains oldDataPath
    if (isempty(strfind(lower(handles.MatchPath{1}), lower(oldDataPath))) == 0)
        possibleNewPath = strrep(lower(handles.MatchPath{1}), lower(oldDataPath), handles.DataPath);         
        % check if possibleNewPath exist
        if (exist(possibleNewPath, 'dir') ~= 0) 
            % ask user about MatchPath{1}
            qstring = ['Do you want to update MatchPath{1} ' ...
                       '(from ' handles.MatchPath{1} '  to ' possibleNewPath]; 
            userResponse = questdlg(qstring,'MatchPath{1} changed?','Yes'); 
            % 
            if (strcmpi(userResponse, 'Yes') == 1) 
                handles.MatchPath{1} = possibleNewPath;
            end              
        end % end if possibleNewPath exists
    end % end if handles.MatchPath{1} contains oldDataPath
    
    % check if handles.MatchPath{2} contains oldDataPath
    if (isempty(strfind(lower(handles.MatchPath{2}), lower(oldDataPath))) == 0)
        possibleNewPath = strrep(lower(handles.MatchPath{2}), lower(oldDataPath), handles.DataPath);         
        % check if possibleNewPath exist
        if (exist(possibleNewPath, 'dir') ~= 0) 
            % ask user about MatchPath{2}
            qstring = ['Do you want to update MatchPath{2} ' ...
                       '(from ' handles.MatchPath{2} '  to ' possibleNewPath]; 
            userResponse = questdlg(qstring,'MatchPath{2} changed?','Yes'); 
            % 
            if (strcmpi(userResponse, 'Yes') == 1) 
                handles.MatchPath{2} = possibleNewPath;
            end              
        end % end if possibleNewPath exists
    end % end if handles.MatchPath{2} contains oldDataPath
end % end if oldDataPath variable exists 

% Check if handles.RectfPath contains oldDataPath
% If yes, try to replace part of handles.RectfPath with handles.DataPath
% and if exist(newRectfPath,'dir') is true (7)
% then ask the user if she/he wants to change to the new path.
% Note: These checks are case insensitive (for Windows only)
% Check and ask about RectfPath (by vince, 2014-07-28)
if (exist('oldDataPath', 'var') ~= 0) 
    % check if handles.RectfPath{1} contains oldDataPath
    if (isempty(strfind(lower(handles.RectfPath{1}), lower(oldDataPath))) == 0)
        possibleNewPath = strrep(lower(handles.RectfPath{1}), lower(oldDataPath), handles.DataPath);         
        % check if possibleNewPath exist
        if (exist(possibleNewPath, 'dir') ~= 0) 
            % ask user about RectfPath{1}
            qstring = ['Do you want to update RectfPath{1} ' ...
                       '(from ' handles.RectfPath{1} '  to ' possibleNewPath]; 
            userResponse = questdlg(qstring,'RectfPath{1} changed?','Yes'); 
            % 
            if (strcmpi(userResponse, 'Yes') == 1) 
                handles.RectfPath{1} = possibleNewPath;
            end              
        end % end if possibleNewPath exists
    end % end if handles.RectfPath{1} contains oldDataPath
    
    % check if handles.RectfPath{2} contains oldDataPath
    if (isempty(strfind(lower(handles.RectfPath{2}), lower(oldDataPath))) == 0)
        possibleNewPath = strrep(lower(handles.RectfPath{2}), lower(oldDataPath), handles.DataPath);         
        % check if possibleNewPath exist
        if (exist(possibleNewPath, 'dir') ~= 0) 
            % ask user about RectfPath{2}
            qstring = ['Do you want to update RectfPath{2} ' ...
                       '(from ' handles.RectfPath{2} '  to ' possibleNewPath]; 
            userResponse = questdlg(qstring,'RectfPath{2} changed?','Yes'); 
            % 
            if (strcmpi(userResponse, 'Yes') == 1) 
                handles.RectfPath{2} = possibleNewPath;
            end              
        end % end if possibleNewPath exists
    end % end if handles.RectfPath{2} contains oldDataPath
end % end if oldDataPath variable exists 


if ( isfield(loadedHandles.handles, 'CtrlPoints') )
  handles.CtrlPoints     = loadedHandles.handles.CtrlPoints;
end
if ( isfield(loadedHandles.handles, 'CtrlPoints3D') )
  handles.CtrlPoints3D = loadedHandles.handles.CtrlPoints3D;
end
if ( isfield(loadedHandles.handles, 'CtrlPoints3Derr') )
  handles.CtrlPoints3Derr = loadedHandles.handles.CtrlPoints3Derr;
end
if ( isfield(loadedHandles.handles, 'measurementErr') )
  handles.measurementErr  = loadedHandles.handles.measurementErr;
end
if ( isfield(loadedHandles.handles, 'CoordSys') )
  handles.CoordSys  = loadedHandles.handles.CoordSys;
end
if ( isfield(loadedHandles.handles, 'calib3d') )
  handles.calib3d      = loadedHandles.handles.calib3d;
end
if ( isfield(loadedHandles.handles, 'rectfMeasureRange') )
  handles.rectfMeasureRange = loadedHandles.handles.rectfMeasureRange;
end
if ( isfield(loadedHandles.handles, 'rpxRectf') )
  handles.rpxRectf = loadedHandles.handles.rpxRectf;
end
if ( isfield(loadedHandles.handles, 'TmpltSize') )
  handles.TmpltSize = loadedHandles.handles.TmpltSize;
end
if ( isfield(loadedHandles.handles, 'camMove') )
  handles.camMove = loadedHandles.handles.camMove;
end
if ( isfield(loadedHandles.handles, 'calibSingleCam') )
  handles.calibSingleCam = loadedHandles.handles.calibSingleCam;
end
if ( isfield(loadedHandles.handles, 'SingleCamCoord') )
  handles.SingleCamCoord = loadedHandles.handles.SingleCamCoord;
end

handles.iPair  = 1;
handles.iLR    = 1;
handles.iPoint = 1;
clear loadedHandles;

% Enable ui components if related information is available in handles

% Setup ui objects and display information
if ( isfield(handles, 'nPair') && handles.nPair >= 1 ) 
  nPair = handles.nPair; 
  set(handles.slPair, 'Min', 1);
  set(handles.slPair, 'Max', nPair);
  set(handles.slPair, 'Value', handles.iPair);
  if (nPair > 1) % added by vince (2016/10/28) for case of nPair is 1.
    set(handles.slPair, 'SliderStep', [1./(nPair-1) 1./(nPair-1)] );
  else
    set(handles.slPair, 'SliderStep', [1 1]);
  end
  set(handles.txPair, 'String', sprintf('Photo pair %05d', 1) );
  set(handles.slPair, 'Enable', 'on');
end
  
txLR={'Left','Right'};
if ( isfield(handles, 'nLR') && handles.nLR >= 2 )
  nLR = handles.nLR; 
  set(handles.slLR,   'Min', 1);
  set(handles.slLR,   'Max', nLR);
  set(handles.slLR,   'Value', handles.iLR);
  set(handles.slLR,   'SliderStep', [1./(nLR-1) 1./(nLR-1)] );
  txLR={'Left','Right'};
  set(handles.txLR,   'String', txLR{1} );
  set(handles.slLR,   'Enable', 'on');
else
  set(handles.slLR,'Enable','off');
end

if ( isfield(handles, 'nPoint') && handles.nPoint >=1 );
  nPoint = handles.nPoint;
  set(handles.slPoint,   'Min', 1);
  set(handles.slPoint,   'Max', nPoint);
  set(handles.slPoint,   'Value', handles.iPoint);
  set(handles.slPoint,   'SliderStep', [1./(nPoint-1) 1./(nPoint-1)] );
  set(handles.slPoint,   'Enable', 'on');
end

% Call slider call-back function
handles = impro_updSlPair(hObject, handles);
handles = impro_updSlLR(hObject, handles);
handles = impro_updSlPoint(hObject, handles);

% quest if load CtrlPoints from all Match mat files.
%dlgans = questdlg('Update all CtrlPoints from Match files?', ...
%               'Update','Yes','No','Yes');
%if ( strcmp(dlgans,'Yes') )
%   for iPair = 1: handles.nPair
%       for iLR = 1: handles.nLR
%           for iPoint = 1: handles.nPoint
%               [handles,iMatchImg] = ...
%                   impro_loadMatch(hObject, handles, iPair, iLR, iPoint);
%           end
%       end
%   end
%end



end