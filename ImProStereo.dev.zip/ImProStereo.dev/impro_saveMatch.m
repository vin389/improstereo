function handles = impro_saveMatch(hObject, handles, iPair, iLR, ...
                   iPoint, mchImg, mchXy, refXy, corr )
% This function saves matched image and data to file

% Create the folder if it does not exist
if ( ~exist(handles.MatchPath{iLR}, 'dir') )
    mkdir(handles.MatchPath{iLR});
end

% Load data from matched file first if it exists, and
% only modify data which are updated. 
if ( exist([handles.MatchPath{iLR} handles.filelistMatch{iPair,iLR}],'file') )
  iMatch = load([handles.MatchPath{iLR} handles.filelistMatch{iPair,iLR}]);
%  handles.iMatch = iMatch.iMatch;
  handles.iMatch{iLR} = iMatch.iMatch; % Modified by vince. 2013/04/23
%            iMatch{iLR}
%            iMatch{iLR}.nPoint   -- number of control points in each photo
%            iMatch{iLR}.file{iP} -- file name of matched image file (.JPG)
%            iMatch{iLR}.mchXy{iP}(1,1:2) -- matched picked point in image
%            iMatch{iLR}.refXy{iP}(1,1:2) -- matched picked point in match
%            iMatch{iLR}.corr{iP} -- correlation of each matching
end
handles.iMatchImg{iLR,iPoint} = mchImg;
handles.iMatch{iLR}.nPoint = handles.nPoint;
tstr= handles.filelistMatch{iPair,iLR};
handles.iMatch{iLR}.file{iPoint} = [tstr(1:size(tstr,2)-4) ...
        sprintf('_Point%03d.jpg',iPoint)]; 
handles.iMatch{iLR}.mchXy{iPoint}(1,1:2) = mchXy(1:2);
handles.iMatch{iLR}.refXy{iPoint}(1,1:2) = refXy(1:2);
handles.iMatch{iLR}.corr{iPoint}         = corr(1); 

% update handles.CtrlPoints (added by vince, 2012-05-16) 
handles.CtrlPoints(iPair,iLR,iPoint,1:2) = ...
      handles.iMatch{iLR}.mchXy{iPoint}(1,1:2);     

% Save iMatch to match file
% iMatch = handles.iMatch; 
iMatch = handles.iMatch{iLR}; % Modified by vince. 2013/04/23
save([handles.MatchPath{iLR} handles.filelistMatch{iPair,iLR}], 'iMatch');
% Save image
imwrite( mchImg, [handles.MatchPath{iLR} handles.iMatch{iLR}.file{iPoint}] );

end