function impro_showPhoto(hObject, handles, iPair, iLR)
% This function loads photo image and data from file and show the image

% Photos
%   Define handles.iPhoto{iLR}
if ( exist([handles.PhotoPath{iLR} handles.filelistPhoto{iPair,iLR}],'file') )
  handles.iPhoto{iLR} = imread( [handles.PhotoPath{iLR} handles.filelistPhoto{iPair,iLR}] );
  % if read image is one-channel, convert it to 3-channel (vince 2014-08-07)
  if (size(handles.iPhoto{iLR},3) == 1)      
     handles.iPhoto{iLR} = uint8(cat(3,handles.iPhoto{iLR},handles.iPhoto{iLR},handles.iPhoto{iLR}));
  end
  
  axes(handles.axPhoto{iLR});
  image(handles.iPhoto{iLR});
  fprintf('Photo Pair:%d/LR:%d loaded.\n', iPair, iLR );
else
  handles.iPhoto{iLR} = [];
  cla(handles.axPhoto{iLR});
  fprintf('Photo Pair:%d/LR:%d did not loaded.\n', iPair, iLR );
end

guidata(hObject, handles);
end


