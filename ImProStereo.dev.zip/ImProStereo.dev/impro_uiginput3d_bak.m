function varargout = impro_uiginput3d(varargin)
% IMPRO_UIGINPUT3D M-file for impro_uiginput3d.fig
%      IMPRO_UIGINPUT3D, by itself, creates a new IMPRO_UIGINPUT3D or raises the existing
%      singleton*.
%
%      H = IMPRO_UIGINPUT3D returns the handle to a new IMPRO_UIGINPUT3D or the handle to
%      the existing singleton*.
%
%      IMPRO_UIGINPUT3D('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in IMPRO_UIGINPUT3D.M with the given input arguments.
%
%      IMPRO_UIGINPUT3D('Property','Value',...) creates a new IMPRO_UIGINPUT3D or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before impro_uiginput3d_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to impro_uiginput3d_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES
% 
% ------------------------------------------------------------------------
% Variables in this handles
% ------------------------------------------------------------------------
%   handles.ListPath/ListFile - [ListPath ListFile] is the full path of the
%                               file-list file.
%   handles.DataPath/DataFile - [DataPath DataFile] is the full path of the
%                               complete handles data. By default it is the
%                               same as [ListPath ListFile] except the ext.
%                               name is '.mat'. 
%   handles.CalibPath/CalibFile - the full path of the 3D calibration data.
%   handles.nPair         - number of pairs of photos
%   handles.nLR           - number of photos in a pair (1 or 2)
%   handles.nPoint        - number of control points in a photo (default:4)
%
%   handles.iPair         - the current pair of photos (shown) 
%   handles.iLR           - selected side (1:left or 2:right)
%   handles.iPoint        - selected control point
% 
%   ----------------------------------------------------------------------
%   handles.CtrlPoints(iPair,iLR,iPoint,iXy) - the matched control points
%                                              in images 
%   handles.CtrlPoints3D(iPair,iLR,iPoint,iXyz) - the matched control 
%                                              points in 3D (L camera)
%                                              in images 
%   ----------------------------------------------------------------------
%   handles.filelistPhoto{iPair,iLR} - file list of photo files (.JPG)
%                         - iPair: the pair index of photos
%                         - iLR: Left(iLR=1) or Right(iLR=2) photo
%   
%   Note: Only the current pair (iPair) data are stored in MATLAB memory.
%
%   ----------------------------------------------------------------------
%   handles.filelistTmplt{iPair,iLR} - file list of template files (.mat)
%                         - iPair: the pair index of photos
%                         - iLR: Left(iLR=1) or Right(iLR=2) photo
%         The MATLAB structure: 
%   handles.iTmplt{iLR}
%           iTmplt{iLR}.nPoint   -- number of control points in each photo
%           iTmplt{iLR}.file{iP} -- file name of template image file (.JPG)
%           iTmplt{iLR}.pckXy{iP}(1,1:2) -- picked point in image
%           iTmplt{iLR}.refXy{iP}(1,1:2) -- picked point in template
%
%   handles.iTmplt{iLR}   - the template data of the current photo pair 
%
%   Note: Only the current pair (iPair) data are stored in MATLAB memory.
%
%   ----------------------------------------------------------------------
%   handles.filelistMatch{iPair,iLR} - file list of matched files (.mat)
%                         - iPair: the pair index of photos
%                         - iLR: Left(iLR=1) or Right(iLR=2) photo
%          The MATLAB structure: 
%    handles.iMatch{iLR}   - the matched data of the current photo pair 
%            iMatch{iLR}.nPoint   -- number of ctrl points in each photo
%            iMatch{iLR}.file{iP} -- file name of matched image (.JPG)
%            iMatch{iLR}.mchXy{iP}(1,1:2) -- matched picked point in image
%            iMatch{iLR}.refXy{iP}(1,1:2) -- matched picked point in match
%            iMatch{iLR}.corr{iP} -- correlation of each matching
%
%   Note: Only the current pair (iPair) data are stored in MATLAB memory.
%
%   ----------------------------------------------------------------------
%   handles.filelistRectf{iPair,iLR} - file list of rectified files (.mat)
%                         - iPair: the pair index of photos
%                         - iLR: Left(iLR=1) or Right(iLR=2) photo
%          The MATLAB structure: 
%     handles.iRectf{iLR}   - the rectified data of the current photo pair 
%             iRectf{iLR}.nPoint   -- number of ctrl points in each photo
%             iRectf{iLR}.file -- file name of rectified image (.JPG)
%
%   ----------------------------------------------------------------------
%   handles.calib3d - 3D calibration data
%                   including the following important factors:
%     handles.calib3d.fc_left/right
%     handles.calib3d.kc_left/right
%     handles.calib3d.cc_left/right
%     handles.calib3d.alpha_c_left/right
%     handles.calib3d.om
%     handles.calib3d.T
%
%   ----------------------------------------------------------------------
% 
% UI objects 
%   handles.axPhotoLeft - handles.axPhoto{1}
%   handles.axPhotoRigt - handles.axPhoto{2}
%   handles.axTmpltLeft - handles.axTmplt{1}
%   handles.axTmpltRigt - handles.axTmplt{2}
%   handles.axMatchLeft - handles.axMatch{1}
%   handles.axMatchRigt - handles.axMatch{2}
%   handles.axRectfLeft - handles.axRectf{1}
%   handles.axRectfRigt - handles.axRectf{2}
%   handles.txCorrLeft  - handles.txCorr{1}
%   handles.txCorrRigt  - handles.txCorr{2}
% 
%   handles.slPair
%   handles.slLR
%   handles.slPoint
% 
% 
% 
% 
% Edit the above text to modify the response to help impro_uiginput3d

% Last Modified by GUIDE v2.5 04-Mar-2011 07:40:00

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @impro_uiginput3d_OpeningFcn, ...
                   'gui_OutputFcn',  @impro_uiginput3d_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

% ------------------------------------------------------------------------
% ------------------------------------------------------------------------

% --- Executes just before impro_uiginput3d is made visible.
function impro_uiginput3d_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to impro_uiginput3d (see VARARGIN)

handles = impro_uiginput3dInit(hObject, handles );

% Choose default command line output for impro_uiginput3d
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes impro_uiginput3d wait for user response (see UIRESUME)
% uiwait(handles.fgImproUiGinput3d);

% ------------------------------------------------------------------------
% ------------------------------------------------------------------------

% --- Outputs from this function are returned to the command line.
function varargout = impro_uiginput3d_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

% ------------------------------------------------------------------------
% ------------------------------------------------------------------------

% --- Executes on button press in pbGetFileList.
function pbGetFileList_Callback(hObject, eventdata, handles)
% hObject    handle to pbGetFileList (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles = impro_getFileList(hObject, handles);

% update handles variables
guidata(hObject, handles);

% ------------------------------------------------------------------------
% ------------------------------------------------------------------------

% --- Executes on slider movement.
function slPair_Callback(hObject, eventdata, handles)
% hObject    handle to slPair (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

% Set the slider disable until this function completes.
set(handles.slPair,'Enable','off');

% update slPair 
handles = impro_updSlPair(hObject, handles);

% Set the slider disable until this function completes.
set(handles.slPair,'Enable','on');

% update handles variables
guidata(hObject, handles);

% ------------------------------------------------------------------------
% ------------------------------------------------------------------------

% --- Executes during object creation, after setting all properties.
function slPair_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slPair (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end

% ------------------------------------------------------------------------
% ------------------------------------------------------------------------

% --- Executes on button press in pbPickPoint.
function pbPickPoint_Callback(hObject, eventdata, handles)
% hObject    handle to pbPickPoint (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles = impro_pbPickPoint(hObject, handles); 

% update handles variables
guidata(hObject, handles);

% ------------------------------------------------------------------------
% ------------------------------------------------------------------------

% --- Executes on slider movement.
function slLR_Callback(hObject, eventdata, handles)
% hObject    handle to slLR (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

% Set the slider disable until this function completes.
set(handles.slLR,'Enable','off');

% update slLR status
handles = impro_updSlLR(hObject, handles);

% Set the slider disable until this function completes.
set(handles.slLR,'Enable','on');

% update handles variables
guidata(hObject, handles);

% ------------------------------------------------------------------------
% ------------------------------------------------------------------------

% --- Executes during object creation, after setting all properties.
function slLR_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slLR (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end

% ------------------------------------------------------------------------
% ------------------------------------------------------------------------

% --- Executes on slider movement.
function slPoint_Callback(hObject, eventdata, handles)
% hObject    handle to slPoint (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

% Set the slider disable until this function completes.
set(handles.slPoint,'Enable','off');

% update slPoint status
handles = impro_updSlPoint(hObject,handles);

% Set the slider disable until this function completes.
set(handles.slPoint,'Enable','on');
% update handles variables
guidata(hObject, handles);

% ------------------------------------------------------------------------
% ------------------------------------------------------------------------

% --- Executes during object creation, after setting all properties.
function slPoint_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slPoint (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end

% ------------------------------------------------------------------------
% ------------------------------------------------------------------------

% --- If Enable == 'on', executes on mouse press in 5 pixel border.
% --- Otherwise, executes on mouse press in 5 pixel border or over txPoint.
function txPoint_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to txPoint (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Change number of control points (handles.nPoint)
handles = impro_changeNPoint(hObject, handles);

% update handles variables
guidata(hObject, handles);


% --- Executes on button press in pbAutoMatch.
function pbAutoMatch_Callback(hObject, eventdata, handles)
% hObject    handle to pbAutoMatch (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles = impro_autoMatch(hObject, handles);
% update handles variables
guidata(hObject,handles);


% --- Executes on button press in pbManualMatch.
function pbManualMatch_Callback(hObject, eventdata, handles)
% hObject    handle to pbManualMatch (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles = impro_manualMatch(hObject, handles);
% update handles variables
guidata(hObject,handles);

% --- Executes on button press in pbTmCopyL2R.
function pbTmCopyL2R_Callback(hObject, eventdata, handles)
% hObject    handle to pbTmCopyL2R (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles = impro_copyTmpltL2R(hObject, handles);
guidata(hObject, handles);


% --- Executes on button press in pbDebug.
function pbDebug_Callback(hObject, eventdata, handles)
% hObject    handle to pbDebug (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
keyboard; 


% --- Executes on button press in pbLoadCtrlPoint.
function pbLoadCtrlPoint_Callback(hObject, eventdata, handles)
% hObject    handle to pbLoadCtrlPoint (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles = impro_loadCtrlPoint(hObject, handles);

guidata(hObject, handles);


% --- Executes on button press in pbSaveCtrlPoint.
function pbSaveCtrlPoint_Callback(hObject, eventdata, handles)
% hObject    handle to pbSaveCtrlPoint (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles = impro_saveCtrlPoint(hObject, handles);

guidata(hObject, handles);


% --- Executes on button press in pbLoad3dCalib.
function pbLoad3dCalib_Callback(hObject, eventdata, handles)
% hObject    handle to pbLoad3dCalib (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

[handles.CalibFile handles.CalibPath] = uigetfile('*.mat');
if ( isnumeric(handles.CalibFile) && isnumeric(handles.CalibPath) ) 
  return     
end

calib3d = load([handles.CalibPath handles.CalibFile]);
handles.calib3d = calib3d; 

guidata(hObject, handles);

% --- Executes on button press in pb3dMesh.
function pb3dMesh_Callback(hObject, eventdata, handles)
% hObject    handle to pb3dMesh (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles = impro_3dMesh( hObject, handles );

guidata(hObject, handles);


% --- Executes on button press in pbRectification.
function pbRectification_Callback(hObject, eventdata, handles)
% hObject    handle to pbRectification (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles = impro_Rectification(hObject, handles);

guidata(hObject, handles);

% --- Executes on button press in pbFieldAnalysis.
function pbFieldAnalysis_Callback(hObject, eventdata, handles)
% hObject    handle to pbFieldAnalysis (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
