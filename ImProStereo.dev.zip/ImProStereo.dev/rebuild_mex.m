mex -Iinclude cvCalcOpticalFlowPyrLK.cpp -Iinclude x64/vc15/lib/opencv_world343.lib
mex -Iinclude cvCanny.cpp                -Iinclude x64/vc15/lib/opencv_world343.lib
mex -Iinclude cvCannyAuto.cpp            -Iinclude x64/vc15/lib/opencv_world343.lib
mex -Iinclude cvRemap.cpp                -Iinclude x64/vc15/lib/opencv_world343.lib
mex -Iinclude cvResize.cpp               -Iinclude x64/vc15/lib/opencv_world343.lib
mex -Iinclude cvTemplateMatch.cpp        -Iinclude x64/vc15/lib/opencv_world343.lib
mex -Iinclude cvTemplateMatch2.cpp       -Iinclude x64/vc15/lib/opencv_world343.lib
mex -Iinclude cvTemplateMatchOptn.cpp    -Iinclude x64/vc15/lib/opencv_world343.lib
