function handles = impro_changeNPoint(hObject, handles)
% hObject    handle to txPoint (see GCBO)
% handles    structure with handles and user data (see GUIDATA)
nPoint_str = inputdlg('Number of ctrl point:', 'Update nPoint', 1, ...
             { num2str(get(handles.slPoint,'Max')) } );     
if ( size(nPoint_str) == 0 ) 
  return;
end
           
nPoint = str2num(cell2mat(nPoint_str));
if (nPoint < 3)
  uiwait(msgbox('Error: Not a valid number of ctrl point.','ERROR'));
else
  handles.nPoint = nPoint;
  set(handles.slPoint,'Max',nPoint);
  set(handles.slPoint,   'SliderStep', [1./(nPoint-1) 1./(nPoint-1)] );
end
end